import sys
import base64 as _b64
import os
import time
import requests
import threading
import configparser
import logging
import random
import shutil
import hmac
import struct
import urllib3
from PyQt5.QtWidgets import (QApplication, QMainWindow, QLabel, QPushButton, QLineEdit,
                           QVBoxLayout, QHBoxLayout, QFormLayout, QWidget, QDialog, QGridLayout,
                           QMenu, QSystemTrayIcon, QTextEdit, QMessageBox, QStyle, QComboBox, QAction, QFrame,
                           QListWidget, QListWidgetItem, QScrollArea, QStackedWidget)
from PyQt5.QtGui import QPixmap, QScreen, QFont, QIcon, QCursor, QFontMetrics
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QObject, QPoint
from evdev import InputDevice, ecodes, list_devices
from pyudev import Context, Monitor
from datetime import datetime, timedelta
import subprocess as _subprocess
import hashlib

# --- Global flag: development mode (--no-lock) ---
NO_LOCK_MODE = '--no-lock' in sys.argv
if NO_LOCK_MODE:
    print("[NO-LOCK] Development mode - locking disabled")

# v6: tum sunucu istekleri verify=True ile yapilir (MITM korumasi, project_rules §8).
# Asagidaki satir artik no-op (guvensiz istek yok) ama zararsiz; birakildi.
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- Autostart dosya içeriği (watchdog ve client ortak kullanır) ---
AUTOSTART_DIR = "/etc/xdg/autostart"
AUTOSTART_FILE = os.path.join(AUTOSTART_DIR, "fatih-client-autostart.desktop")
AUTOSTART_CONTENT = """[Desktop Entry]
Type=Application
Name=Fatih Client
Comment=Akıllı Tahta Kilit Sistemi
Exec=/usr/bin/python3 /opt/fatih-client/main.py
Hidden=false
NoDisplay=true
X-GNOME-Autostart-enabled=true
StartupNotify=false
Terminal=false
"""

# --- NEW: Setup Logging ---
log_file = os.path.expanduser("~/fatih_client.log")
logging.basicConfig(filename=log_file, level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s')
logging.info("--- Fatih Client Starting Up ---")


# ==================== KURESEL ISTISNA YAKALAYICI ====================
# PyQt5 (>=5.5) bir slot icinde yakalanmamis Python istisnasi olusursa VARSAYILAN
# excepthook'u cagirir ve ardindan qFatal() ile SURECI OLDURUR. Ana uygulamada 11
# zamanlayici geri cagrisi var (poll, duyuru slider'i, sinav, saat, yoklama...);
# bunlarin ucunde (duyuru durumu, slayt gecisi, saat) try/except YOKTU.
#
# Boyle bir cokme tahtayi calisir durumda BIRAKMIYOR: kilit penceresi kayboluyor ama
# gorev cubugu gizli / kisayollar kapali kaliyor (geri alma unlock_system'de yapiliyor,
# cokmede calismiyor). Uygulamayi yeniden baslatan bir gozcu de yok -> tahta yeniden
# baslatilana kadar kullanilamaz halde kaliyor.
#
# OZEL excepthook kurulunca PyQt5 abort ETMEZ; istisna loglanir ve dongu devam eder.
# Bir panel cizilemezse yalnizca o panel eksik kalir, tahta ayakta durur.
def _kuresel_istisna(tur, deger, iz):
    try:
        logging.critical("YAKALANMAMIS ISTISNA — surec ayakta tutuluyor", exc_info=(tur, deger, iz))
    except Exception:
        pass


sys.excepthook = _kuresel_istisna

# --- Configuration ---
# Define paths for user-specific and default configurations
APP_NAME = "fatih-client"
APP_INSTALL_DIR = "/opt/fatih-client"
USER_CONFIG_DIR = os.path.expanduser(f"~/.config/{APP_NAME}")
USER_CONFIG_PATH = os.path.join(USER_CONFIG_DIR, "config.ini")

# Resources path (for background images, etc.)
RESOURCES_DIR = os.path.join(APP_INSTALL_DIR, "resources")
if not os.path.exists(RESOURCES_DIR):
    # Fallback for local testing
    RESOURCES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources")

# The default config is installed system-wide, but we need a fallback for local testing
DEFAULT_CONFIG_PATH = "/opt/fatih-client/config.ini"
if not os.path.exists(DEFAULT_CONFIG_PATH):
    DEFAULT_CONFIG_PATH = "config.ini" # Fallback for local testing

def setup_configuration():
    """
    Ensures user configuration exists, copying from default if necessary.
    Returns the path to the active configuration file.
    """
    if not os.path.exists(USER_CONFIG_PATH):
        logging.info(f"User config not found at {USER_CONFIG_PATH}. Creating from default.")
        try:
            os.makedirs(USER_CONFIG_DIR, exist_ok=True)
            # Check if default exists before copying
            if os.path.exists(DEFAULT_CONFIG_PATH):
                shutil.copy(DEFAULT_CONFIG_PATH, USER_CONFIG_PATH)
                logging.info(f"Copied default config to {USER_CONFIG_PATH}")
            else:
                logging.error(f"Default config not found at {DEFAULT_CONFIG_PATH}. Cannot create user config.")
                # If default is missing, we can't proceed with creating a user config.
                # The app will likely fail later, which is appropriate.
                return DEFAULT_CONFIG_PATH # Fallback to trying to read the (missing) default
        except Exception as e:
            logging.error(f"Could not create user configuration: {e}")
            # Fallback to default config path if user config cannot be created
            return DEFAULT_CONFIG_PATH
    return USER_CONFIG_PATH

# Set the global CONFIG_PATH to the user's writable config file
CONFIG_PATH = setup_configuration()

config = configparser.ConfigParser()
config.read(CONFIG_PATH)
SETTINGS = config['settings']

# --- Surum: TEK DOGRULUK KAYNAGI version.txt ---
# config.ini'deki 'version' bayat kalabiliyor (setup.sh bir donem oraya sabit "V2.13"
# yaziyordu; kilit ekrani version.txt'ten okudugu icin dogru gorunurken sunucuya YANLIS
# surum bildiriliyordu). version.txt her kurulumda paketten taze kopyalanir; varsa o kazanir.
for _vf in ("/opt/fatih-client/version.txt",
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "version.txt")):
    try:
        if os.path.exists(_vf):
            with open(_vf, 'r', encoding='utf-8') as _f:
                _v = _f.read().strip()
            if _v:
                SETTINGS['version'] = _v
                break
    except Exception:
        pass

# --- Credential Deobfuscation (compiled into .so binary) ---
def _deo(v):
    """Decode obfuscated config values (ENC: prefix = base64)"""
    if v and v.startswith('ENC:'):
        try:
            return _b64.b64decode(v[4:]).decode('utf-8')
        except Exception:
            return v
    return v

def get_setting(key, fallback=''):
    """Get a config value, auto-decoding obfuscated ones"""
    return _deo(SETTINGS.get(key, fallback))

# --- Configuration Validation ---
def validate_config():
    """Validate that all required configuration variables are present"""
    required_vars = [
        'corporate_code', 'board_id', 'version', 'sub_version'
    ]
    
    missing_vars = []
    for var in required_vars:
        if var not in SETTINGS:
            missing_vars.append(var)
    
    if missing_vars:
        error_msg = f"Missing required configuration variables: {', '.join(missing_vars)}"
        logging.error(error_msg)
        raise ValueError(error_msg)
    
    logging.info("Configuration validation passed")
    logging.info(f"Loaded configuration for board: {SETTINGS.get('board_id')}")
    logging.info(f"Version: {get_setting('version')}.{get_setting('sub_version')}")

# Validate configuration on startup
try:
    validate_config()
except ValueError as e:
    print(f"Configuration Error: {e}")
    sys.exit(1)

# --- USB Password Constants (obfuscated - decoded at runtime, compiled into .so) ---
USB_PASSWORD = _b64.b64decode(''.join([
    'MzI1NDFrZWjEsFVGYWxpX3ZlbGlf',
    'aMO8c2V5aW4/xLAwNDRFSEVKU1RS',
    'xLBIVEVNRVM1NDg4OTY1RThHxLBFxLA='
])).decode('utf-8')

USB_REMOVE_PASSWORD = _b64.b64decode(''.join([
    'dWVnZTMyNTQxa2Voxa',
    'BVRmFsaV92ZWxpX2jDvHNleWluP8Sw',
    'RUhFSlNUUsSwSDUyODc0VEVNRVM1',
    'NDg5NjVFOEdpRcSwICA='
])).decode('utf-8').strip()

# --- NEW: Ensure USB drives are mounted (fixes USB not working while locked) ---
def ensure_usb_mounted():
    """
    Kilit aktifken masaüstü ortamı USB otomatik bağlama yapmayabilir.
    Bu fonksiyon bağlanmamış USB cihazlarını udisksctl ile bağlar.
    """
    try:
        # lsblk -P paramatresi ile Key="Value" formatında güvenli çıktı al
        result = _subprocess.run(
            ['lsblk', '-P', '-o', 'NAME,TYPE,RM,TRAN,MOUNTPOINT'],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0:
            return
        
        for line in result.stdout.strip().split('\n'):
            if not line.strip(): continue
            
            # Extract key-value pairs (e.g. NAME="sda1" TYPE="part" RM="1" TRAN="usb" MOUNTPOINT="")
            import re
            matches = dict(re.findall(r'([A-Z]+)="([^"]*)"', line))
            
            name = matches.get('NAME', '')
            dev_type = matches.get('TYPE', '')
            rm = matches.get('RM', '0')
            tran = matches.get('TRAN', '')
            mountpoint = matches.get('MOUNTPOINT', '')
            
            # Sadece USB/Çıkarılabilir partition'ları ve mount edilmemişleri (TRAN=usb veya RM=1)
            is_usb = (tran == 'usb' or rm == '1')
            if dev_type == 'part' and is_usb and not mountpoint:
                device_path = f'/dev/{name}'
                logging.info(f"Bağlanmamış USB cihazı bulundu: {device_path}, mount ediliyor...")
                try:
                    mount_result = _subprocess.run(
                        ['udisksctl', 'mount', '-b', device_path, '--no-user-interaction'],
                        capture_output=True, text=True, timeout=10
                    )
                    if mount_result.returncode == 0:
                        logging.info(f"USB cihazı başarıyla mount edildi: {device_path} -> {mount_result.stdout.strip()}")
                    else:
                        logging.warning(f"USB mount başarısız (udisksctl): {device_path}: {mount_result.stderr.strip()}")
                        # Native fallback for root service
                        fallback_dir = f"/media/usb_{name}"
                        os.makedirs(fallback_dir, exist_ok=True)
                        fallback_mount = _subprocess.run(['mount', device_path, fallback_dir], capture_output=True, text=True)
                        if fallback_mount.returncode == 0:
                            logging.info(f"USB fallback mount başarılı: {device_path} -> {fallback_dir}")
                        else:
                            logging.warning(f"USB fallback mount hatası: {fallback_mount.stderr.strip()}")
                except Exception as me:
                    logging.warning(f"USB mount hatası: {device_path}: {me}")
            
            # USB disk olup hiç partition'ı olmayan cihazlar (tek partition'sız USB)
            elif dev_type == 'disk' and is_usb and not mountpoint:
                # Bu disk'in partition'ı var mı kontrol et
                has_part = False
                for check_line in result.stdout.strip().split('\n'):
                    import re
                    check_matches = dict(re.findall(r'([A-Z]+)="([^"]*)"', check_line))
                    c_name = check_matches.get('NAME', '')
                    c_type = check_matches.get('TYPE', '')
                    if c_type == 'part' and c_name.startswith(name):
                        has_part = True
                        break
                
                if not has_part:
                    device_path = f'/dev/{name}'
                    logging.info(f"Partition'sız USB disk bulundu: {device_path}, mount ediliyor...")
                    try:
                        mount_result = _subprocess.run(
                            ['udisksctl', 'mount', '-b', device_path, '--no-user-interaction'],
                            capture_output=True, text=True, timeout=10
                        )
                        if mount_result.returncode == 0:
                            logging.info(f"USB disk mount edildi: {device_path} -> {mount_result.stdout.strip()}")
                        else:
                            logging.warning(f"USB disk mount başarısız (udisksctl): {device_path}: {mount_result.stderr.strip()}")
                            # Native fallback for root service
                            fallback_dir = f"/media/usb_{name}"
                            os.makedirs(fallback_dir, exist_ok=True)
                            fallback_mount = _subprocess.run(['mount', device_path, fallback_dir], capture_output=True, text=True)
                            if fallback_mount.returncode == 0:
                                logging.info(f"USB disk fallback mount başarılı: {device_path} -> {fallback_dir}")
                            else:
                                logging.warning(f"USB disk fallback mount hatası: {fallback_mount.stderr.strip()}")
                    except Exception as me:
                        logging.warning(f"USB disk mount hatası: {device_path}: {me}")
                        
    except Exception as e:
        logging.debug(f"ensure_usb_mounted hatası: {e}")

# --- Dynamic Password Control (from C# pctrl.cs) ---
# Sunucu ve istemci aynı algoritma ile şifre üretiyor
# Öğretmen Mebrecep uygulamasından bu şifreyi görüp giriyor

def get_network_time():
    """
    NTP sunucusundan ağ zamanını al (C# Tools.GetNetworkTime() karşılığı)
    Şifre hesaplaması için doğru zaman kritik
    """
    import socket
    import struct
    
    ntp_servers = SETTINGS.get('ntp_servers', 'time.google.com,time.windows.com').split(',')
    
    for server in ntp_servers:
        try:
            server = server.strip()
            # NTP packet
            client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            client.settimeout(3)
            
            # NTP request packet (48 bytes, first byte = 0x1B for client mode)
            data = b'\x1b' + 47 * b'\0'
            client.sendto(data, (server, 123))
            
            msg, _ = client.recvfrom(1024)
            client.close()
            
            # Unpack timestamp (bytes 40-43 = seconds since 1900)
            unpacked = struct.unpack('!12I', msg)
            t = unpacked[10] - 2208988800  # Convert from 1900 to 1970 epoch
            
            network_time = datetime.fromtimestamp(t)
            logging.debug(f"Got network time from {server}: {network_time}")
            return network_time
            
        except Exception as e:
            logging.debug(f"Failed to get time from {server}: {e}")
            continue
    
    # Fallback to local time if all NTP servers fail
    logging.warning("Could not get network time, using local time")
    return datetime.now()

# ============================================================================
# AĞ SAATİ SENKRONU — tahtanın sistem saati yanlış olabilir (Pardus'ta NTP kapalı
# olabiliyor, RTC kayabiliyor). Otomatik kilit, sınav penceresi, duyuru ve ekrandaki
# saat KESİNLİKLE doğru olmalı. Bu yüzden NTP'den bir OFSET hesaplanır ve zamana
# duyarlı tüm okumalar `simdi()` üzerinden yapılır. Sistem saatine DOKUNULMAZ
# (root gerektirir); ofset uygulama içinde tutulur.
# ----------------------------------------------------------------------------
_TIME_OFFSET_SEC = 0.0     # ag_saati - yerel_saat (saniye)
_TIME_SYNCED = False       # en az bir kez basarili senkron oldu mu

def simdi():
    """Senkronlanmış şimdiki zaman. NTP ofseti uygulanır; senkron yoksa yerel saat."""
    return datetime.now() + timedelta(seconds=_TIME_OFFSET_SEC)

def sync_network_time():
    """NTP'den ofseti hesaplar (bloklar — arka plan thread'inden çağır).
    Sapma 2 sn'den büyükse uyarı loglar; ağ yoksa mevcut ofset korunur."""
    global _TIME_OFFSET_SEC, _TIME_SYNCED
    try:
        yerel_once = datetime.now()
        ag = get_network_time()
        yerel_sonra = datetime.now()
        if ag is None:
            return False
        # NTP cagrisinin kendi gecikmesini ortala (yerel olcumun ortasi)
        yerel = yerel_once + (yerel_sonra - yerel_once) / 2
        sapma = (ag - yerel).total_seconds()
        # get_network_time() basarisiz olunca datetime.now() donuyor -> sapma ~0 olur;
        # bu durumda da zarar yok (ofset 0 kalir).
        if abs(sapma) > 2:
            logging.warning(f"Tahta saati {sapma:+.1f} sn sapmis — ag saatine gore duzeltiliyor.")
        else:
            logging.info(f"Saat senkronu tamam (sapma {sapma:+.1f} sn).")
        _TIME_OFFSET_SEC = sapma
        _TIME_SYNCED = True
        return True
    except Exception as e:
        logging.error(f"Saat senkronu basarisiz: {e}")
        return False

def generate_dynamic_password(dt: datetime, minute_offset: int = 0) -> str:
    """
    Dinamik şifre üret (C# pctrl.ps() karşılığı)
    Formül: (Year * Day * Minute * 85) ilk 6 karakteri
    
    Args:
        dt: Tarih/saat
        minute_offset: Dakika toleransı (0, 1, veya 2)
    """
    try:
        year = dt.year
        day = dt.day
        minute = dt.minute
        
        # C# kodundaki gibi: minute 0 veya 1 ise 2 yap
        if minute == 0 or minute == 1:
            minute = 2
        
        minute += minute_offset
        
        # Hesaplama: Year * Day * Minute * 85
        result = year * day * minute * 85
        
        # İlk 6 karakteri al
        password = str(result)[:6]
        logging.debug(f"Generated password for {dt} (offset={minute_offset}): {password}")
        return password
        
    except Exception as e:
        logging.error(f"Error generating dynamic password: {e}")
        return "000000"

def validate_dynamic_password(entered_password: str) -> bool:
    """
    Girilen şifreyi doğrula (C# pctrl.pc() karşılığı)
    Anlık dakika, +1 ve +2 dakika toleransı ile kontrol eder
    
    Args:
        entered_password: Kullanıcının girdiği şifre
    
    Returns:
        True eğer şifre geçerli ise
    """
    try:
        # Önce ağ zamanını dene, başarısızsa local time kullan
        current_time = get_network_time()
        
        # 3 farklı dakika offset ile kontrol et (tolerans)
        for offset in [0, 1, 2]:
            expected_password = generate_dynamic_password(current_time, offset)
            if entered_password == expected_password:
                logging.info(f"Password validated with offset={offset}")
                return True
        
        # Eğer ağ zamanı ile eşleşmediyse, local time ile de kontrol et
        # (internet olmadığında cihaz saati ile çalışabilsin)
        local_time = datetime.now()
        if local_time != current_time:
            logging.info("Trying local time for password validation...")
            for offset in [0, 1, 2]:
                expected_password = generate_dynamic_password(local_time, offset)
                if entered_password == expected_password:
                    logging.info(f"Password validated with local time, offset={offset}")
                    return True
        
        logging.warning(f"Invalid password entered")
        return False
        
    except Exception as e:
        logging.error(f"Error validating password: {e}")
        # Son çare: local time ile kontrol et
        try:
            local_time = datetime.now()
            for offset in [0, 1, 2]:
                expected_password = generate_dynamic_password(local_time, offset)
                if entered_password == expected_password:
                    logging.info(f"Password validated with local time (fallback), offset={offset}")
                    return True
        except:
            pass
        return False

# ============================================================================
# v6 Çevrimdışı (internetsiz) şifre — tahta-özel TOTP
# ----------------------------------------------------------------------------
# Eski `Y·d·m·85` formülü öğrenciler tarafından çözülmüştü (tek bilinmeyen dakika, tahta-özel sır YOK).
# v6: her tahtanın device_token'ından türetilen özel sır + zaman-tabanlı OTP (RFC 4226/6238).
#
# ⚠️ DETERMİNİZM: Bu blok, SUNUCU üretimiyle (v5 helpers/offlineOtp.js) BİREBİR aynı 6 haneyi
#    üretmek zorunda. Sabitler (LABEL, adım=60sn, HMAC-SHA256, kırpma, mod 10^6, sıfır-doldurma)
#    tek taraflı değiştirilemez. Test vektörü (v5 ile ortak):
#    token=a1b2...ff00 → H=83418260... → unix=1800000000 → şifre="637221".
# ============================================================================
_OTP_LABEL = b"mebre-offline-otp-v1"
_OTP_STEP = 60          # adım (saniye)
_OTP_WINDOW = 15        # doğrulama penceresi: [Cb-15 .. Cb+15] = ±15 dk saat toleransı
_OTP_MAX_FAILS = 5      # bu kadar üst üste yanlıştan sonra kilit
_OTP_LOCK_SECONDS = 300 # kilit süresi (5 dk)

def _otp_secret_from_token(device_token: str) -> bytes:
    """offline_secret = HMAC-SHA256(key=H, msg=LABEL); H = sha256(device_token) hex."""
    H = hashlib.sha256(device_token.encode("utf-8")).hexdigest()
    return hmac.new(H.encode("utf-8"), _OTP_LABEL, hashlib.sha256).digest()

def _hotp(secret: bytes, counter: int) -> str:
    """RFC 4226 HOTP: 6 haneli, sıfır-doldurulmuş."""
    c = struct.pack(">Q", counter)  # 8-byte big-endian
    mac = hmac.new(secret, c, hashlib.sha256).digest()
    off = mac[-1] & 0x0F
    p = ((mac[off] & 0x7F) << 24) | (mac[off + 1] << 16) | (mac[off + 2] << 8) | mac[off + 3]
    return str(p % 1000000).zfill(6)

def validate_totp_password(entered_password: str, unix_time: int = None) -> bool:
    """Tahta-özel TOTP doğrula (±15 dk pencere). device_token yoksa False (v6 tahtası değil)."""
    token = get_setting('device_token', '')
    if not token:
        return False
    try:
        secret = _otp_secret_from_token(token)
        if unix_time is None:
            unix_time = int(time.time())
        cb = unix_time // _OTP_STEP
        for c in range(cb - _OTP_WINDOW, cb + _OTP_WINDOW + 1):
            if hmac.compare_digest(_hotp(secret, c), entered_password):
                return True
        return False
    except Exception as e:
        logging.error(f"TOTP validation error: {e}")
        return False


# ============================================================================
# KRIZ KODU — sunucu tamamen cokse bile tahtayi acabilmek icin.
# ----------------------------------------------------------------------------
# Senaryo: v5/ynt5/DB erisilemez. O anda mobil acma da, tahta-ozel TOTP uretimi de
# calismaz (ikisi de sunucuya bagli). Bu kod TAMAMEN CEVRIMDISI dogrulanir; Mebre
# kodu kendi bilgisayarinda (internetsiz araciyla) uretip telefonla soyler.
#
#   kod = HMAC-SHA256(ANA_ANAHTAR, "<kurum_kodu>-<YYYYMMDD>") ilk 4 bayt -> 8 hane
#
# NEDEN FORMUL DEGIL: eski Y*d*m*85 formulu ogrenciler tarafindan cozulmustu —
# girdiler (kurum kodu, tarih) herkesce bilindigi icin tek sir formulun kendisiydi ve
# birkac kod gozlemlenerek cikarilabiliyordu. HMAC'te girdi-cikti arasinda gorulebilir
# oruntu yoktur; kirmak icin anahtarin kendisini cikarmak gerekir. Anahtar sizarsa
# yeni surumle DONDURULEBILIR (formulde bu imkansizdi).
#
# Gun toleransi: tahtanin saati kaymis olabilir diye dun/bugun/yarin kabul edilir
# (saat senkronu var ama internetsiz tahtada NTP de calismaz).
# Kaba kuvvet: mevcut 5-deneme kilidi bu kodu da korur (bkz. validate_admin_password).
# ============================================================================
def _kriz_anahtari():
    """Ana anahtari coz (kodda duz metin durmaz — USB sifresi/host ile ayni desen)."""
    _k = "pardus2026!"
    _o = "4351140110125605040010420010064611510206001315574250174b000757071540564206464b0b540b52174159445114435154000540120716544d43565202"
    b = bytes.fromhex(_o)
    return ''.join(chr(b[i] ^ ord(_k[i % len(_k)])) for i in range(len(b)))

def _kriz_kodu(kurum_kodu: str, gun: datetime) -> str:
    mesaj = f"{kurum_kodu}-{gun.strftime('%Y%m%d')}".encode()
    mac = hmac.new(_kriz_anahtari().encode(), mesaj, hashlib.sha256).digest()
    p = int.from_bytes(mac[0:4], 'big') & 0x7FFFFFFF
    return str(p % 100000000).zfill(8)

# Kriz kodu girilince tahta bu sure boyunca ACIK kalir: kriz aninda her ders bitiminde
# tekrar kilitlenip kodu yeniden istemesin. Sure config.ini'ye yazilir -> tahta yeniden
# baslatilsa bile pencere devam eder (kriz sirasinda reboot cok olasi).
KRIZ_ACIK_SURE_SAAT = 24

# ==================== ADMIN SIFRESI (PBKDF2) ====================
# SORUN (3 Agustos 2026 incelemesi): admin_password config.ini'de DUZ METIN duruyordu
# ve dogrulama duz karsilastirmaydi. Kullanici config'i
#     /home/etapadmin/.config/fatih-client/config.ini
# etapadmin'e ait ve 600 — ama tahta ZATEN etapadmin olarak otomatik giris yapiyor.
# Yani tahta acikken (ogretmen actiktan sonra) terminale/dosya yoneticisine ulasan bir
# ogrenci tek `cat` ile sifreyi okuyup tahtayi ISTEDIGI ZAMAN acabiliyordu. Bu, urunun
# var olma sebebini dogrudan cokertiyordu ("ogrenciler tahtayi ele geciriyor").
#
# COZUM: sifre PBKDF2-HMAC-SHA256 ile, tahtaya ozel rastgele tuzla saklanir.
#   admin_password = PBKDF2:<tuz_hex>:<hash_hex>
#
# GERIYE DONUK UYUMLU: bu bicimde OLMAYAN deger eski duz metin kabul edilir; sahadaki
# 70 okul guncellemeden once de calismaya devam eder. setup.sh yeni kurulumda/guncellemede
# duz metni hash'e cevirir.
#
# DURUSTCE SINIR: sifre 6 haneli sayi. PBKDF2 sozluk saldirisini YAVASLATIR (10^6 aday
# ~40 saat), IMKANSIZ KILMAZ. Asil koruma, dosyayi okuyabilecek kisinin tahtaya
# fiziksel erisiminin zaten sinirli olmasi.
_ADMIN_PBKDF2_TUR = 200000


def admin_sifre_uret(sifre: str) -> str:
    """Duz sifreden saklanabilir 'PBKDF2:tuz:hash' dizisi uretir."""
    tuz = os.urandom(16)
    ozet = hashlib.pbkdf2_hmac('sha256', (sifre or '').encode('utf-8'), tuz, _ADMIN_PBKDF2_TUR)
    return f"PBKDF2:{tuz.hex()}:{ozet.hex()}"


def admin_sifre_dogru(girilen: str) -> bool:
    """Girilen sifre config'teki degerle eslesiyor mu? Hem PBKDF2 hem eski duz metin."""
    saklanan = SETTINGS.get('admin_password', '803580') or '803580'

    if saklanan.startswith('PBKDF2:'):
        try:
            _, tuz_hex, ozet_hex = saklanan.split(':', 2)
            ozet = hashlib.pbkdf2_hmac(
                'sha256', (girilen or '').encode('utf-8'), bytes.fromhex(tuz_hex), _ADMIN_PBKDF2_TUR)
            return hmac.compare_digest(ozet.hex(), ozet_hex)
        except Exception as e:
            logging.error(f"admin_password PBKDF2 cozulemedi: {e}")
            return False

    # --- Eski bicim: duz metin ---
    if saklanan == 'mebre':          # cok eski kurulumlarda kalan deger
        saklanan = '803580'
    return hmac.compare_digest(str(girilen or ''), str(saklanan))


def admin_sifre_varsayilan_mi() -> bool:
    """Fabrika sifresi (803580) hala kullaniliyor mu? (Sifre degistir ekrani icin)"""
    return admin_sifre_dogru('803580')


def kriz_penceresi_kalan() -> int:
    """Kriz penceresinden kalan saniye (0 = pencere yok)."""
    try:
        until = int(SETTINGS.get('kriz_acik_until', '0') or '0')
    except ValueError:
        until = 0
    kalan = until - int(time.time())
    return kalan if kalan > 0 else 0

def kriz_penceresi_baslat():
    """Kriz penceresini baslat (kalici)."""
    _otp_persist('kriz_acik_until', int(time.time()) + KRIZ_ACIK_SURE_SAAT * 3600)
    logging.warning(f"KRIZ PENCERESI ACILDI — tahta {KRIZ_ACIK_SURE_SAAT} saat kilitlenmeyecek.")

def kriz_penceresi_kapat(sebep: str = ""):
    """Pencereyi elle kapat (ornegin sunucudan acik kilit komutu gelince)."""
    if kriz_penceresi_kalan() > 0:
        _otp_persist('kriz_acik_until', 0)
        logging.warning(f"Kriz penceresi kapatildi: {sebep}")

def validate_kriz_password(entered_password: str) -> bool:
    """Kriz kodunu dogrula (dun/bugun/yarin). Kurum kodu config'ten gelir."""
    try:
        kurum = str(SETTINGS.get('corporate_code', '') or '').strip()
        if not kurum or not entered_password:
            return False
        bugun = simdi()
        for fark in (-1, 0, 1):
            if hmac.compare_digest(_kriz_kodu(kurum, bugun + timedelta(days=fark)), entered_password):
                logging.warning("KRIZ KODU ile acildi (sunucusuz acil giris).")
                kriz_penceresi_baslat()
                return True
        return False
    except Exception as e:
        logging.error(f"Kriz kodu dogrulama hatasi: {e}")
        return False

def validate_offline_password(entered_password: str) -> bool:
    """v6 tahta (device_token var) → TOTP; yoksa eski formül (C#/eski Pardus uyumu)."""
    if get_setting('device_token', ''):
        return validate_totp_password(entered_password)
    return validate_dynamic_password(entered_password)

# --- Kaba kuvvet kilidi (6 hane = 10^6; kilit olmadan taranabilir) ---
# Durum config.ini'de tutulur → tahtayı kapat-aç ile sıfırlanamaz.
def offline_lock_remaining() -> int:
    """Kalan kilit saniyesi (0 = kilit yok)."""
    try:
        until = int(SETTINGS.get('otp_lock_until', '0') or '0')
    except ValueError:
        until = 0
    rem = until - int(time.time())
    return rem if rem > 0 else 0

def _otp_persist(key: str, value) -> None:
    """SETTINGS + config.ini'ye yaz (reboot'a dayanıklı kilit durumu)."""
    SETTINGS[key] = str(value)
    try:
        cfg = configparser.ConfigParser()
        cfg.read(CONFIG_PATH)
        if 'settings' not in cfg:
            cfg.add_section('settings')
        cfg.set('settings', key, str(value))
        with open(CONFIG_PATH, 'w') as f:
            cfg.write(f)
    except Exception as e:
        logging.warning(f"OTP kilit durumu yazılamadı: {e}")

def offline_register_failure() -> None:
    """Yanlış deneme say; eşiğe gelince kilitle."""
    try:
        fails = int(SETTINGS.get('otp_fail_count', '0') or '0')
    except ValueError:
        fails = 0
    fails += 1
    if fails >= _OTP_MAX_FAILS:
        _otp_persist('otp_lock_until', int(time.time()) + _OTP_LOCK_SECONDS)
        _otp_persist('otp_fail_count', 0)
        logging.warning(f"Çok fazla yanlış şifre — {_OTP_LOCK_SECONDS//60} dk kilitlendi.")
    else:
        _otp_persist('otp_fail_count', fails)

def offline_register_success() -> None:
    """Başarılı açılışta sayaç + kilit sıfırla."""
    if SETTINGS.get('otp_fail_count', '0') != '0':
        _otp_persist('otp_fail_count', 0)
    if SETTINGS.get('otp_lock_until', '0') != '0':
        _otp_persist('otp_lock_until', 0)

# --- Generate User-Key like C# Tools.userKey() ---
# Key oluşturma kurum koduna bağlı yapıldı
def generate_user_key(corporate_code: str = None) -> str:
    """Generate a unique key based on corporate code (kurum kodu)"""
    if corporate_code is None:
        corporate_code = SETTINGS.get('corporate_code', '0')
    
    charset = "a?A)b(B*cCdD-eEf+FgGhHi[IjJkKm?MlLm]MnNoOpPrRs)StT1*23[456-7890"
    # Seed the random generator with corporate code for consistent keys per institution
    seed_value = sum(ord(c) for c in str(corporate_code))
    rng = random.Random(seed_value)
    part1 = ''.join(rng.choice(charset[0:len(charset)-1]) for _ in range(5))
    part2 = ''.join(rng.choice(charset[1:len(charset)-1]) for _ in range(4))
    part3 = ''.join(rng.choice(charset[2:len(charset)-1]) for _ in range(8))
    part4 = ''.join(rng.choice(charset[3:len(charset)-1]) for _ in range(8))
    return f"{part1}_{part2}_{part3}!{part4}"

# --- NEW: USB Check Function (equivalent to C# AcKapa) ---
def check_usb_password() -> bool:
    """
    Check if USB drive with correct password is present.
    Equivalent to C# AcKapa() function.
    """
    try:
        # Get all mounted filesystems
        with open('/proc/mounts', 'r') as f:
            mounts = f.readlines()
        
        usb_mounts_found = []
        for mount in mounts:
            parts = mount.split()
            if len(parts) >= 2:
                device = parts[0]
                mount_point = parts[1]
                
                # Skip system mount points
                if mount_point in ('/', '/boot', '/home') or mount_point.startswith('/sys') or mount_point.startswith('/proc') or mount_point.startswith('/dev'):
                    continue
                
                # Check if it's a block device (USB drives are /dev/sd*, /dev/usb*, etc.)
                if device.startswith('/dev/sd') or device.startswith('/dev/usb'):
                    # USB drives can be mounted in /media, /mnt, /run/media, or /tmp
                    if mount_point.startswith('/media') or mount_point.startswith('/mnt') or mount_point.startswith('/run/media') or mount_point.startswith('/tmp'):
                        usb_mounts_found.append(mount_point)
                        pass_file = os.path.join(mount_point, "pass.txt")
                        if os.path.exists(pass_file):
                            try:
                                # First try UTF-8 with BOM signature (handles standard notepad saves and Windows defaults properly)
                                try:
                                    with open(pass_file, 'r', encoding='utf-8-sig') as f:
                                        content = f.read().strip()
                                except UnicodeDecodeError:
                                    # Fallback to Turkish Windows encoding
                                    with open(pass_file, 'r', encoding='cp1254') as f:
                                        content = f.read().strip()
                                        
                                logging.info(f"USB pass.txt found at {mount_point}, content length: {len(content)}")
                                if content == USB_PASSWORD:
                                    logging.info(f"USB password MATCHED at {mount_point}")
                                    return True
                                else:
                                    logging.warning(f"USB pass.txt content does NOT match at {mount_point}. Expected len:{len(USB_PASSWORD)} Got len:{len(content)}")
                                    logging.debug(f"Expected: '{USB_PASSWORD}'")
                                    logging.debug(f"Got:      '{content}'")
                            except Exception as e:
                                logging.warning(f"Error reading pass.txt from {mount_point}: {e}")
                                continue
                        else:
                            logging.debug(f"No pass.txt at USB mount: {mount_point}")
        
        if usb_mounts_found:
            logging.info(f"USB mounts found but no valid password: {usb_mounts_found}")
        else:
            logging.debug("No USB drives detected in mount points")
        return False
        
    except Exception as e:
        logging.error(f"Error checking USB password: {e}")
        return False

# --- NEW: USB Remove Check Function (equivalent to C# Rsystm) ---
def check_usb_remove() -> bool:
    """
    Check if USB drive with remove command is present.
    Equivalent to C# Rsystm() function.
    """
    try:
        with open('/proc/mounts', 'r') as f:
            mounts = f.readlines()
        
        for mount in mounts:
            parts = mount.split()
            if len(parts) >= 2:
                device = parts[0]
                mount_point = parts[1]
                
                # Skip non-USB mount points
                if mount_point.startswith('/tmp') or mount_point.startswith('/sys') or mount_point.startswith('/proc'):
                    continue
                
                if device.startswith('/dev/sd') or device.startswith('/dev/usb'):
                    # USB drives are usually mounted in /media or /mnt
                    if not (mount_point.startswith('/media') or mount_point.startswith('/mnt') or mount_point.startswith('/run/media')):
                        continue
                        
                    remove_file = os.path.join(mount_point, "rmove.txt")
                    if os.path.exists(remove_file):
                        try:
                            try:
                                with open(remove_file, 'r', encoding='utf-8-sig') as f:
                                    content = f.read().strip()
                            except UnicodeDecodeError:
                                with open(remove_file, 'r', encoding='cp1254') as f:
                                    content = f.read().strip()
                                    
                            if content == USB_REMOVE_PASSWORD:
                                logging.info(f"USB remove command found at {mount_point}")
                                return True
                        except Exception as e:
                            logging.warning(f"Error reading rmove.txt from {mount_point}: {e}")
                            continue
        
        return False
        
    except Exception as e:
        logging.error(f"Error checking USB remove: {e}")
        return False

# --- Desktop Environment Detection (Pardus ETAP) ---
def detect_desktop_environment() -> str:
    """
    Çalışma zamanında masaüstü ortamını algıla.
    Pardus ETAP: GNOME (birincil), XFCE (eski tahtalar), Cinnamon (özel imajlar)
    """
    desktop = os.environ.get('XDG_CURRENT_DESKTOP', '').upper()
    session = os.environ.get('DESKTOP_SESSION', '').upper()
    
    if 'GNOME' in desktop or 'GNOME' in session:
        return 'GNOME'
    elif 'XFCE' in desktop or 'XFCE' in session:
        return 'XFCE'
    elif 'CINNAMON' in desktop or 'CINNAMON' in session:
        return 'CINNAMON'
    elif 'KDE' in desktop or 'KDE' in session:
        return 'KDE'
    
    # Fallback: process detection
    try:
        result = _subprocess.run(['pgrep', '-x', 'gnome-shell'], capture_output=True)
        if result.returncode == 0:
            return 'GNOME'
        result = _subprocess.run(['pgrep', '-x', 'xfce4-panel'], capture_output=True)
        if result.returncode == 0:
            return 'XFCE'
    except Exception:
        pass
    
    return 'UNKNOWN'

DESKTOP_ENV = detect_desktop_environment()
logging.info(f"Detected desktop environment: {DESKTOP_ENV}")


# --- Panel/Taskbar Manager (C# TastbarWindows.cs karşılığı) ---
class PanelManager:
    """
    Taskbar/panel gizleme/gösterme. Windows'taki TastbarWindows.cs karşılığı.
    GNOME ve XFCE için farklı komutlar kullanılır.
    """
    
    @staticmethod
    def hide():
        """Panel/taskbar'ı gizle - Cinnamon'da agresif xdotool + gsettings yöntemi"""
        if NO_LOCK_MODE:
            logging.info("[NO-LOCK] PanelManager.hide() skipped")
            return
        try:
            de = DESKTOP_ENV
            if de == 'GNOME':
                # GNOME Shell: Dock/Panel gizle
                cmds = [
                    ['gsettings', 'set', 'org.gnome.shell.extensions.dash-to-dock', 'dock-fixed', 'false'],
                    ['gsettings', 'set', 'org.gnome.shell.extensions.dash-to-dock', 'autohide', 'true'],
                    ['gsettings', 'set', 'org.gnome.shell.extensions.dash-to-dock', 'intellihide', 'false'],
                ]
                for cmd in cmds:
                    try:
                        _subprocess.run(cmd, capture_output=True, timeout=3)
                    except Exception:
                        pass
                try:
                    _subprocess.run(['gdbus', 'call', '--session',
                                     '--dest', 'org.gnome.Shell',
                                     '--object-path', '/org/gnome/Shell',
                                     '--method', 'org.gnome.Shell.Eval',
                                     'Main.panel.hide();'],
                                    capture_output=True, timeout=3)
                except Exception:
                    pass
            elif de == 'XFCE':
                try:
                    _subprocess.run(['xfconf-query', '-c', 'xfce4-panel',
                                     '-p', '/panels/panel-1/autohide-behavior', '-s', '2'],
                                    capture_output=True, timeout=3)
                except Exception:
                    pass
            elif de == 'CINNAMON':
                # Yöntem 1: gsettings ile panel'i gizle
                try:
                    _subprocess.run(['gsettings', 'set', 'org.cinnamon',
                                     'panels-autohide', "['1:true']"],
                                    capture_output=True, timeout=3)
                except Exception:
                    pass
                # Yöntem 2: xdotool ile cinnamon-panel penceresini ikonlaştır/gizle
                try:
                    result = _subprocess.run(
                        ['xdotool', 'search', '--name', 'Cinnamon'],
                        capture_output=True, text=True, timeout=3
                    )
                    for wid in result.stdout.strip().split():
                        _subprocess.run(['xdotool', 'windowminimize', wid],
                                       capture_output=True, timeout=2)
                except Exception:
                    pass
                # Yöntem 3: wmctrl ile cinnamon-panel'i en alta göm
                try:
                    _subprocess.run(
                        ['wmctrl', '-r', ':ACTIVE:', '-b', 'add,below'],
                        capture_output=True, timeout=2
                    )
                except Exception:
                    pass
            logging.info(f"Panel hidden ({de})")
        except Exception as e:
            logging.error(f"Error hiding panel: {e}")
    
    @staticmethod
    def show():
        """Panel/taskbar'ı göster"""
        try:
            de = DESKTOP_ENV
            if de == 'GNOME':
                cmds = [
                    ['gsettings', 'set', 'org.gnome.shell.extensions.dash-to-dock', 'dock-fixed', 'true'],
                    ['gsettings', 'set', 'org.gnome.shell.extensions.dash-to-dock', 'autohide', 'false'],
                ]
                for cmd in cmds:
                    try:
                        _subprocess.run(cmd, capture_output=True, timeout=3)
                    except Exception:
                        pass
                try:
                    _subprocess.run(['gdbus', 'call', '--session',
                                     '--dest', 'org.gnome.Shell',
                                     '--object-path', '/org/gnome/Shell',
                                     '--method', 'org.gnome.Shell.Eval',
                                     'Main.panel.show();'],
                                    capture_output=True, timeout=3)
                except Exception:
                    pass
            elif de == 'XFCE':
                try:
                    _subprocess.run(['xfconf-query', '-c', 'xfce4-panel',
                                     '-p', '/panels/panel-1/autohide-behavior', '-s', '0'],
                                    capture_output=True, timeout=3)
                except Exception:
                    pass
            elif de == 'CINNAMON':
                try:
                    _subprocess.run(['gsettings', 'set', 'org.cinnamon',
                                     'panels-autohide', "['1:false']"],
                                    capture_output=True, timeout=3)
                except Exception:
                    pass
            logging.info(f"Panel shown ({de})")
        except Exception as e:
            logging.error(f"Error showing panel: {e}")


# --- Volume Control (C# VD/VU/VM karşılığı) ---
class VolumeControl:
    """
    Ses kontrolü. Windows'taki SendMessageW VOLUME_MUTE/UP/DOWN karşılığı.
    PulseAudio (pactl) veya ALSA (amixer) kullanır.
    """
    
    @staticmethod
    def mute():
        """Sesi kapat (kilitlenme anında)"""
        try:
            cmds = [
                ['pactl', 'set-sink-mute', '@DEFAULT_SINK@', '1'],
                ['amixer', 'set', 'Master', 'mute'],
            ]
            for cmd in cmds:
                try:
                    result = _subprocess.run(cmd, capture_output=True, timeout=3)
                    if result.returncode == 0:
                        logging.info(f"Audio muted using {cmd[0]}")
                        return
                except FileNotFoundError:
                    continue
                except Exception:
                    continue
        except Exception as e:
            logging.error(f"Error muting audio: {e}")
    
    @staticmethod
    def unmute():
        """Sesi aç ve max yap (kilit açılınca)"""
        try:
            cmds_unmute = [
                ['pactl', 'set-sink-mute', '@DEFAULT_SINK@', '0'],
                ['amixer', 'set', 'Master', 'unmute'],
            ]
            cmds_volume = [
                ['pactl', 'set-sink-volume', '@DEFAULT_SINK@', '100%'],
                ['amixer', 'set', 'Master', '100%'],
            ]
            for cmd in cmds_unmute:
                try:
                    result = _subprocess.run(cmd, capture_output=True, timeout=3)
                    if result.returncode == 0:
                        logging.info(f"Audio unmuted using {cmd[0]}")
                        break
                except (FileNotFoundError, Exception):
                    continue
            for cmd in cmds_volume:
                try:
                    result = _subprocess.run(cmd, capture_output=True, timeout=3)
                    if result.returncode == 0:
                        logging.info(f"Volume set to max using {cmd[0]}")
                        break
                except (FileNotFoundError, Exception):
                    continue
        except Exception as e:
            logging.error(f"Error unmuting audio: {e}")


# --- Power Manager (C# powercfg karşılığı) ---
class PowerManager:
    """
    Güç yönetimi. Uyku modu / ekran kapanması devre dışı bırakma.
    """
    
    @staticmethod
    def disable_sleep():
        """Uyku modu ve ekran kapanmasını devre dışı bırak"""
        try:
            de = DESKTOP_ENV
            if de == 'GNOME':
                cmds = [
                    ['gsettings', 'set', 'org.gnome.settings-daemon.plugins.power',
                     'sleep-inactive-ac-type', 'nothing'],
                    ['gsettings', 'set', 'org.gnome.settings-daemon.plugins.power',
                     'sleep-inactive-battery-type', 'nothing'],
                    ['gsettings', 'set', 'org.gnome.desktop.session', 'idle-delay', '0'],
                    ['gsettings', 'set', 'org.gnome.desktop.screensaver', 'lock-enabled', 'false'],
                ]
                for cmd in cmds:
                    try:
                        _subprocess.run(cmd, capture_output=True, timeout=3)
                    except Exception:
                        pass
            elif de == 'XFCE':
                cmds = [
                    ['xfconf-query', '-c', 'xfce4-power-manager',
                     '-p', '/xfce4-power-manager/inactivity-on-ac', '-s', '0'],
                    ['xfconf-query', '-c', 'xfce4-power-manager',
                     '-p', '/xfce4-power-manager/dpms-enabled', '-s', 'false'],
                ]
                for cmd in cmds:
                    try:
                        _subprocess.run(cmd, capture_output=True, timeout=3)
                    except Exception:
                        pass
            
            # Genel: systemd-inhibit benzeri (tüm ortamlar)
            try:
                _subprocess.run(['xset', 's', 'off'], capture_output=True, timeout=3)
                _subprocess.run(['xset', '-dpms'], capture_output=True, timeout=3)
                _subprocess.run(['xset', 's', 'noblank'], capture_output=True, timeout=3)
            except Exception:
                pass
            
            logging.info(f"Sleep mode disabled ({de})")
        except Exception as e:
            logging.error(f"Error disabling sleep: {e}")


# --- Shortcut Manager (C# CtrlAltDel karşılığı) ---
class ShortcutManager:
    """
    Klavye kısayollarını devre dışı bırakma/geri yükleme.
    GNOME ve XFCE için farklı komutlar.
    """
    _saved_shortcuts = {}
    
    @classmethod
    def disable(cls):
        """Tehlikeli kısayolları devre dışı bırak (kilitlenme anında)"""
        if NO_LOCK_MODE:
            logging.info("[NO-LOCK] ShortcutManager.disable() skipped")
            return
        try:
            de = DESKTOP_ENV
            if de == 'GNOME':
                # Orijinal değerleri kaydet
                shortcuts_to_disable = {
                    'org.gnome.mutter overlay-key': "''",
                    'org.gnome.settings-daemon.plugins.media-keys logout': "''",
                    'org.gnome.desktop.wm.keybindings switch-to-workspace-up': "'[]'",
                    'org.gnome.desktop.wm.keybindings switch-to-workspace-down': "'[]'",
                    'org.gnome.desktop.wm.keybindings panel-main-menu': "'[]'",
                }
                for key, disable_val in shortcuts_to_disable.items():
                    parts = key.rsplit(' ', 1)
                    schema, prop = parts[0], parts[1]
                    try:
                        # Orijinal değeri kaydet
                        result = _subprocess.run(
                            ['gsettings', 'get', schema, prop],
                            capture_output=True, text=True, timeout=3)
                        if result.returncode == 0:
                            cls._saved_shortcuts[key] = result.stdout.strip()
                        
                        # Devre dışı bırak
                        _subprocess.run(
                            ['gsettings', 'set', schema, prop, disable_val],
                            capture_output=True, timeout=3)
                    except Exception:
                        pass
            
            elif de == 'XFCE':
                # XFCE kısayolları devre dışı bırakma
                try:
                    _subprocess.run(
                        ['xfconf-query', '-c', 'xfce4-keyboard-shortcuts',
                         '-p', '/commands/custom/super', '-s', ''],
                        capture_output=True, timeout=3)
                except Exception:
                    pass
            
            # Ortak: Ctrl+Alt+Del engelleme (systemd mask)
            try:
                _subprocess.run(
                    ['sudo', 'systemctl', 'mask', 'ctrl-alt-del.target'],
                    capture_output=True, timeout=3)
            except Exception:
                pass
            
            logging.info(f"Keyboard shortcuts disabled ({de})")
        except Exception as e:
            logging.error(f"Error disabling shortcuts: {e}")
    
    @classmethod
    def restore(cls):
        """Kısayolları geri yükle (kilit açılınca)"""
        try:
            de = DESKTOP_ENV
            if de == 'GNOME':
                for key, original_val in cls._saved_shortcuts.items():
                    parts = key.rsplit(' ', 1)
                    schema, prop = parts[0], parts[1]
                    try:
                        _subprocess.run(
                            ['gsettings', 'set', schema, prop, original_val],
                            capture_output=True, timeout=3)
                    except Exception:
                        pass
                cls._saved_shortcuts.clear()
            
            # Ctrl+Alt+Del geri yükle
            try:
                _subprocess.run(
                    ['sudo', 'systemctl', 'unmask', 'ctrl-alt-del.target'],
                    capture_output=True, timeout=3)
            except Exception:
                pass
            
            logging.info(f"Keyboard shortcuts restored ({de})")
        except Exception as e:
            logging.error(f"Error restoring shortcuts: {e}")


# --- Browser/App Killer (C# KillAllItem karşılığı) ---
def kill_all_browsers():
    """Tüm tarayıcıları ve system monitor uygulamalarını kapat."""
    targets = [
        'chromium', 'chromium-browser', 'firefox', 'firefox-esr',
        'google-chrome', 'opera', 'midori', 'epiphany',
        'gnome-system-monitor', 'xfce4-taskmanager',
        # NOT: Terminal emulatörleri listeden çıkarıldı.
        # Uygulama terminalden başlatıldığında terminali öldürmek uygulamayı da öldürür.
    ]
    for target in targets:
        try:
            _subprocess.run(['pkill', '-f', target], capture_output=True, timeout=3)
        except Exception:
            pass
    logging.info("All browsers and monitors killed")


# --- Embedded Numpad Widget ---
class EmbeddedNumpad(QWidget):
    def __init__(self, parent=None, on_enter_callback=None):
        super().__init__(parent)
        self.on_enter_callback = on_enter_callback
        self.target_field = None  # Doğrudan hedef alan referansı
        self.init_ui()

    def init_ui(self):
        self.setObjectName("embeddedNumpad")
        self.setStyleSheet("""
            QWidget#embeddedNumpad QPushButton {
                background-color: #444444;
                color: white;
                border: 1px solid #666;
                border-radius: 8px;
            }
            QWidget#embeddedNumpad QPushButton:hover {
                background-color: #5aa1e3;
            }
            QWidget#embeddedNumpad QPushButton:pressed {
                background-color: #0066cc;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 10, 0, 0)
        keyboard_layout = QGridLayout()

        # Numpad layout
        buttons = [
            ('1', 0, 0), ('2', 0, 1), ('3', 0, 2),
            ('4', 1, 0), ('5', 1, 1), ('6', 1, 2),
            ('7', 2, 0), ('8', 2, 1), ('9', 2, 2)
        ]

        for char, row, col in buttons:
            btn = QPushButton(char)
            btn.setMinimumSize(60, 60)
            btn.setFont(QFont("Arial", 16, QFont.Weight.Bold))
            btn.setFocusPolicy(Qt.NoFocus)
            btn.clicked.connect(lambda checked, c=char: self.add_char(c))
            keyboard_layout.addWidget(btn, row, col)

        backspace_btn = QPushButton("⌫")
        backspace_btn.setMinimumSize(60, 60)
        backspace_btn.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        backspace_btn.setFocusPolicy(Qt.NoFocus)
        backspace_btn.clicked.connect(self.backspace)
        keyboard_layout.addWidget(backspace_btn, 3, 0)

        zero_btn = QPushButton("0")
        zero_btn.setMinimumSize(60, 60)
        zero_btn.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        zero_btn.setFocusPolicy(Qt.NoFocus)
        zero_btn.clicked.connect(lambda checked, c="0": self.add_char(c))
        keyboard_layout.addWidget(zero_btn, 3, 1)

        enter_btn = QPushButton("Enter")
        enter_btn.setMinimumSize(60, 60)
        enter_btn.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        enter_btn.setStyleSheet("background-color: #0066cc; color: white;")
        enter_btn.setFocusPolicy(Qt.NoFocus)
        enter_btn.clicked.connect(self.enter_text)
        keyboard_layout.addWidget(enter_btn, 3, 2)

        layout.addLayout(keyboard_layout)
        
        control_layout = QHBoxLayout()
        clear_btn = QPushButton("Temizle")
        clear_btn.setMinimumHeight(40)
        clear_btn.setFocusPolicy(Qt.NoFocus)
        clear_btn.clicked.connect(self.clear_text)
        control_layout.addWidget(clear_btn)
        layout.addLayout(control_layout)

    def set_target(self, field):
        """Numpad'in yazmak için kullanacağı QLineEdit alanını ayarla"""
        self.target_field = field

    def _get_field(self):
        """Hedef alanı döndür: önce sabit referans, yoksa focus'taki alan"""
        if self.target_field is not None:
            return self.target_field
        # Fallback: focus'taki QLineEdit
        focus_w = QApplication.focusWidget()
        if isinstance(focus_w, QLineEdit):
            return focus_w
        return None

    def add_char(self, char):
        w = self._get_field()
        if w:
            w.insert(char)

    def backspace(self, checked=False):
        w = self._get_field()
        if w:
            w.backspace()

    def clear_text(self, checked=False):
        w = self._get_field()
        if w:
            w.clear()

    def enter_text(self, checked=False):
        if self.on_enter_callback:
            self.on_enter_callback()
        else:
            w = self._get_active_field()
            if w and hasattr(w, '_on_enter_callback') and w._on_enter_callback:
                w._on_enter_callback()

# --- Simplified LineEdit ---
class KeyboardLineEdit(QLineEdit):
    def __init__(self, parent=None, on_enter_callback=None):
        super().__init__(parent)
        self._on_enter_callback = on_enter_callback

    def set_on_enter_callback(self, callback):
        self._on_enter_callback = callback
        
    def keyPressEvent(self, event):
        super().keyPressEvent(event)
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            if self._on_enter_callback:
                self._on_enter_callback()

# --- Login Dialog ---
class LoginDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Sistem Girişi")
        self.setModal(True)
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.Tool)
        logging.info("LoginDialog UI initialized")

        layout = QVBoxLayout()

        # Title
        title = QLabel("Yönetici Girişi")
        title.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # Password field
        self.password_field = KeyboardLineEdit()
        self.password_field.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_field.setPlaceholderText("Mebrecep den şifre yazınız")
        self.password_field.setFont(QFont("Arial", 14))
        self.password_field.set_on_enter_callback(self.attempt_login)
        layout.addWidget(self.password_field)

        # Embedded Numpad
        self.numpad = EmbeddedNumpad(on_enter_callback=self.attempt_login)
        self.numpad.set_target(self.password_field)  # Numpad şifre alanına yazsın
        layout.addWidget(self.numpad)

        # Buttons
        button_layout = QHBoxLayout()

        cancel_btn = QPushButton("İptal")
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)

        login_btn = QPushButton("Tahtayı Aç")
        login_btn.clicked.connect(self.attempt_login)
        login_btn.setDefault(True)
        button_layout.addWidget(login_btn)

        layout.addLayout(button_layout)
        self.setLayout(layout)
        
        # Ensure the focus is actually placed on the password field
        # so the onscreen keyboard logic or physical typing fires
        QTimer.singleShot(100, self.password_field.setFocus)

    def attempt_login(self, checked=False):
        password = self.password_field.text()
        logging.info(f"Login attempt with password: {'*' * len(password)}")
        
        if self.parent.validate_admin_password(password):
            logging.info("Password validated successfully")
            # NOT: burada SEBEPSIZ ack ATILMAZ. Sunucu "yerel acilis" kaydini open_close
            # 1->0 gecisinde yaziyor; sebepsiz ack once gidince gecis orada tuketiliyor,
            # unlock_system'in sebepli ack'i "degisiklik yok" sayilip sebep KAYBOLUYORDU.
            # Ack'i tek yerden, sebebiyle birlikte unlock_system gonderir.
            _y = getattr(self.parent, 'son_acilis_yontemi', 'Admin sifresi')
            self.parent.save_log("Admin şifre ile giriş yapıldı", "login")
            self.parent.unlock_system(f"{_y} ile acildi")
            self.accept()
        else:
            logging.warning("Invalid password entered")
            QMessageBox.warning(self, "Hata", "Geçersiz şifre!")
            self.password_field.clear()

# --- Board Configuration Dialog ---
class BoardConfigWidget(QWidget):
    def __init__(self, parent=None, network_client=None, close_callback=None):
        super().__init__(parent)
        self.parent = parent
        self.network_client = network_client
        self.close_callback = close_callback
        self.boards = []
        self.init_ui()
        self._connect_focus_tracking()

    def init_ui(self):
        self.setMinimumWidth(480)
        
        layout = QVBoxLayout()
        layout.setSpacing(12)
        layout.setContentsMargins(25, 20, 25, 20)

        # Title
        title = QLabel("Tahta Yapılandırması")
        title.setFont(QFont("Arial", 18, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # Form layout - labellar sağ yaslı, textboxlar hizalı
        form_layout = QFormLayout()
        form_layout.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        form_layout.setFormAlignment(Qt.AlignCenter)
        form_layout.setSpacing(10)
        form_layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)

        # Corporate code input - görünür şekilde gelecek
        corporate_label = QLabel("Kurum Kodu:")
        corporate_label.setFont(QFont("Arial", 12))
        self.corporate_code_field = KeyboardLineEdit()
        self.corporate_code_field.set_on_enter_callback(self.fetch_boards)
        self.corporate_code_field.setText(SETTINGS.get('corporate_code', ''))
        self.corporate_code_field.setMinimumWidth(250)
        self.corporate_code_field.setMinimumHeight(35)
        self.corporate_code_field.setFont(QFont("Arial", 12))
        form_layout.addRow(corporate_label, self.corporate_code_field)

        # Password input - admin şifresi zorunlu
        password_label = QLabel("Şifre:")
        password_label.setFont(QFont("Arial", 12))
        self.password_field = KeyboardLineEdit()
        self.password_field.set_on_enter_callback(self.fetch_boards)
        self.password_field.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_field.setPlaceholderText("Admin şifresini giriniz")
        self.password_field.setMinimumWidth(250)
        self.password_field.setMinimumHeight(35)
        self.password_field.setFont(QFont("Arial", 12))
        form_layout.addRow(password_label, self.password_field)

        layout.addLayout(form_layout)

        # Fetch boards button
        self.fetch_btn = QPushButton("Tahtaları Getir")
        self.fetch_btn.setMinimumHeight(40)
        self.fetch_btn.setFont(QFont("Arial", 11, QFont.Weight.Bold))
        self.fetch_btn.clicked.connect(self.fetch_boards)
        layout.addWidget(self.fetch_btn)

        # Geri Bildirim mesajları için QMessageBox yerine inline etiket kullanacağız (X11 kilitlenme hatasını çözer!)
        self.status_label = QLabel("")
        self.status_label.setFont(QFont("Arial", 11, QFont.Weight.Bold))
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setMinimumHeight(30)
        self.status_label.setStyleSheet("color: #ffaa00;")
        layout.addWidget(self.status_label)

        # Alt Kısım: Sol tarafta küçültülmüş numpad, sağ tarafta liste
        bottom_layout = QHBoxLayout()
        bottom_layout.setSpacing(20)

        # Sol taraf: Embedded Numpad (Genişliği enter tuşu sığacak kadar artırıldı)
        self.numpad = EmbeddedNumpad(on_enter_callback=self.fetch_boards)
        self.numpad.setMaximumWidth(320)  # Enter tam sığsın
        self.numpad.set_target(self.password_field)  # Numpad şifre alanına yazsın
        QTimer.singleShot(100, self.password_field.setFocus)
        bottom_layout.addWidget(self.numpad, stretch=10)

        # Sağ taraf: Tahta Listesi (QListWidget) - Popup olmadan, sabit yanda
        list_container = QVBoxLayout()
        list_container.setSpacing(5)
        
        board_label = QLabel("Sağdan Tahtanızı Seçin:")
        board_label.setFont(QFont("Arial", 11, QFont.Weight.Bold))
        list_container.addWidget(board_label)

        self.board_list_widget = QListWidget()
        self.board_list_widget.setFont(QFont("Arial", 12))
        self.board_list_widget.setStyleSheet("""
            QListWidget {
                background-color: #ffffff;
                color: #000000;
                border: 2px solid #555;
                border-radius: 5px;
            }
            QListWidget::item {
                padding: 10px 12px;
                border-bottom: 1px solid #ddd;
            }
            QListWidget::item:selected {
                background-color: #0066cc;
                color: white;
                font-weight: bold;
            }
        """)
        list_container.addWidget(self.board_list_widget)
        bottom_layout.addLayout(list_container, stretch=11) # Liste ile tuş takımı oranları dengelendi
        
        layout.addLayout(bottom_layout)

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)

        cancel_btn = QPushButton("İptal")
        cancel_btn.setMinimumHeight(45)
        cancel_btn.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        cancel_btn.clicked.connect(self.close_widget)
        button_layout.addWidget(cancel_btn)

        confirm_btn = QPushButton("Onayla")
        confirm_btn.setMinimumHeight(45)
        confirm_btn.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        confirm_btn.clicked.connect(self.confirm_selection)
        confirm_btn.setDefault(True)
        button_layout.addWidget(confirm_btn)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def _connect_focus_tracking(self):
        """Input alanlarına focus geldiğinde numpad hedefini güncelle"""
        for field in [self.corporate_code_field, self.password_field]:
            field.installEventFilter(self)

    def eventFilter(self, obj, event):
        """QLineEdit focus olduğunda numpad hedefini güncelle"""
        if event.type() == event.Type.FocusIn and isinstance(obj, QLineEdit):
            self.numpad.set_target(obj)
            self.status_label.setText("") # Mesajı temizle
        return super().eventFilter(obj, event)

    def wheelEvent(self, event):
        """Scroll event'leri BoardConfigWidget içinde tut.
        Listenin sonunda/başında wheel event parent'a sızmasını engelle."""
        event.accept()

    def close_widget(self, *args, **kwargs):
        if self.close_callback:
            self.close_callback()

    def fetch_boards(self, checked=False):
        logging.info("[BoardConfig] fetch_boards called")
        self.status_label.setText("")

        corporate_code = self.corporate_code_field.text().strip()
        if not corporate_code:
            self.status_label.setStyleSheet("color: #ff5555;")
            self.status_label.setText("Hata: Kurum kodu gerekli!")
            return

        # Şifre zorunlu kontrolü
        password = self.password_field.text().strip()
        if not password:
            self.status_label.setStyleSheet("color: #ff5555;")
            self.status_label.setText("Hata: Şifre gerekli!")
            return

        # Şifre doğrulama — PBKDF2 veya eski düz metin (bkz. admin_sifre_dogru)
        if not admin_sifre_dogru(password):
            self.status_label.setStyleSheet("color: #ff5555;")
            self.status_label.setText("Hata: Şifre yanlış!")
            return

        # İlk kurulumda şifre değiştirilmemiş ise uyarı ver
        password_changed = SETTINGS.get('password_changed', 'false').lower() == 'true'
        if not password_changed:
            self.status_label.setStyleSheet("color: #ffaa00;")
            self.status_label.setText("Önce sağ tıklayıp şifrenizi değiştiriniz!")
            return

        if not self.network_client:
            self.status_label.setStyleSheet("color: #ff5555;")
            self.status_label.setText("Hata: Ağ modülü başlatılamadı!")
            return

        self.status_label.setStyleSheet("color: #00aaff;")
        self.status_label.setText("Sunucuya bağlanılıyor, lütfen bekleyin...")
        QApplication.processEvents() # UI'ı güncelle

        # v6: liste kurulum-ani /boards'tan gelir (X-Enroll-Secret). Cihaz token'i henuz yok.
        try:
            items = self.network_client.list_boards(corporate_code)

            if items is not None:
                if items and len(items) > 0:
                    self.boards = items
                    self.board_list_widget.clear()
                    for board in items:
                        board_id = board.get("boardId", "N/A")
                        board_name = board.get("name") or f"Tahta {board_id}"
                        pasif = "" if board.get("aktif", 1) else " (pasif)"
                        item = QListWidgetItem(f"{board_id} - {board_name}{pasif}")
                        item.setData(Qt.UserRole, board_id)
                        self.board_list_widget.addItem(item)

                    self.board_list_widget.setCurrentRow(0)

                    self.status_label.setStyleSheet("color: #55ff55;")
                    self.status_label.setText(f"Başarılı! {len(items)} tahta bulundu. Lütfen sağdan seçin.")
                else:
                    self.status_label.setStyleSheet("color: #ffaa00;")
                    self.status_label.setText("Uyarı: Bu kurum için tahta bulunamadı.")
            else:
                # Teknisyen sahada ne yapacagini EKRANDAN gorsun: eskiden her sebep icin
                # ayni cumle yaziliyordu ve hata ancak sunucu loglarindan bulunabiliyordu.
                _h = getattr(self.network_client, 'son_enroll_hata', '')
                if not get_setting('enroll_secret', '') and not get_setting('device_token', ''):
                    _msg = "Hata: Kurulum dosyası eksik. Tahtanın yeniden kurulması gerekiyor."
                elif _h == "401":
                    _msg = "Hata: Kurulum kodu geçersiz (401). Kurulum medyası güncel değil."
                elif _h == "403":
                    _msg = "Hata: Bu tahta bu kuruma ait değil (403). Kurum kodunu kontrol edin."
                elif _h == "500":
                    _msg = "Hata: Sunucu yapılandırması eksik (500). Mebre'yi arayın."
                elif _h == "404":
                    _msg = "Hata: Sunucuda bu servis yok (404). Mebre'yi arayın."
                elif _h == "ssl":
                    _msg = "Hata: Güvenli bağlantı kurulamadı. Okul ağı engelliyor olabilir."
                elif _h == "ag":
                    _msg = "Hata: İnternet yok. Ağ bağlantısını kontrol edin."
                else:
                    _msg = "Hata: Sunucudan tahta listesi alınamadı."
                self.status_label.setStyleSheet("color: #ff5555;")
                self.status_label.setText(_msg)
        except Exception as e:
            logging.error(f"[BoardConfig] fetch_boards failed: {e}")
            self.status_label.setStyleSheet("color: #ff5555;")
            self.status_label.setText("Hata: Ağ hatası oluştu.")

    def confirm_selection(self, checked=False):
        logging.info("[BoardConfig] confirm_selection called")
        
        selected_item = self.board_list_widget.currentItem()
        if not selected_item:
            self.status_label.setStyleSheet("color: #ff5555;")
            self.status_label.setText("Hata: Sağdaki listeden bir tahta seçiniz!")
            return

        selected_board_id = selected_item.data(Qt.UserRole)
        if selected_board_id is None:
            self.status_label.setStyleSheet("color: #ff5555;")
            self.status_label.setText("Hata: Listeden bir tahta seçiniz!")
            return

        # Find board name
        board_name = "Pardus Tahta"
        for board in self.boards:
            if board.get("boardId") == selected_board_id:
                board_name = board.get("name") or f"Tahta {selected_board_id}"
                break

        corporate_code = self.corporate_code_field.text().strip()

        # v6: tahta secildi -> cihaz token'i uret (/enroll). Token OLMADAN config yazMA;
        # yarim yazilirsa tahta kimliksiz kalir ve fail-safe ile kilitli acilir (sebebi de gorunmez).
        self.status_label.setStyleSheet("color: #00aaff;")
        self.status_label.setText("Tahta tanıtılıyor, lütfen bekleyin...")
        QApplication.processEvents()

        device_token = self.network_client.enroll(corporate_code, selected_board_id, board_name)
        if not device_token:
            self.status_label.setStyleSheet("color: #ff5555;")
            self.status_label.setText("Hata: Tahta tanıtılamadı! Ayarlar kaydedilmedi.")
            return

        token_enc = 'ENC:' + _b64.b64encode(device_token.encode('utf-8')).decode('ascii')
        device_token = None  # zero-footprint: token'i RAM'de tutma, config'ten okunacak

        # Update configuration
        config = configparser.ConfigParser()
        config.read(CONFIG_PATH)
        config.set('settings', 'corporate_code', corporate_code)
        config.set('settings', 'board_id', str(selected_board_id))
        config.set('settings', 'board_name', board_name)
        config.set('settings', 'device_token', token_enc)
        config.remove_option('settings', 'enroll_secret')

        try:
            with open(CONFIG_PATH, 'w') as configfile:
                config.write(configfile)

            # Sistem geneline de yaz (kiosk mode için - fatih-kiosk kullanıcısı buradan okur)
            system_config_path = "/opt/fatih-client/config.ini"
            try:
                sys_config = configparser.ConfigParser()
                sys_config.read(system_config_path)
                if 'settings' not in sys_config:
                    sys_config.add_section('settings')
                sys_config.set('settings', 'corporate_code', corporate_code)
                sys_config.set('settings', 'board_id', str(selected_board_id))
                sys_config.set('settings', 'board_name', board_name)
                sys_config.set('settings', 'device_token', token_enc)
                sys_config.remove_option('settings', 'enroll_secret')
                with open(system_config_path, 'w') as f:
                    sys_config.write(f)
                logging.info(f"System-wide config updated at {system_config_path}")
            except Exception as e:
                logging.warning(f"Could not update system-wide config: {e}")
                # Sistem config güncellenemezse bile devam et

            # Kiosk kullanıcısının config'ini de güncelle (varsa)
            kiosk_config_path = "/home/fatih-kiosk/.config/fatih-client/config.ini"
            try:
                kiosk_dir = os.path.dirname(kiosk_config_path)
                os.makedirs(kiosk_dir, exist_ok=True)
                kiosk_config = configparser.ConfigParser()
                kiosk_config.read(system_config_path)  # Sistem config'ini baz al
                kiosk_config.set('settings', 'corporate_code', corporate_code)
                kiosk_config.set('settings', 'board_id', str(selected_board_id))
                kiosk_config.set('settings', 'board_name', board_name)
                kiosk_config.set('settings', 'device_token', token_enc)
                kiosk_config.remove_option('settings', 'enroll_secret')
                with open(kiosk_config_path, 'w') as f:
                    kiosk_config.write(f)
                logging.info(f"Kiosk user config updated at {kiosk_config_path}")
            except Exception as e:
                logging.warning(f"Could not update kiosk user config: {e}")

            # Update current SETTINGS in memory
            SETTINGS['corporate_code'] = corporate_code
            SETTINGS['board_id'] = str(selected_board_id)
            SETTINGS['board_name'] = board_name
            # Token hemen devreye girsin (yeniden baslatma beklemeden poll calissin).
            SETTINGS['device_token'] = token_enc
            # Sir gorevini tamamladi: bellekten de dusur (artik cihaza ozel token var).
            try:
                del SETTINGS['enroll_secret']
            except KeyError:
                pass

            # Update board ID display on main window
            if hasattr(self.parent, 'update_board_id_display'):
                self.parent.update_board_id_display()

            self.status_label.setStyleSheet("color: #55ff55; font-size: 13px;")
            self.status_label.setText(f"Başarılı! Tahta Ayarlandı:\nID: {selected_board_id} - Ad: {board_name}")
            
            # Kilit ekranında pencereyi düzgünce kapatmak için 1.5 sn bekle
            QTimer.singleShot(1500, self.close_widget)

        except PermissionError:
            QMessageBox.critical(self, "İzin Hatası",
                                 f"Yapılandırma dosyası kaydedilemedi: '{CONFIG_PATH}'.\n"
                                 "Ayarları değiştirmek için lütfen uygulamayı yönetici olarak çalıştırın (örn. 'sudo').")
        except Exception as e:
            QMessageBox.warning(self, "Hata", f"Yapılandırma kaydedilemedi: {e}")


# --- Change Password Dialog ---
class ChangePasswordWidget(QWidget):
    def __init__(self, parent=None, close_callback=None):
        super().__init__(parent)
        self.parent = parent
        self.close_callback = close_callback
        self.init_ui()
        self._connect_focus_tracking()

    def init_ui(self):
        self.setMinimumWidth(450)

        layout = QVBoxLayout()
        layout.setSpacing(12)
        layout.setContentsMargins(25, 20, 25, 20)

        # Title
        title = QLabel("Admin Şifresini Değiştir")
        title.setFont(QFont("Arial", 18, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # Form layout - labellar sağ yaslı, textboxlar hizalı
        form_layout = QFormLayout()
        form_layout.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        form_layout.setFormAlignment(Qt.AlignCenter)
        form_layout.setSpacing(10)
        form_layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)

        # Current password
        current_label = QLabel("Mevcut Şifre:")
        current_label.setFont(QFont("Arial", 12))
        self.current_field = KeyboardLineEdit()
        self.current_field.set_on_enter_callback(self.change_password)
        self.current_field.setMinimumWidth(250)
        self.current_field.setMinimumHeight(35)
        self.current_field.setFont(QFont("Arial", 12))
        
        # Mevcut şifre gösterimi mantığı — hash'li saklamada şifre OKUNAMAZ,
        # yalnızca "fabrika şifresi mi" sorusu cevaplanabilir.
        self._is_default_password = admin_sifre_varsayilan_mi()
        
        if self._is_default_password:
            # Varsayılan şifre: göster ve readOnly yap (kullanıcı değiştirmesin)
            self.current_field.setEchoMode(QLineEdit.EchoMode.Normal)
            self.current_field.setText('803580')
            self.current_field.setReadOnly(True)
            self.current_field.setStyleSheet("background-color: #e0e0e0; color: #333;")
        else:
            # Özel şifre: gizle, kullanıcı girsin
            self.current_field.setEchoMode(QLineEdit.EchoMode.Password)
            self.current_field.setText('')
            
        form_layout.addRow(current_label, self.current_field)

        # New password
        new_label = QLabel("Yeni Şifre:")
        new_label.setFont(QFont("Arial", 12))
        self.new_field = KeyboardLineEdit()
        self.new_field.set_on_enter_callback(self.change_password)
        self.new_field.setEchoMode(QLineEdit.EchoMode.Password)
        self.new_field.setMinimumWidth(250)
        self.new_field.setMinimumHeight(35)
        self.new_field.setFont(QFont("Arial", 12))
        form_layout.addRow(new_label, self.new_field)

        # Confirm password
        confirm_label = QLabel("Yeni Şifre (Tekrar):")
        confirm_label.setFont(QFont("Arial", 12))
        self.confirm_field = KeyboardLineEdit()
        self.confirm_field.set_on_enter_callback(self.change_password)
        self.confirm_field.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_field.setMinimumWidth(250)
        self.confirm_field.setMinimumHeight(35)
        self.confirm_field.setFont(QFont("Arial", 12))
        form_layout.addRow(confirm_label, self.confirm_field)

        layout.addLayout(form_layout)

        # Embedded Numpad
        self.numpad = EmbeddedNumpad(on_enter_callback=self.change_password)
        layout.addWidget(self.numpad)
        # Varsayılan şifrede numpad doğrudan "Yeni Şifre" alanına yazsın
        if self._is_default_password:
            self.numpad.set_target(self.new_field)
            QTimer.singleShot(100, self.new_field.setFocus)
        else:
            self.numpad.set_target(self.current_field)

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)

        cancel_btn = QPushButton("İptal")
        cancel_btn.setMinimumHeight(40)
        cancel_btn.setFont(QFont("Arial", 11))
        cancel_btn.clicked.connect(self.close_widget)
        button_layout.addWidget(cancel_btn)

        change_btn = QPushButton("Değiştir")
        change_btn.setMinimumHeight(40)
        change_btn.setFont(QFont("Arial", 11, QFont.Weight.Bold))
        change_btn.clicked.connect(self.change_password)
        change_btn.setDefault(True)
        button_layout.addWidget(change_btn)

        # Status label
        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #ff4444; font-size: 13px; font-weight: bold;")
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def _connect_focus_tracking(self):
        """Input alanlarına focus geldiğinde numpad hedefini güncelle"""
        for field in [self.current_field, self.new_field, self.confirm_field]:
            field.installEventFilter(self)

    def eventFilter(self, obj, event):
        """QLineEdit focus olduğunda numpad hedefini güncelle"""
        if event.type() == event.Type.FocusIn and isinstance(obj, QLineEdit):
            self.numpad.set_target(obj)
        return super().eventFilter(obj, event)

    def close_widget(self, *args, **kwargs):
        if self.close_callback:
            self.close_callback()

    def change_password(self, checked=False):
        logging.info("[ChangePassword] change_password called")
        current = self.current_field.text()
        new = self.new_field.text()
        confirm = self.confirm_field.text()
        logging.info(f"[ChangePassword] fields: current_len={len(current)}, new_len={len(new)}, confirm_len={len(confirm)}")

        if not current or not new or not confirm:
            self.status_label.setStyleSheet("color: #ff4444; font-size: 15px; font-weight: bold;")
            self.status_label.setText("Hata: Tüm alanları doldurun!")
            logging.warning("[ChangePassword] Empty fields detected")
            return

        # Mevcut şifre doğrulama — PBKDF2 veya eski düz metin
        if not admin_sifre_dogru(current):
            self.status_label.setStyleSheet("color: #ff4444; font-size: 15px; font-weight: bold;")
            self.status_label.setText("Hata: Mevcut şifre yanlış!")
            logging.warning("[ChangePassword] Wrong current password")
            return

        if new != confirm:
            self.status_label.setStyleSheet("color: #ff4444; font-size: 15px; font-weight: bold;")
            self.status_label.setText("Hata: Yeni şifreler eşleşmiyor!")
            logging.warning("[ChangePassword] Password mismatch")
            return

        if len(new) < 4:
            self.status_label.setStyleSheet("color: #ff4444; font-size: 15px; font-weight: bold;")
            self.status_label.setText("Hata: Şifre en az 4 karakter olmalı!")
            logging.warning("[ChangePassword] Password too short")
            return

        if new == '803580':
            self.status_label.setStyleSheet("color: #ff4444; font-size: 15px; font-weight: bold;")
            self.status_label.setText("Hata: Varsayılan şifre ile aynı olamaz!")
            logging.warning("[ChangePassword] Default password rejected")
            return

        # Update configuration
        config = configparser.ConfigParser()
        config.read(CONFIG_PATH)
        # Sifre ARTIK DUZ METIN SAKLANMIYOR (bkz. admin_sifre_uret).
        new_saklanan = admin_sifre_uret(new)
        config.set('settings', 'admin_password', new_saklanan)
        config.set('settings', 'password_changed', 'true')

        try:
            with open(CONFIG_PATH, 'w') as configfile:
                config.write(configfile)
            logging.info(f"[ChangePassword] Config saved to {CONFIG_PATH}")

            # Sistem geneline de yaz (kiosk mode için)
            system_config_path = "/opt/fatih-client/config.ini"
            try:
                sys_config = configparser.ConfigParser()
                sys_config.read(system_config_path)
                if 'settings' not in sys_config:
                    sys_config.add_section('settings')
                sys_config.set('settings', 'admin_password', new_saklanan)
                sys_config.set('settings', 'password_changed', 'true')
                with open(system_config_path, 'w') as f:
                    sys_config.write(f)
                logging.info(f"[ChangePassword] System-wide config updated at {system_config_path}")
            except Exception as e:
                logging.warning(f"[ChangePassword] Could not update system-wide config: {e}")

            # Kiosk kullanıcısının config'ini de güncelle
            kiosk_config_path = "/home/fatih-kiosk/.config/fatih-client/config.ini"
            try:
                kiosk_config = configparser.ConfigParser()
                kiosk_config.read(kiosk_config_path)
                if 'settings' not in kiosk_config:
                    kiosk_config.add_section('settings')
                kiosk_config.set('settings', 'admin_password', new_saklanan)
                kiosk_config.set('settings', 'password_changed', 'true')
                with open(kiosk_config_path, 'w') as f:
                    kiosk_config.write(f)
                logging.info(f"[ChangePassword] Kiosk config updated at {kiosk_config_path}")
            except Exception as e:
                logging.warning(f"[ChangePassword] Could not update kiosk config: {e}")

            # Update current SETTINGS
            SETTINGS['admin_password'] = new_saklanan
            SETTINGS['password_changed'] = 'true'

            # Log kaydet - parent üzerinden güvenli erişim
            try:
                if hasattr(self.parent, 'save_log'):
                    self.parent.save_log("Admin şifresi değiştirildi", "security")
            except Exception as e:
                logging.warning(f"[ChangePassword] save_log failed: {e}")
            
            logging.info("[ChangePassword] Password changed successfully!")
            self.status_label.setStyleSheet("color: #00ff88; font-weight: bold; font-size: 15px;")
            self.status_label.setText("✓ Şifre başarıyla değiştirildi!")
            
            # 1.5 saniye sonra overlay'i kapat
            QTimer.singleShot(1500, self.close_widget)

        except PermissionError:
            logging.error("[ChangePassword] PermissionError writing config")
            self.status_label.setStyleSheet("color: #ff4444; font-size: 15px; font-weight: bold;")
            self.status_label.setText("Yapılandırma yetkisi yok (sudo gerekir)!")
        except Exception as e:
            logging.error(f"[ChangePassword] Exception: {e}")
            self.status_label.setStyleSheet("color: #ff4444; font-size: 15px; font-weight: bold;")
            self.status_label.setText(f"Hata: {str(e)[:30]}")


# --- YENİ: Kilit Ekranı İçinde Çalışan Overlay (HİÇ yeni pencere açmıyor) ---
class LockScreenOverlay(QFrame):
    """
    Kilit ekranının kendi üzerine yerleştirilen bir child widget.
    QDialog/QMessageBox gibi ayrı bir pencere OLMADIĞI için
    lockscreen hiç kapanmıyor, hiç titresmiyor.
    """
    def __init__(self, parent, title="", content_widget=None, text=""):
        super().__init__(parent)
        self.setStyleSheet("""
            LockScreenOverlay {
                background-color: rgba(20, 20, 35, 240);
                border: 2px solid #0066cc;
                border-radius: 15px;
            }
            QLabel { color: white; background: transparent; }
            QPushButton {
                background-color: #0066cc; color: white;
                border-radius: 6px; padding: 8px 20px;
                font-size: 14px; font-weight: bold;
            }
            QPushButton:hover { background-color: #0052aa; }
        """)
        self.setAttribute(Qt.WA_StyledBackground, True)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(25, 20, 25, 20)
        layout.setSpacing(12)

        # Başlık
        title_lbl = QLabel(title)
        title_lbl.setFont(QFont('DejaVu Sans', 16, QFont.Bold))
        title_lbl.setAlignment(Qt.AlignCenter)
        title_lbl.setStyleSheet("color: #00ccff; margin-bottom: 5px;")
        layout.addWidget(title_lbl)

        # İçerik (metin ya da widget)
        if content_widget:
            layout.addWidget(content_widget)
        elif text:
            text_lbl = QLabel(text)
            text_lbl.setWordWrap(True)
            text_lbl.setFont(QFont('DejaVu Sans', 12))
            text_lbl.setAlignment(Qt.AlignLeft | Qt.AlignTop)
            text_lbl.setStyleSheet("color: #e0e0e0; font-size: 13px;")
            layout.addWidget(text_lbl)

        # Kapat butonu
        close_btn = QPushButton("Kapat")
        close_btn.setMinimumHeight(40)
        close_btn.clicked.connect(self.close_overlay)
        layout.addWidget(close_btn)

        # Boyut ve konum — ekran ortasına yerleştir
        self.setMinimumWidth(480)
        self.adjustSize()
        self._reposition()
        self.show()

    def _reposition(self):
        p = self.parent()
        if p:
            self.adjustSize()
            x = (p.width() - self.width()) // 2
            y = (p.height() - self.height()) // 2
            self.move(x, y)

    def close_overlay(self, *args, **kwargs):
        self.hide()
        self.deleteLater()
        # X11'de parent üzerinde raise_() veya activateWindow() çağırmak, Cinnamon WM'nin 
        # BypassWindow olarak ayarlanmış pencereyi tamamen un-map etmesine (gizlemesine) neden oluyor.
        # Overlay sadece bir QFrame olduğu için parent hiçbir zaman gerçek bir X11 focus'u kaybetmiş olmadığından
        # odak geri alma koduna gerek yoktur.

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.close_overlay()
        else:
            super().keyPressEvent(event)

    def wheelEvent(self, event):
        """Scroll event'leri overlay içinde tut, parent kilit ekranına sızdırma.
        QListWidget listenin sonuna/başına geldiğinde event'i parent'a sızdırabilir,
        bu da kilit ekranının tetiklenmesine veya focus kaybına yol açar."""
        event.accept()

# --- Schedule Display Dialog (C# FormGirisCikisSaatleri karşılığı) ---
class ScheduleDialog(QDialog):
    """Ders giriş/çıkış saatlerini gösteren form."""
    DAYS = ['', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar']

    def __init__(self, parent=None, schedule_data=None):
        super().__init__(parent)
        self.parent = parent
        self.schedule_data = schedule_data
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Giriş/Çıkış Saatleri")
        self.setWindowFlags(Qt.Tool | Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint)
        self.setModal(True)
        self.setMinimumSize(500, 600)

        layout = QVBoxLayout()

        # Gün seçim butonları
        day_layout = QHBoxLayout()
        self.day_buttons = []
        today = simdi().isoweekday()  # 1=Mon, 7=Sun
        for i in range(1, 8):
            btn = QPushButton(self.DAYS[i][:3])
            btn.setCheckable(True)
            btn.setStyleSheet("""
                QPushButton { padding: 8px 12px; border: 1px solid #555; border-radius: 4px; background: #2a2a3e; color: white; }
                QPushButton:checked { background: #0066cc; border-color: #0088ff; font-weight: bold; }
            """)
            btn.clicked.connect(lambda checked, day=i: self._select_day(day))
            day_layout.addWidget(btn)
            self.day_buttons.append(btn)
        layout.addLayout(day_layout)

        # Saat tablosu başlık
        header = QHBoxLayout()
        for text in ['Ders', 'Giriş', 'Çıkış']:
            lbl = QLabel(text)
            lbl.setStyleSheet("font-weight: bold; font-size: 14px; padding: 4px; color: white; background: #333;")
            lbl.setAlignment(Qt.AlignCenter)
            header.addWidget(lbl)
        layout.addLayout(header)

        # 18 ders periyodu satırları
        self.rows = []
        for i in range(1, 19):
            row_layout = QHBoxLayout()
            ders_lbl = QLabel(f"{i}. Ders")
            ders_lbl.setAlignment(Qt.AlignCenter)
            ders_lbl.setStyleSheet("padding: 2px; font-size: 12px;")
            giris_lbl = QLabel("—")
            giris_lbl.setAlignment(Qt.AlignCenter)
            giris_lbl.setStyleSheet("padding: 2px; font-size: 12px; color: #00cc66;")
            cikis_lbl = QLabel("—")
            cikis_lbl.setAlignment(Qt.AlignCenter)
            cikis_lbl.setStyleSheet("padding: 2px; font-size: 12px; color: #ff6644;")
            row_layout.addWidget(ders_lbl)
            row_layout.addWidget(giris_lbl)
            row_layout.addWidget(cikis_lbl)
            layout.addLayout(row_layout)
            self.rows.append((giris_lbl, cikis_lbl))

        # Kapat butonu
        close_btn = QPushButton("Kapat")
        close_btn.setStyleSheet("padding: 8px; background: #0066cc; color: white; border-radius: 4px;")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

        self.setLayout(layout)
        self.setStyleSheet("background-color: #1e1e2e; color: white;")

        # Bugünün gününü seç
        self._select_day(today)

    def _select_day(self, day_index):
        """Seçilen güne göre saatleri güncelle."""
        # Buton durumlarını güncelle
        for i, btn in enumerate(self.day_buttons):
            btn.setChecked(i + 1 == day_index)

        # Tüm satırları temizle
        for giris, cikis in self.rows:
            giris.setText("—")
            cikis.setText("—")

        if not self.schedule_data or 'hours' not in self.schedule_data:
            return

        hours_data = self.schedule_data.get('hours')
        try:
            if isinstance(hours_data, list):
                if day_index < len(hours_data):
                    day_schedule = hours_data[day_index]
                    for period in range(1, min(19, len(day_schedule))):
                        period_data = day_schedule[period]
                        if isinstance(period_data, list) and len(period_data) >= 3:
                            start = period_data[1] if period_data[1] and period_data[1] != '0' else ''
                            end = period_data[2] if period_data[2] and period_data[2] != '0' else ''
                            if start:
                                self.rows[period - 1][0].setText(start)
                            if end:
                                self.rows[period - 1][1].setText(end)
            elif isinstance(hours_data, dict):
                day_schedule = hours_data.get(str(day_index), {})
                for k in range(1, 19):
                    slot = day_schedule.get(str(k))
                    if slot and isinstance(slot, dict):
                        start = slot.get('1', '')
                        end = slot.get('2', '')
                        if start and start != '0':
                            self.rows[k - 1][0].setText(start)
                        if end and end != '0':
                            self.rows[k - 1][1].setText(end)
        except Exception as e:
            logging.warning(f"Error displaying schedule: {e}")


# --- Giriş/Çıkış Saatleri — Overlay İçin Saf Widget (pencere açmaz) ---
class ScheduleWidget(QWidget):
    """ScheduleDialog ile aynı içerik, ama LockScreenOverlay içinde kullanılmak üzere 
    bağımsız bir QWidget. Yeni pencere açmaz."""
    DAYS = ['', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar']

    def __init__(self, schedule_data=None, parent=None):
        super().__init__(parent)
        self.schedule_data = schedule_data
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(4)
        layout.setContentsMargins(0, 0, 0, 0)

        # Gün seçim butonları
        day_layout = QHBoxLayout()
        self.day_buttons = []
        today = simdi().isoweekday()
        for i in range(1, 8):
            btn = QPushButton(self.DAYS[i][:3])
            btn.setCheckable(True)
            btn.setStyleSheet("""
                QPushButton { padding: 6px 10px; border: 1px solid #555; border-radius: 4px;
                              background: #2a2a3e; color: white; font-size: 12px; }
                QPushButton:checked { background: #0066cc; border-color: #0088ff; font-weight: bold; }
            """)
            btn.clicked.connect(lambda checked, day=i: self._select_day(day))
            day_layout.addWidget(btn)
            self.day_buttons.append(btn)
        layout.addLayout(day_layout)

        # Başlık satırı
        header = QHBoxLayout()
        for text in ['Ders', 'Giriş', 'Çıkış']:
            lbl = QLabel(text)
            lbl.setStyleSheet("font-weight: bold; font-size: 13px; padding: 3px; color: #aaddff;")
            lbl.setAlignment(Qt.AlignCenter)
            header.addWidget(lbl)
        layout.addLayout(header)

        # 18 ders satırı
        self.rows = []
        for i in range(1, 19):
            row = QHBoxLayout()
            d = QLabel(f"{i}.")
            d.setAlignment(Qt.AlignCenter)
            d.setStyleSheet("color: #ccc; font-size: 11px;")
            g = QLabel("—")
            g.setAlignment(Qt.AlignCenter)
            g.setStyleSheet("color: #00cc66; font-size: 11px;")
            c = QLabel("—")
            c.setAlignment(Qt.AlignCenter)
            c.setStyleSheet("color: #ff6644; font-size: 11px;")
            row.addWidget(d)
            row.addWidget(g)
            row.addWidget(c)
            layout.addLayout(row)
            self.rows.append((g, c))

        self._select_day(today)

    def _select_day(self, day_index):
        for i, btn in enumerate(self.day_buttons):
            btn.setChecked(i + 1 == day_index)
        for giris, cikis in self.rows:
            giris.setText("—")
            cikis.setText("—")
        if not self.schedule_data or 'hours' not in self.schedule_data:
            return
        hours_data = self.schedule_data.get('hours')
        try:
            if isinstance(hours_data, list):
                if day_index < len(hours_data):
                    day_schedule = hours_data[day_index]
                    for period in range(1, min(19, len(day_schedule))):
                        period_data = day_schedule[period]
                        if isinstance(period_data, list) and len(period_data) >= 3:
                            start = period_data[1] if period_data[1] and period_data[1] != '0' else ''
                            end = period_data[2] if period_data[2] and period_data[2] != '0' else ''
                            if start: self.rows[period - 1][0].setText(start)
                            if end:   self.rows[period - 1][1].setText(end)
            elif isinstance(hours_data, dict):
                day_schedule = hours_data.get(str(day_index), {})
                for k in range(1, 19):
                    slot = day_schedule.get(str(k))
                    if slot and isinstance(slot, dict):
                        start = slot.get('1', '')
                        end = slot.get('2', '')
                        if start and start != '0': self.rows[k - 1][0].setText(start)
                        if end and end != '0':     self.rows[k - 1][1].setText(end)
        except Exception as e:
            logging.warning(f"ScheduleWidget error: {e}")


# --- Keyboard Locker Thread (More Aggressive) ---
class KeyboardLocker(threading.Thread):
    def __init__(self):
        super().__init__()
        self.daemon = True
        self.devices = []
        self.stop_event = threading.Event()
        self._find_input_devices()

    def _find_input_devices(self):
        paths = list_devices()
        for path in paths:
            try:
                device = InputDevice(path)
                caps = device.capabilities()

                # Changed logic: Lock anything that might be used to type or bypass the lock screen.
                # Since MEB school boards use various touch layers and generic HID devices, 
                # we'll be more inclusive and lock general EV_KEY devices that look like keyboards.
                if ecodes.EV_KEY in caps:
                    # Check if device has keyboard-specific keys
                    has_keyboard_keys = any(key in caps.get(ecodes.EV_KEY, [])
                                          for key in [ecodes.KEY_A, ecodes.KEY_ENTER, ecodes.KEY_SPACE, ecodes.KEY_ESC])
                    
                    has_mouse_buttons = any(key in caps.get(ecodes.EV_KEY, [])
                                          for key in [getattr(ecodes, 'BTN_LEFT', 272), getattr(ecodes, 'BTN_RIGHT', 273), getattr(ecodes, 'BTN_MOUSE', 272)])
                    
                    if has_keyboard_keys:
                        logging.info(f"Found keyboard device to lock: {device.name} at {device.path}")
                        self.devices.append(device)
                    elif has_mouse_buttons:
                        logging.info(f"Skipping mouse device: {device.name} at {device.path}")
                    else:
                        logging.info(f"Skipping unknown input device: {device.name} at {device.path}")

            except Exception as e:
                logging.warning(f"Could not access device {path}: {e}")
                continue
        if not self.devices:
            logging.warning("No keyboard devices found by evdev.")

    def run(self):
        if not self.devices: return
        try:
            self.contexts = [dev.grab_context() for dev in self.devices]
            for context in self.contexts: context.__enter__()
            logging.info("Keyboard lock acquired on keyboard devices only (mice remain free).")
            self.stop_event.wait()
        except Exception as e:
            logging.error(f"Error grabbing devices: {e}.")
        finally:
            for context in getattr(self, 'contexts', []): context.__exit__(None, None, None)
            logging.info("Keyboard/mouse lock released.")

    def stop(self):
        self.stop_event.set()

# --- USB Monitor Thread (Enhanced for removal detection) ---
class UdevMonitor(QObject):
    usbUnlockSignal = pyqtSignal()
    usbRemoveSignal = pyqtSignal()
    usbRemovedSignal = pyqtSignal()  # NEW: Signal for when USB is removed
    
    def __init__(self):
        super().__init__()
        self.monitor_thread = threading.Thread(target=self._run, daemon=True)
        self.context = Context()
        self.monitor = Monitor.from_netlink(self.context)
        self.monitor.filter_by('block', 'partition')
        self.last_usb_state = False  # Track if USB was present in last check
        self.unlocked_by_usb = False  # NEW: Track if system was unlocked by USB
        
    def start(self): 
        self.monitor_thread.start()
        
    def _run(self):
        logging.info("USB monitor started.")
        for device in iter(self.monitor.poll, None):
            if device.action == 'add':
                time.sleep(2)  # Wait for mount
                self.check_device(device)
            elif device.action == 'remove':
                # NEW: Handle USB removal
                time.sleep(1)  # Wait for unmount
                self.check_usb_removal()
                
    def check_device(self, device):
        mount_point = self.get_mount_point(device)
        if not mount_point:
            try:
                ensure_usb_mounted()
                time.sleep(1)
                mount_point = self.get_mount_point(device)
            except Exception:
                pass
        if not mount_point: return
        
        unlock_file = os.path.join(mount_point, "pass.txt")
        if os.path.exists(unlock_file):
            with open(unlock_file, 'r') as f: 
                content = f.read().strip()
            if content == USB_PASSWORD:
                logging.info("USB unlock key found!")
                self.last_usb_state = True
                self.unlocked_by_usb = True  # NEW: Mark that system was unlocked by USB
                self.usbUnlockSignal.emit()
                
        remove_file = os.path.join(mount_point, "rmove.txt")
        if os.path.exists(remove_file):
            with open(remove_file, 'r') as f: 
                content = f.read().strip()
            if content == USB_REMOVE_PASSWORD:
                logging.info("USB remove key found!")
                self.usbRemoveSignal.emit()
                
    def check_usb_removal(self):
        """
        NEW: Check if USB drive with password was removed
        Only lock if system was originally unlocked by USB
        """
        current_usb_state = check_usb_password()
        
        # If USB was present before but not now, check if we should lock
        if self.last_usb_state and not current_usb_state:
            if self.unlocked_by_usb:
                logging.info("USB drive that unlocked the system was removed - locking system")
                self.last_usb_state = False
                self.unlocked_by_usb = False  # Reset the flag
                self.usbRemovedSignal.emit()
            else:
                logging.info("USB drive removed but system was not unlocked by USB - not locking")
                self.last_usb_state = False
        elif not current_usb_state:
            self.last_usb_state = False
            
    def reset_usb_unlock_flag(self):
        """
        NEW: Reset the USB unlock flag when system is unlocked by other means
        """
        self.unlocked_by_usb = False
        logging.info("USB unlock flag reset - system unlocked by other means")
            
    def get_mount_point(self, device):
        try:
            with open('/proc/mounts', 'r') as f:
                for line in f:
                    if line.startswith(device.device_node): 
                        return line.split()[1]
        except Exception: 
            return None

# --- NEW: Network Client for Server Communication ---
class NetworkClient:
    """
    Handles all communication with the backend server, mirroring the
    functionality of the C# ClassClient. Zero footprint approach used for secrets.
    """
    def __init__(self, settings):
        self.settings = settings

    def _base_url(self):
        """v5 cihaz taban URL'i (XOR gizli, project_rules §1). Endpoint basina yol eklenir."""
        _k = "pardus2026!"
        _dx = lambda t: bytes([b ^ ord(_k[i % len(_k)]) for i, b in enumerate(bytes.fromhex(t))]).decode()
        u = _dx("1815061406491d1f53464806545c09101140551c554e1d4f06165a105e595758555f00190d191f5b6f46574904002d071c1b534a")
        _k = _dx = None
        return u

    def _headers(self):
        """v6 cihaz auth: Bearer cihaz token'i (config'te ENC'li device_token) + X-Timestamp (replay).
        v4'teki Basic + User-Key + UserCore(fnc) semasi KALDIRILDI (pardusv6_project_rules §5)."""
        _k = "pardus2026!"
        _dx = lambda t: bytes([b ^ ord(_k[i % len(_k)]) for i, b in enumerate(bytes.fromhex(t))]).decode()
        _agt = _dx("1106170a012c615d534455320e131611")
        token = get_setting('device_token', '') or None
        headers = {
            "User-Agent": _agt,
            "X-Timestamp": str(int(time.time())),
        }
        if token:
            headers["Authorization"] = f"Bearer {token}"
        _k = _dx = _agt = token = None
        return headers

    def _make_request(self, endpoint: str, data: dict = None, method: str = "POST", timeout: int = 100):
        """v5 cihaz endpoint'ine JSON istek. endpoint: poll|ack|schedule|log|log_reset|version."""
        if not self.check_network():
            logging.warning("Network is unavailable. Aborting request.")
            return None

        headers = self._headers()
        if "Authorization" not in headers:
            logging.error("Cihaz token'i yok (config'te device_token tanimli degil) — enrollment gerekli.")
            return None

        _url = self._base_url() + "/" + endpoint
        try:
            if method == "GET":
                response = requests.get(_url, headers=headers, timeout=timeout, verify=True)
            else:
                response = requests.post(_url, headers=headers, json=(data or {}), timeout=timeout, verify=True)
            _url = None

            if response.status_code != 200:
                logging.error(f"API Error: {response.status_code} @ {endpoint}")
                return None
            return response
        except requests.exceptions.SSLError as e:
            _url = None
            logging.error(f"SSL Error during network request: {e}. MITM Protection active.")
            return None
        except requests.RequestException as e:
            _url = None
            logging.error(f"Network request failed @ {endpoint}: {e}")
            return None

    def _enroll_request(self, endpoint: str, data: dict, timeout: int = 60):
        """Kurulum-ani istek: cihaz token'i HENUZ YOK, X-Enroll-Secret ile kimlik dogrulanir.
        Sir config'e setup.sh tarafindan ENC'li yazilir (kurulum medyasindaki secret.txt'ten) ve
        enroll basarili olur olmaz silinir (bkz. BoardConfig._strip_enroll_secret)."""
        secret = get_setting('enroll_secret', '')
        # YENIDEN TANITMA: tanitim basarili olunca sir config'ten SILINIYOR. Tahta adini/sinifini
        # degistirmek ya da baska bir tahta kaydina gecmek isteyen teknisyen bu yuzden duvara
        # tosluyordu ("Kurulum sirri yok"). Sir yoksa mevcut cihaz token'i ile devam ediyoruz;
        # sunucu token'i kabul eder ama YALNIZCA kendi okulu icin (bkz. checkDeviceToken).
        token = get_setting('device_token', '') or None
        if not secret and not token:
            logging.error("Ne enroll_secret ne device_token var — kurulum medyasinda secret.txt eksik.")
            return None

        self.son_enroll_hata = ""
        if not self.check_network():
            logging.warning("Network is unavailable. Aborting enroll request.")
            self.son_enroll_hata = "ag"
            return None

        _k = "pardus2026!"
        _dx = lambda t: bytes([b ^ ord(_k[i % len(_k)]) for i, b in enumerate(bytes.fromhex(t))]).decode()
        _agt = _dx("1106170a012c615d534455320e131611")
        headers = {
            "User-Agent": _agt,
            "X-Timestamp": str(int(time.time())),
        }
        if secret:
            headers["X-Enroll-Secret"] = secret
        else:
            headers["Authorization"] = f"Bearer {token}"
        _url = self._base_url() + "/" + endpoint
        try:
            response = requests.post(_url, headers=headers, json=data, timeout=timeout, verify=True)
            if response.status_code != 200:
                logging.error(f"Enroll API Error: {response.status_code} @ {endpoint}")
                self.son_enroll_hata = str(response.status_code)
                return None
            return response
        except requests.exceptions.SSLError as e:
            logging.error(f"SSL Error during enroll request: {e}. MITM Protection active.")
            self.son_enroll_hata = "ssl"
            return None
        except requests.RequestException as e:
            logging.error(f"Enroll request failed @ {endpoint}: {e}")
            self.son_enroll_hata = "ag"
            return None
        finally:
            # Sir/token'i RAM'den dusur (§5 zero-footprint).
            secret = token = headers = _k = _dx = _agt = _url = None

    def duyuru_resmi_indir(self, url: str):
        """Duyuru fotografini CIHAZ KIMLIGIYLE indirir; ham bayt doner, hata olursa None.

        Uc: GET /client/akilli_tahta_cihaz/duyuru_resim/<id> (deviceAuth).
        Adres /display icinde `resimUrl` olarak geliyor; anahtar tahtaya HIC verilmez,
        sunucu duyuru id'sini tahtanin KENDI okuluyla dogruluyor.
        """
        if not url:
            return None
        headers = self._headers()
        if "Authorization" not in headers:
            return None
        try:
            r = requests.get(url, headers=headers, timeout=20, verify=True, stream=True)
            if r.status_code != 200:
                logging.warning(f"Duyuru resmi alinamadi ({r.status_code}): {url}")
                return None
            # Kotu niyetli/bozuk buyuk govde kilit ekranini bogmasin.
            veri = r.raw.read(DUYURU_RESIM_MAX_BAYT + 1, decode_content=True)
            if veri is None:
                return None
            if len(veri) > DUYURU_RESIM_MAX_BAYT:
                logging.warning("Duyuru resmi cok buyuk, atlandi.")
                return None
            return veri
        except Exception as e:
            logging.warning(f"Duyuru resmi indirilemedi: {e}")
            return None
        finally:
            headers = None

    def list_boards(self, corporate_code):
        """Kurumun tahta listesi (v5 /boards). Ilk kurulumda X-Enroll-Secret, yeniden
        tanitmada mevcut cihaz token'i ile. [{boardId, name, aktif}] doner."""
        result = self._result(self._enroll_request("boards", {"corporateCode": str(corporate_code)}))
        if result is None:
            return None
        return result.get("boards")

    def enroll(self, corporate_code, board_id, board_name):
        """Cihaz token'i uret (v5 /enroll). Ilk kurulumda X-Enroll-Secret, yeniden tanitmada
        mevcut token ile (yalnizca kendi okulu). Token YALNIZCA bir kez doner."""
        result = self._result(self._enroll_request("enroll", {
            "corporateCode": str(corporate_code),
            "boardId": int(board_id),
            "boardName": board_name,
        }))
        if result is None:
            return None
        return result.get("token") or None

    def _result(self, response):
        """v5 zarfi {status, desc, httpStatus, result} -> result doner; status false/parse hatasi -> None."""
        if not response:
            return None
        try:
            body = response.json()
        except ValueError:
            logging.error(f"JSON decode failed: {response.text[:200]}")
            return None
        if body.get("status") is not True:
            logging.error(f"API status false: {body.get('desc')}")
            return None
        return body.get("result")

    def check_network(self):
        """Ag var mi? v5 kok host'una (apiv5) bakar. Host XOR'lu; plaintext host YOK (§5.1)."""
        _k = "pardus2026!"
        _dx = lambda t: bytes([b ^ ord(_k[i % len(_k)]) for i, b in enumerate(bytes.fromhex(t))]).decode()
        _url = _dx("1815061406491d1f53464806545c09101140551c554e1d4f0616")

        try:
            import requests
            requests.get(_url, timeout=3, verify=True)
            _url = _k = _dx = None
            return True
        except requests.exceptions.RequestException:
            import socket
            from urllib.parse import urlparse
            _host = urlparse(_url).hostname
            _url = _k = _dx = None
            try:
                socket.create_connection((_host, 443), timeout=3)
                return True
            except OSError:
                return False

    def ctrl_post(self):
        """Yoklama (v5 /poll). Kimlik token'dan gelir; govdede SADECE surum bilgisi var.
        process_commands ile uyum icin LISTE doner: [openClose, message, shutdown, systemRemove, logIstek]
        (hepsi str; mesaj bos ise '0' = v4 default davranisi). Kayit yoksa v5 fail-safe KILITLI doner.

        Surum bildirimi: sunucu tahtanin hangi istemci surumunde oldugunu bilmiyordu. ynt5'teki
        'Programi Kaldir' butonu yalnizca TAM temizlik yapabilen surumlerde (V6.00.12+) aktif
        olacagi icin bu bilgi gerekli. Sunucu throttle'li yazar; her yoklamada DB'ye gitmez."""
        result = self._result(self._make_request("poll", {
            "version": str(self.settings.get('version') or ''),
        }))
        if result is None:
            return None
        msg = result.get("message", "")
        return [
            str(result.get("openClose", 1)),
            msg if msg else "0",
            str(result.get("shutdown", 0)),
            str(result.get("systemRemove", 0)),
            str(result.get("logIstek", 0)),
        ]

    def set_value(self, column, value, sebep=None):
        """Komut ACK'i (v5 /ack). Kolon whitelist: open_close/shutdown/system_Remove/log_istek/message.

        `sebep`: tahtanin KENDI actigi/kilitledigi durumlarda nedenini sunucuya bildirir
        (admin sifresi / USB / cevrimdisi sifre / zamanlanmis...). Sunucu bunu denetim
        kaydina yazar; illegal acilis uyarisi buna dayanir. Kimlik yine token'dan gelir."""
        govde = {"column": column, "value": str(value)}
        if sebep:
            govde["sebep"] = str(sebep)[:60]
        result = self._result(self._make_request("ack", govde))
        if result is not None:
            logging.info(f"Acknowledged command: set {column}={value}")
            return True
        return False

    def save_log(self, log_name, vog_name):
        """Hata/olay logu (v5 /log)."""
        if vog_name == "logistek":
            self.log_request()

        log_str = f"{self.settings.get('version')}-{self.settings.get('sub_version')}:{log_name}"
        result = self._result(self._make_request("log", {"logName": log_str, "vog": vog_name}))
        if result is not None:
            logging.info(f"Log saved: {vog_name} - {log_name}")
            return True
        return False

    def log_request(self):
        """log_istek bayragini sifirla (v5 /log_reset)."""
        result = self._result(self._make_request("log_reset", {}))
        if result is not None:
            logging.info("Log request sent successfully.")
            return True
        return False

    def get_values(self):
        """Calisma saatleri (v5 /schedule). result.schedule (parse edilmis JSON) doner.
        NOT: kurulumdaki tahta LISTELEME artik buradan gelmez (Secenek A); onu provisioning araci yapar."""
        result = self._result(self._make_request("schedule", {}))
        if result is None:
            return None
        return result.get("schedule")

    def check_version(self):
        """Guncel istemci surumu (v5 GET /version)."""
        current_version = self.settings.get('version')
        result = self._result(self._make_request("version", method="GET"))
        if result:
            nw = str(result.get("version", "")).strip()
            if nw and len(nw) < 6:
                return nw
        return current_version

    def get_display(self):
        """Kilit ekrani gosterim verisi (v5 /display). Kimlik token'dan; govde bos.
        result.aferinTop5 = [{numara, adi, aferin}] (bu haftanin sinif ilk-5'i). Isim eslesmezse
        veya bu hafta aferin yoksa bos liste; sunucu hatasinda None. Sonraki feature'lar ayni objede."""
        result = self._result(self._make_request("display", {}))
        if result is None:
            return None
        return result

    def get_sinav_oturma(self):
        """Sinav oturma duzeni (v5 GET /sinav_oturma). deviceAuth (/display ile ayni); govde yok.
        result = {aktif, salon, sinav_id, sinav_adi, ders_adi, saat, ogrenciler[], gorevliler[]}.
        aktif=false -> bugun bu odada sinav yok. Sunucu hatasi/ag yoksa None (mevcut durum korunur)."""
        result = self._result(self._make_request("sinav_oturma", {}, method="GET"))
        if result is None:
            return None
        return result


# --- Main Application Window ---
# --- Feature 5: "Bu Haftanin Aferinleri" paneli stili ---
# Qt zengin-metin (QLabel RichText) gradient/flex desteklemez; bu yuzden panel QFrame + QSS + layout
# olarak kuruluyor. QSS qlineargradient ve border-radius destekler -> podyum hissi verebiliyoruz.
# Sinif tahtasinin arkasindan okunabilmesi icin punto ve kontrast bilerek yuksek tutuldu.
AFERIN_PANEL_QSS = """
QFrame#aferinPanel {
    background-color: rgba(10, 17, 34, 238);
    border: 2px solid rgba(255, 193, 71, 190);
    border-radius: 22px;
}
QLabel { background: transparent; }
QLabel#aferinTitle {
    color: #FFD35C;
    font-family: 'DejaVu Sans';
    font-size: 15px;
    font-weight: bold;
}
QLabel#aferinSubtitle {
    color: rgba(190, 205, 230, 190);
    font-family: 'DejaVu Sans';
    font-size: 10px;
}
QFrame#aferinRule {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(255,193,71,220), stop:0.65 rgba(255,193,71,60), stop:1 rgba(255,193,71,0));
    border: none;
    border-radius: 1px;
}
/* Lider satiri: hafif altin parilti */
QFrame#aferinRowTop {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(255,193,71,46), stop:1 rgba(255,193,71,8));
    border: 1px solid rgba(255,193,71,90);
    border-radius: 12px;
}
QFrame#aferinRow {
    background-color: rgba(255, 255, 255, 14);
    border: 1px solid rgba(255, 255, 255, 20);
    border-radius: 12px;
}
QLabel#aferinName {
    color: #FFFFFF;
    font-family: 'DejaVu Sans';
    font-size: 13px;
    font-weight: bold;
}
QLabel#aferinNameTop {
    color: #FFF3D0;
    font-family: 'DejaVu Sans';
    font-size: 14px;
    font-weight: bold;
}
QLabel#aferinNo {
    color: rgba(178, 195, 222, 205);
    font-family: 'DejaVu Sans';
    font-size: 10px;
}
QLabel#aferinCount {
    color: #1E1605;
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
        stop:0 #FFE082, stop:1 #FFB300);
    border-radius: 12px;
    font-family: 'DejaVu Sans';
    font-size: 13px;
    font-weight: bold;
}
QLabel#aferinCountPlain {
    color: #EAF1FF;
    background-color: rgba(255, 255, 255, 30);
    border-radius: 12px;
    font-family: 'DejaVu Sans';
    font-size: 13px;
    font-weight: bold;
}
"""

# Ilk uc sira icin madalya rozeti renkleri: (gradient ust, gradient alt, yazi rengi)
AFERIN_RANK_COLORS = [
    ('#FFE485', '#F0A500', '#3A2A05'),   # altin
    ('#F2F6FA', '#AEBCC9', '#252C33'),   # gumus
    ('#EBB278', '#B9743A', '#3A2110'),   # bronz
]

# --- Feature 4: "Bugun Gelmeyenler" (yoklama yok listesi) paneli stili ---
# Sag-alt kosede (aferin sol-altta -> simetrik). Kirmizi tema = devamsizlik.
# O sinifin bugunku EN SON yoklamasindaki gelmeyenler (numara + isim).
YOKLAMA_PANEL_QSS = """
QFrame#yoklamaPanel {
    background-color: rgba(30, 12, 14, 240);
    border: 2px solid rgba(239, 83, 80, 200);
    border-radius: 22px;
}
QLabel { background: transparent; }
QLabel#yoklamaTitle {
    color: #FF8A80;
    font-family: 'DejaVu Sans';
    font-size: 15px;
    font-weight: bold;
}
QLabel#yoklamaSubtitle {
    color: rgba(230, 200, 200, 190);
    font-family: 'DejaVu Sans';
    font-size: 10px;
}
QFrame#yoklamaRule {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(239,83,80,220), stop:0.65 rgba(239,83,80,60), stop:1 rgba(239,83,80,0));
    border: none;
    border-radius: 1px;
}
QFrame#yoklamaRow {
    background-color: rgba(255, 255, 255, 14);
    border: 1px solid rgba(255, 120, 120, 40);
    border-radius: 12px;
}
QLabel#yoklamaName {
    color: #FFFFFF;
    font-family: 'DejaVu Sans';
    font-size: 13px;
    font-weight: bold;
}
QLabel#yoklamaNo {
    color: #1A0A0B;
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
        stop:0 #FF8A80, stop:1 #E53935);
    border-radius: 12px;
    font-family: 'DejaVu Sans';
    font-size: 13px;
    font-weight: bold;
}
QLabel#yoklamaTamKatilim {
    color: #A5D6A7;
    font-family: 'DejaVu Sans';
    font-size: 13px;
    font-weight: bold;
}
/* Durum etiketleri: geç (turuncu) ve nöbetçi (mavi). Yok'ta etiket gösterilmez. */
QLabel#yoklamaTagGec {
    color: #3A2600;
    background-color: #FFB74D;
    border-radius: 8px;
    font-family: 'DejaVu Sans';
    font-size: 10px;
    font-weight: bold;
}
QLabel#yoklamaTagNbt {
    color: #06222E;
    background-color: #4FC3F7;
    border-radius: 8px;
    font-family: 'DejaVu Sans';
    font-size: 10px;
    font-weight: bold;
}
"""

# --- Feature 1: "Iyi ki dogdun" kutlama paneli stili ---
# Ekranin ORTASINDA gosterilir (kullanici karari) — dogum gunu nadir bir olay oldugu icin
# merkezdeki gorseli o gune ozel kapatmasi kabul edildi. Sadece o sinifta bugun dogan varsa gorunur.
BIRTHDAY_PANEL_QSS = """
QFrame#birthdayPanel {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 rgba(58, 18, 74, 246), stop:0.55 rgba(30, 16, 66, 246), stop:1 rgba(16, 20, 58, 246));
    border: 3px solid rgba(255, 158, 205, 215);
    border-radius: 30px;
}
QLabel { background: transparent; }
QLabel#bdayEmoji {
    font-size: 40px;
}
QLabel#bdayTitle {
    color: #FFD9EC;
    font-family: 'DejaVu Sans';
    font-size: 29px;
    font-weight: bold;
}
QLabel#bdayName {
    color: #FFFFFF;
    font-family: 'DejaVu Sans';
    font-size: 33px;
    font-weight: bold;
}
QLabel#bdayAge {
    color: #FFD35C;
    font-family: 'DejaVu Sans';
    font-size: 18px;
    font-weight: bold;
}
QLabel#bdaySub {
    color: rgba(223, 205, 240, 200);
    font-family: 'DejaVu Sans';
    font-size: 15px;
}
QFrame#bdayRule {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(255,158,205,0), stop:0.5 rgba(255,158,205,190), stop:1 rgba(255,158,205,0));
    border: none;
}
"""

# --- Duyuru (announcement) slider paneli — ORTA PANO (kullanici karari: orta pano = DUYURU PANOSU) ---
# Sinif + ders saati hedefli; v5 /display'den `duyurular` alaninda gelir. Dogum gunu varsa ilk 10 dk
# kutlama gosterilir, sonra (ya da dogum gunu yoksa direkt) burada slider olarak oynar. Ogretmen
# "Durdur" ile bu tahtada bu ders saati boyunca gizleyebilir. Duyuru yoksa panel kapali kalir.
# Renk: birthday moru/pembesinden AYRI, otoriter mavi (duyuru/bilgi hissi).
DUYURU_PANEL_QSS = """
QFrame#duyuruPanel {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 rgba(12, 44, 78, 248), stop:0.55 rgba(10, 54, 88, 248), stop:1 rgba(8, 40, 72, 248));
    border: 3px solid rgba(120, 200, 255, 220);
    border-radius: 30px;
}
QLabel { background: transparent; }
QLabel#duyuruKicker {
    color: #8FD3FF;
    font-family: 'DejaVu Sans';
    font-size: 20px;
    font-weight: bold;
    letter-spacing: 2px;
}
QLabel#duyuruGonderen {
    color: rgba(184, 216, 242, 210);
    font-family: 'DejaVu Sans';
    font-size: 15px;
}
QFrame#duyuruRule {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(120,200,255,0), stop:0.5 rgba(120,200,255,190), stop:1 rgba(120,200,255,0));
    border: none;
}
QLabel#duyuruBaslik {
    color: #FFFFFF;
    font-family: 'DejaVu Sans';
    font-size: 30px;
    font-weight: bold;
}
QLabel#duyuruDots {
    color: rgba(150, 200, 240, 230);
    font-family: 'DejaVu Sans';
    font-size: 20px;
    font-weight: bold;
    letter-spacing: 3px;
}
"""

# Dogum gunu -> slider gecis kapisi (dk) ve slayt sure (ms).
# Kilitlenme anindan itibaren dogum gunu kutlamasi bu sure boyunca one cikar, sonra duyuru
# slider'i devralir. Tenefusler 5 dk kadar kisa olabildigi icin dusuk tutuldu (kullanici karari).
DUYURU_BIRTHDAY_GATE_SEC = 180  # 3 dk
DUYURU_SLIDE_MS = 8000
DUYURU_MAX_NOKTA = 12
DUYURU_RESIM_MAX_BAYT = 6 * 1024 * 1024   # 6 MB ustu resim cizilmez
DUYURU_RESIM_MAX_YUKSEKLIK = 1600          # panelde resme ayrilan azami yukseklik (px). Yuksek cozunurluklu tahtada foto buyuk gorunsun; dusuk cozunurlukte zaten ekran orani (0.40H) sinirlar.

# Sinav bitis saati gonderilmemisse ekran gun boyu acik kalmasin diye varsayilan sure.
EXAM_VARSAYILAN_SURE_DK = 120


# --- Sinav Oturma Duzeni (tam ekran sinav modu) paneli ---
# Ortak sinav saatinde tahta komple kilitlenir; bu panel TUM ekrani kaplar (aferin/duyuru kilit
# ekraninin USTUNDE, oncelikli). Ogrenci sinifa girince adini x/y grid'inde bulup oturur.
EXAM_PANEL_QSS = """
QFrame#examPanel {
    background-color: qlineargradient(x1:0, y1:0, x2:0.35, y2:1,
        stop:0 #0B1226, stop:0.55 #0E1830, stop:1 #0A1020);
}
QLabel { background: transparent; }
QLabel#examHeader {
    color: #FFFFFF;
    font-family: 'DejaVu Sans';
    font-size: 36px;
    font-weight: bold;
    letter-spacing: 3px;
}
QLabel#examSubHeader {
    color: #7DD3FC;
    font-family: 'DejaVu Sans';
    font-size: 23px;
    font-weight: bold;
}
QLabel#examClock {
    color: #E6EEF9;
    font-family: 'DejaVu Sans';
    font-size: 26px;
    font-weight: bold;
}
QLabel#examFront {
    color: rgba(168, 194, 224, 190);
    font-family: 'DejaVu Sans';
    font-size: 14px;
    font-weight: bold;
    letter-spacing: 4px;
}
QLabel#examFooter {
    color: #CBD9EC;
    font-family: 'DejaVu Sans';
    font-size: 17px;
    font-weight: bold;
}
QLabel#examLegend {
    color: rgba(190, 208, 230, 210);
    font-family: 'DejaVu Sans';
    font-size: 14px;
    font-weight: bold;
}
/* SINAVDA olan öğrenci — MAVİ (renk körü güvenli çift: mavi <-> amber) */
QFrame#examBox {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #1C3357, stop:1 #16263F);
    border: 2px solid #5EA8E8;
    border-radius: 14px;
}
QLabel#examName {
    color: #FFFFFF;
    font-family: 'DejaVu Sans';
    font-size: 17px;
    font-weight: bold;
}
QLabel#examNo {
    color: #A9CBEA;
    font-family: 'DejaVu Sans';
    font-size: 14px;
}
/* GELMEYEN öğrenci — AMBER + KALIN KESİKLİ çerçeve + "GELMEDİ" rozeti.
   Renk körlüğüne karşı üç ayrı ipucu: renk, çerçeve deseni, metin. Kırmızı KULLANILMAZ. */
QFrame#examBoxYok {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #4A3512, stop:1 #35260B);
    border: 3px dashed #F2A93B;
    border-radius: 14px;
}
QLabel#examNameYok {
    color: #FFE3B0;
    font-family: 'DejaVu Sans';
    font-size: 17px;
    font-weight: bold;
}
QLabel#examTagYok {
    color: #1B1405;
    background-color: #F2A93B;
    border-radius: 7px;
    font-family: 'DejaVu Sans';
    font-size: 13px;
    font-weight: bold;
    padding: 1px 6px;
}
QFrame#examYokPanel {
    background-color: rgba(58, 42, 14, 238);
    border: 2px solid #F2A93B;
    border-radius: 16px;
}
QLabel#examYokTitle {
    color: #FFCF8B;
    font-family: 'DejaVu Sans';
    font-size: 16px;
    font-weight: bold;
    letter-spacing: 1px;
}
QLabel#examYokRow {
    color: #FFFFFF;
    font-family: 'DejaVu Sans';
    font-size: 15px;
    font-weight: bold;
}
QLabel#examYokEmpty {
    color: #BFE3D6;
    font-family: 'DejaVu Sans';
    font-size: 14px;
}
"""


class FatihClientApp(QWidget):
    # Signal emitted from background thread when password validation completes.
    _validation_result = pyqtSignal(bool)
    
    # NEW: Signal to safely execute server commands on the main UI thread
    command_signal = pyqtSignal(list)
    
    # NEW: Signal to trigger UI updates for network status changes
    network_status_signal = pyqtSignal(bool)

    # /display verisi arka plan thread'inden UI thread'ine (tum sonuc sozlugu ya da None).
    # Icinden hem aferinTop5 (Feature 5) hem dogumGunleri (Feature 1) beslenir.
    _display_ready = pyqtSignal(object)

    # Duyuru fotografi arka planda inince UI thread'e tasinir.
    # QPixmap YALNIZCA UI thread'inde uretilebilir; thread ham bayt yollar.
    _duyuru_resim_geldi = pyqtSignal(int, object)

    # /sinav_oturma verisi arka plan thread'inden UI thread'ine (result dict ya da None).
    _exam_ready = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        # Connect the command signal to process_commands
        self.command_signal.connect(self.process_commands)
        self.network_status_signal.connect(self.update_network_status_ui)
        self._display_ready.connect(self._render_display)
        self._exam_ready.connect(self._apply_exam)

        # --- SINAV MODU (oturma duzeni tam ekran) ---
        # Sinav ekrani = KILITLIYKEN gosterilen bir mod (duyuru gibi); kilidi ZORLA tutmaz.
        # Sadece saat gelince BIR KEZ otomatik kilitler (ekran gelsin). Sonrasi mebrecep/ynt5/
        # masaustu mudahaleleri her zaman ONCELIKLI. Pencere: [saat, bitis] — bitis gecince durur.
        self._exam_on = False        # sinav penceresi su an aktif mi (aktif + saat<=now<bitis)
        self._exam_data = None
        self._exam_boxes = []        # dinamik ogrenci kutulari
        self._exam_locked_for = None # ilk otomatik kilit yapilan sinav_id (bir kez)
        self._exam_rendered_id = None # cizili sinav_id (titreme onleme)

        self.is_locked = False  # Start as unlocked, then lock_system() will show the screen
        self._last_display_data = None  # /display son yaniti (panelleri aga gitmeden geri cizmek icin)
        self.keyboard_locker = None
        self.usb_check_timer = None
        # NEW: Instantiate the NetworkClient
        self.network_client = NetworkClient(SETTINGS)
        # Server command state
        self.shutDown = 0
        self.tahta_lock = 0
        self.system_remove = 0
        self.log_send = 0
        
        # --- İNTERNET KOPMA KORUNMASI ---
        # Sunucunun son gönderdiği tahta_lock değerini takip et
        # -1 = sunucudan henüz cevap alınmadı (bilinmiyor)
        # Bu sayede internet kopup geldiğinde sunucu varsayılan tahta_lock=0 
        # dönerse, önceki durumla karşılaştırırız:
        # - Eğer önceki değer 1 idi ve şimdi 0 → birileri Mebrecep/yönetimden açtı → kilidi aç
        # - Eğer önceki değer -1 (bilinmiyor) ve şimdi 0 → internet yeni geldi → kilidi AÇMA
        self.server_has_spoken = False  # Sunucu en az bir kez başarılı cevap verdi mi?
        
        # Yerel kilit/kilit açma durumunu sunucunun yansıtmasını beklemek için
        # -1 = Gelen her şeyi kabul et (beklenti yok)
        # 0 = Sunucunun 0 döndürmesini bekliyoruz (yeni açtık)
        # 1 = Sunucunun 1 döndürmesini bekliyoruz (yeni kilitledik)
        
        # --- KİLİTLEME SOĞUMA SÜRESİ ---
        # Kilitleme yapıldıktan sonra sunucunun eski 'aç' komutunu yoksaymak için
        # zaman damgası. 10 saniyelik soğuma süresi boyunca sunucudan gelen
        # tahta_lock=0 komutları yoksayılır.
        self.last_lock_time = 0

        # --- C# startWork / ewt MEKANİZMASI ---
        # İlk açılışta sunucu komutlarını yoksay.
        # C# kodu: startWork = false, ewt sayacı her timer tick'te artar,
        # ewt >= 4 olunca startWork = true olur.
        # Bu sayede ilk ~20 saniye sunucudan gelen eski 'aç' komutları yoksayılır.
        self.start_work = False
        self.early_wait_ticks = 0

        # --- SCHEDULING ---
        self.schedule = None
        self.manual_override = False # True if unlocked by user, ignores schedule until next lock time
        # C# kSaat[] karşılığı - çıkış saatlerinde tekrar kilitlemeyi önler
        self.exit_time_locked = [0] * 20  # index 1-18 kullanılacak (her ders periyodu için)
        self.last_schedule_day = -1  # Gün değişince exit_time_locked sıfırlanacak
        # --- END SCHEDULING ---

        # --- DUYURU (kilit-tabanlı slider) ---
        # MODEL: duyurular YALNIZ tahta KİLİTLİYKEN gösterilir (tenefüs/auto-lock/power açılışı/
        # kilit-on-send). Ders saati penceresi mantığı YOK — kilitli olduğu SÜRECE bugünün tüm
        # duyuruları döner (kısa 5 dk tenefüste de çalışır). /display o sınıfın (+0=tüm sınıf)
        # bugünkü tüm aktiflerini döner; tahta hepsini gösterir.
        self._duyuru_active = []          # kilitliyken gösterilecek bugünün duyuruları
        self._duyuru_index = 0            # slider'da gösterilen slayt
        # --- END DUYURU ---

        self.init_ui()
        self.init_network_timer()
        self.init_usb_monitor()
        self.init_usb_check_timer()
        self.init_maintenance_timer()
        self.init_time_timer()
        self.init_schedule_timer() # New timer for scheduling
        self.init_display_timer()  # Feature 5: ilk-5 aferin paneli
        self.init_duyuru_timers()  # Duyuru: durum değerlendirme + slayt geçişi
        self.init_exam_timer()     # Sınav oturma düzeni: /sinav_oturma yoklaması
        self.init_time_sync()      # Ağ saati senkronu (kilit/sınav/duyuru saatleri doğru olsun)

        # Güç yönetimi: uyku modu devre dışı (C# powercfg karşılığı)
        PowerManager.disable_sleep()

        # Show the lock screen at startup
        if not NO_LOCK_MODE:
            # İlk başlangıçta USB kontrolü yap - USB takılıysa kilitleme
            if check_usb_password():
                logging.info("USB password found at startup - skipping initial lock")
                self.usb_monitor.unlocked_by_usb = True
                self.manual_override = True
            elif kriz_penceresi_kalan() > 0:
                # Kriz penceresi surerken tahta yeniden baslatildi -> kilitli acilmasin.
                logging.warning(f"Kriz penceresi acik ({kriz_penceresi_kalan() // 60} dk) — baslangic kilidi atlandi.")
            else:
                self.lock_system("Sistem başlangıcı")
        else:
            logging.info("[NO-LOCK] Skipping initial lock")

        # İlk poll_server'ı geciktir - kilit ekranının kararlı olması için
        # (Hemen çağırırsak sunucu tahta_lock=0 döndürüp kilidi anında açar)
        QTimer.singleShot(5000, self.poll_server)

    def init_ui(self):
        self.setWindowTitle("Fatih Client v1.5 - Scheduling Enabled")
        # Qt.Tool kaldırıldı: Taskbar'ın üstüne geçemiyordu.
        # Qt.Window + WindowStaysOnTopHint + BypassWindowManagerHint kombinasyonu
        # Cinnamon WM'i atlayarak doğrudan X11 compositing katmanına yerleşir.
        self.setWindowFlags(
            Qt.Window
            | Qt.FramelessWindowHint
            | Qt.WindowStaysOnTopHint
            | Qt.X11BypassWindowManagerHint
        )
        self.setGeometry(QApplication.primaryScreen().geometry())

        # Ensure the window accepts mouse events
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        
        # Background image
        self.background = QLabel(self)
        bg_image_path = os.path.join(RESOURCES_DIR, "Artboard 3.png")
        if os.path.exists(bg_image_path):
            self.background.setPixmap(QPixmap(bg_image_path))
        else:
            # Fallback to solid color if image not found
            logging.warning(f"Background image not found: {bg_image_path}")
            self.background.setStyleSheet("background-color: #1a1a2e;")
        self.background.setScaledContents(True)
        self.background.setGeometry(self.rect())

        # Time display (bottom-right corner)
        self.time_label = QLabel("", self)
        self.time_label.setStyleSheet("color: white; font-size: 18px; background-color: rgba(0,0,0,0.7); padding: 5px;")
        self.time_label.setAlignment(Qt.AlignRight)
        self.time_label.setGeometry(self.width() - 250, self.height() - 50, 240, 40)

        # Version display (bottom-left corner)
        self.version_label = QLabel("", self)
        self.version_label.setStyleSheet("color: white; font-size: 18px; background-color: rgba(0,0,0,0.7); padding: 5px; border-radius: 5px;")
        self.version_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.version_label.setGeometry(10, self.height() - 50, 200, 40)
        
        # Read version
        version_text = "V1.00.28" # Default
        try:
            version_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "version.txt")
            if os.path.exists(version_path):
                with open(version_path, 'r', encoding='utf-8') as f:
                    version_text = f.read().strip()
            # Kiosk/Kurulum yolu
            elif os.path.exists("/opt/fatih-client/version.txt"):
                with open("/opt/fatih-client/version.txt", 'r', encoding='utf-8') as f:
                    version_text = f.read().strip()
        except:
            pass
        self.version_label.setText(f"Sürüm: {version_text}")

        # Board Name display (top-center) - TAHTA ADI üst ortada
        self.board_id_label = QLabel("", self)
        # Qt 5.11 uyumlu stylesheet - çok büyük padding
        self.board_id_label.setStyleSheet("""
            QLabel {
                color: white; 
                background-color: rgba(0, 0, 0, 220); 
                padding: 25px 40px;
                border-radius: 10px;
            }
        """)
        self.board_id_label.setFont(QFont('Sans', 20, QFont.Bold))
        self.board_id_label.setAlignment(Qt.AlignCenter)
        # Üst ortada - sabit boyut
        label_width = 450
        label_height = 100
        label_x = (self.width() - label_width) // 2  # Tam ortada
        self.board_id_label.setGeometry(label_x, 20, label_width, label_height)
        self.board_id_label.setMinimumHeight(label_height)
        self.update_board_id_display()

        # --- Feature 5: "Bu Haftanın Aferinleri" paneli (sol-alt, surum etiketinin ustunde) ---
        # Sunucudan (v5 /display) gelir; sinif bazli, bu haftanin en cok aferin alan 5 ogrencisi.
        # Veri yoksa (isim eslesmedi / bu hafta aferin yok / ag yok) panel gizli kalir.
        # Yapі: QFrame + QSS (gradient/radius icin) -> satirlar _render_aferin_panel'de kurulur.
        self.aferin_panel = QFrame(self)
        self.aferin_panel.setObjectName("aferinPanel")
        self.aferin_panel.setAttribute(Qt.WA_StyledBackground, True)
        self.aferin_panel.setStyleSheet(AFERIN_PANEL_QSS)
        self.aferin_panel.setFixedWidth(370)  # yan listeler dar: orta (dogum gunu/duyuru) panosu one ciksin

        _ap_lay = QVBoxLayout(self.aferin_panel)
        _ap_lay.setContentsMargins(24, 19, 24, 21)
        _ap_lay.setSpacing(3)

        self.aferin_title = QLabel("🏆  BU HAFTANIN AFERİNLERİ", self.aferin_panel)
        self.aferin_title.setObjectName("aferinTitle")
        _ap_lay.addWidget(self.aferin_title)

        self.aferin_subtitle = QLabel("", self.aferin_panel)
        self.aferin_subtitle.setObjectName("aferinSubtitle")
        _ap_lay.addWidget(self.aferin_subtitle)

        _ap_rule = QFrame(self.aferin_panel)
        _ap_rule.setObjectName("aferinRule")
        _ap_rule.setFixedHeight(3)
        _ap_lay.addSpacing(9)
        _ap_lay.addWidget(_ap_rule)
        _ap_lay.addSpacing(11)

        # Ogrenci satirlarinin kabi — her yenilemede yeniden doldurulur.
        self.aferin_rows_layout = QVBoxLayout()
        self.aferin_rows_layout.setSpacing(8)
        _ap_lay.addLayout(self.aferin_rows_layout)

        self.aferin_panel.hide()

        # --- Feature 1: doğum günü kutlama paneli (ekran ortasi) ---
        # Sadece tahtanin sinifinda BUGUN dogum gunu olan varsa gorunur.
        self.birthday_panel = QFrame(self)
        self.birthday_panel.setObjectName("birthdayPanel")
        self.birthday_panel.setAttribute(Qt.WA_StyledBackground, True)
        self.birthday_panel.setStyleSheet(BIRTHDAY_PANEL_QSS)
        self.birthday_panel.setFixedWidth(760)

        _bd_lay = QVBoxLayout(self.birthday_panel)
        # Yan ic bosluk 46->30: dar ekranda (iki panelin arasindaki bosluk kucuk) ada
        # isme daha cok yer kalsin. Genis tahtada da estetik bozulmaz.
        _bd_lay.setContentsMargins(30, 30, 30, 34)
        _bd_lay.setSpacing(4)

        self.bday_emoji = QLabel("🎉🎂🎈", self.birthday_panel)
        self.bday_emoji.setObjectName("bdayEmoji")
        self.bday_emoji.setAlignment(Qt.AlignCenter)
        _bd_lay.addWidget(self.bday_emoji)

        self.bday_title = QLabel("İYİ Kİ DOĞDUN!", self.birthday_panel)
        self.bday_title.setObjectName("bdayTitle")
        self.bday_title.setAlignment(Qt.AlignCenter)
        self.bday_title.setWordWrap(True)  # dar kartta kirpilmasin, gerekirse alt satira kaysin
        _bd_lay.addWidget(self.bday_title)

        _bd_rule = QFrame(self.birthday_panel)
        _bd_rule.setObjectName("bdayRule")
        _bd_rule.setFixedHeight(2)
        _bd_lay.addSpacing(14)
        _bd_lay.addWidget(_bd_rule)
        _bd_lay.addSpacing(16)

        # Kutlanan ogrencilerin kabi — her yenilemede yeniden doldurulur.
        self.bday_rows_layout = QVBoxLayout()
        self.bday_rows_layout.setSpacing(12)
        _bd_lay.addLayout(self.bday_rows_layout)

        _bd_lay.addSpacing(14)
        self.bday_sub = QLabel("", self.birthday_panel)
        self.bday_sub.setObjectName("bdaySub")
        self.bday_sub.setAlignment(Qt.AlignCenter)
        _bd_lay.addWidget(self.bday_sub)

        self.birthday_panel.hide()

        # --- Duyuru slider paneli (ORTA PANO) ---
        # Sınıf+ders saati hedefli duyurular burada slider olarak oynar (birthday ile aynı
        # merkezi alan; ikisi aynı anda gösterilmez — _update_duyuru_state karar verir).
        self.duyuru_panel = QFrame(self)
        self.duyuru_panel.setObjectName("duyuruPanel")
        self.duyuru_panel.setAttribute(Qt.WA_StyledBackground, True)
        self.duyuru_panel.setStyleSheet(DUYURU_PANEL_QSS)
        self.duyuru_panel.setFixedWidth(760)

        _dy_lay = QVBoxLayout(self.duyuru_panel)
        _dy_lay.setContentsMargins(36, 26, 36, 26)
        _dy_lay.setSpacing(5)

        self.duyuru_kicker = QLabel("📢  SINIF DUYURUSU", self.duyuru_panel)
        self.duyuru_kicker.setObjectName("duyuruKicker")
        self.duyuru_kicker.setAlignment(Qt.AlignCenter)
        _dy_lay.addWidget(self.duyuru_kicker)

        self.duyuru_gonderen = QLabel("", self.duyuru_panel)
        self.duyuru_gonderen.setObjectName("duyuruGonderen")
        self.duyuru_gonderen.setAlignment(Qt.AlignCenter)
        self.duyuru_gonderen.setWordWrap(True)
        self.duyuru_gonderen.setTextFormat(Qt.PlainText)   # gonderen adi da duz metin
        _dy_lay.addWidget(self.duyuru_gonderen)

        _dy_rule = QFrame(self.duyuru_panel)
        _dy_rule.setObjectName("duyuruRule")
        _dy_rule.setFixedHeight(2)
        _dy_lay.addSpacing(12)
        _dy_lay.addWidget(_dy_rule)
        _dy_lay.addSpacing(16)

        self.duyuru_baslik = QLabel("", self.duyuru_panel)
        self.duyuru_baslik.setObjectName("duyuruBaslik")
        self.duyuru_baslik.setAlignment(Qt.AlignCenter)
        self.duyuru_baslik.setWordWrap(True)  # uzun başlık dar kartta kesilmesin
        # GUVENLIK: QLabel varsayilani Qt.AutoText -> gelen metin HTML'e benziyorsa
        # ZENGIN METIN olarak islenir. Duyuru yazabilen biri <b>/<a>/<img src="http://...">
        # gonderip tahtanin ekranini bicimlendirebilir, hatta disari istek attirabilirdi.
        # Duyuru metni her zaman DUZ METIN. (Sunucu da etiketleri temizliyor; iki katman.)
        self.duyuru_baslik.setTextFormat(Qt.PlainText)
        _dy_lay.addWidget(self.duyuru_baslik)

        _dy_lay.addSpacing(10)
        self.duyuru_mesaj = QLabel("", self.duyuru_panel)
        self.duyuru_mesaj.setObjectName("duyuruMesaj")
        self.duyuru_mesaj.setAlignment(Qt.AlignCenter)
        self.duyuru_mesaj.setWordWrap(True)
        self.duyuru_mesaj.setTextFormat(Qt.PlainText)   # bkz. duyuru_baslik — HTML calistirilmaz
        _dy_lay.addWidget(self.duyuru_mesaj)

        # Duyuru fotografi (opsiyonel). Idare/ogretmen masaustunden resim eklerse
        # burada gosterilir; resmi olmayan duyuruda etiket gizli kalir.
        self.duyuru_resim = QLabel("", self.duyuru_panel)
        self.duyuru_resim.setObjectName("duyuruResim")
        self.duyuru_resim.setAlignment(Qt.AlignCenter)
        self.duyuru_resim.hide()
        _dy_lay.addWidget(self.duyuru_resim)

        _dy_lay.addSpacing(18)
        # Slayt noktaları (birden fazla duyuru varsa) — ortalı.
        self.duyuru_dots = QLabel("", self.duyuru_panel)
        self.duyuru_dots.setObjectName("duyuruDots")
        self.duyuru_dots.setAlignment(Qt.AlignCenter)
        _dy_lay.addWidget(self.duyuru_dots)

        # GÜVENLİK: kilit ekranında öğrencinin basabileceği HİÇBİR buton yok — "Durdur" butonu
        # KALDIRILDI (öğrenci basıp tahtayı açabiliyordu). Öğretmen duyuruyu durdurmak isterse
        # tahtayı AÇAR (ders başlatır); o an tüm paneller (slider dahil) zaten gizlenir.
        self.duyuru_panel.hide()

        # --- Sınav Oturma Düzeni paneli (TAM EKRAN, sınav modu) ---
        # Ortak sınav saatinde tahta kilitlenir; bu panel her şeyin üstünde tam ekran çizilir.
        # Öğrenci kutuları (x/y grid) _render_exam_panel'de dinamik kurulur.
        self.exam_panel = QFrame(self)
        self.exam_panel.setObjectName("examPanel")
        self.exam_panel.setAttribute(Qt.WA_StyledBackground, True)
        self.exam_panel.setStyleSheet(EXAM_PANEL_QSS)
        self.exam_header = QLabel("SINAV OTURMA DÜZENİ", self.exam_panel)
        self.exam_header.setObjectName("examHeader")
        self.exam_header.setAlignment(Qt.AlignCenter)
        self.exam_subheader = QLabel("", self.exam_panel)
        self.exam_subheader.setObjectName("examSubHeader")
        self.exam_subheader.setAlignment(Qt.AlignCenter)
        self.exam_front = QLabel("▲  TAHTA / ÖN SIRALAR", self.exam_panel)
        self.exam_front.setObjectName("examFront")
        self.exam_front.setAlignment(Qt.AlignCenter)
        self.exam_footer = QLabel("", self.exam_panel)
        self.exam_footer.setObjectName("examFooter")
        self.exam_footer.setAlignment(Qt.AlignCenter)
        self.exam_footer.setWordWrap(True)

        # Canlı saat (sağ üst) — ağ saatiyle senkron; sınav salonunda saat görmek kritik.
        self.exam_clock = QLabel("", self.exam_panel)
        self.exam_clock.setObjectName("examClock")
        self.exam_clock.setAlignment(Qt.AlignRight | Qt.AlignVCenter)

        # Lejant: renk kodunu AÇIKÇA yazar (renk körü kullanıcılar için renkten bağımsız ipucu).
        self.exam_legend = QLabel("", self.exam_panel)
        self.exam_legend.setObjectName("examLegend")
        self.exam_legend.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

        # Sınava gelmeyenler paneli (sağ kolon) — gözetmen MebreCep'ten yoklama alınca dolar.
        self.exam_yok_panel = QFrame(self.exam_panel)
        self.exam_yok_panel.setObjectName("examYokPanel")
        self.exam_yok_panel.setAttribute(Qt.WA_StyledBackground, True)
        _ey_lay = QVBoxLayout(self.exam_yok_panel)
        _ey_lay.setContentsMargins(16, 14, 16, 14)
        _ey_lay.setSpacing(8)
        self.exam_yok_title = QLabel("🚫  SINAVA GELMEYENLER", self.exam_yok_panel)
        self.exam_yok_title.setObjectName("examYokTitle")
        self.exam_yok_title.setWordWrap(True)
        _ey_lay.addWidget(self.exam_yok_title)
        self.exam_yok_rows = QVBoxLayout()
        self.exam_yok_rows.setSpacing(6)
        _ey_lay.addLayout(self.exam_yok_rows)
        _ey_lay.addStretch(1)
        self.exam_yok_panel.hide()

        self.exam_panel.hide()

        # --- Feature 4: "Bugün Gelmeyenler" (yoklama yok) paneli (sağ-alt köşe) ---
        # O sınıfın bugünkü EN SON yoklamasındaki gelmeyenler (numara + isim). Yoklama
        # alınmadıysa gizli; alındıysa ama gelmeyen yoksa "Tam katılım" gösterir.
        self.yoklama_panel = QFrame(self)
        self.yoklama_panel.setObjectName("yoklamaPanel")
        self.yoklama_panel.setAttribute(Qt.WA_StyledBackground, True)
        self.yoklama_panel.setStyleSheet(YOKLAMA_PANEL_QSS)
        self.yoklama_panel.setFixedWidth(370)  # aferin paneliyle simetrik (sol-sag esit dar liste)

        _yk_lay = QVBoxLayout(self.yoklama_panel)
        _yk_lay.setContentsMargins(24, 19, 24, 21)
        _yk_lay.setSpacing(3)

        self.yoklama_title = QLabel("🚫  BUGÜN GELMEYENLER", self.yoklama_panel)
        self.yoklama_title.setObjectName("yoklamaTitle")
        _yk_lay.addWidget(self.yoklama_title)

        self.yoklama_sub = QLabel("", self.yoklama_panel)
        self.yoklama_sub.setObjectName("yoklamaSubtitle")
        _yk_lay.addWidget(self.yoklama_sub)

        _yk_rule = QFrame(self.yoklama_panel)
        _yk_rule.setObjectName("yoklamaRule")
        _yk_rule.setFixedHeight(3)
        _yk_lay.addSpacing(9)
        _yk_lay.addWidget(_yk_rule)
        _yk_lay.addSpacing(11)

        self.yoklama_rows_layout = QVBoxLayout()
        self.yoklama_rows_layout.setSpacing(8)
        _yk_lay.addLayout(self.yoklama_rows_layout)

        self.yoklama_panel.hide()

        # Status message label
        self.message_label = QLabel("", self)
        # Siyah renk istendi
        self.message_label.setStyleSheet("color: black; font-size: 32px; background-color: transparent;")
        self.message_label.setAlignment(Qt.AlignCenter)
        self.message_label.setWordWrap(True)
        self.message_label.setGeometry(50, self.height() // 2 - 100, self.width() - 100, 200)

        # --- GÖMÜLÜ GİRİŞ FORMU (Child widget to prevent Cinnamon WM focus loss) ---
        self.login_panel = QWidget(self)  # Child of main window
        self.login_panel.setStyleSheet("""
            QWidget#loginPanel {
                background-color: rgba(30, 30, 30, 240);
                border: 2px solid #0066cc;
                border-radius: 15px;
            }
            QLabel { color: white; }
            QLineEdit {
                background-color: #3c3c3c;
                color: white;
                border: 2px solid #555;
                border-radius: 5px;
                padding: 10px;
                font-size: 18px;
            }
            QLineEdit:focus { border-color: #0066cc; }
            QPushButton {
                padding: 12px 25px;
                border-radius: 5px;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        self.login_panel.setObjectName("loginPanel")
        # No window flags needed for child widget overlaid on the main window
        # Fix height to 480 to properly fit EmbeddedNumpad
        panel_w, panel_h = 450, 480
        self.login_panel.setGeometry(
            (self.width() - panel_w) // 2,
            (self.height() - panel_h) // 2,
            panel_w, panel_h
        )
        lp_layout = QVBoxLayout(self.login_panel)
        lp_layout.setSpacing(15)
        lp_layout.setContentsMargins(30, 25, 30, 25)

        lp_title = QLabel("Yönetici Girişi")
        lp_title.setFont(QFont('Sans', 18, QFont.Bold))
        lp_title.setAlignment(Qt.AlignCenter)
        lp_layout.addWidget(lp_title)

        pass_layout = QHBoxLayout()
        self.login_password_field = KeyboardLineEdit()
        self.login_password_field.setEchoMode(QLineEdit.EchoMode.Password)
        self.login_password_field.setPlaceholderText("Mebrecep şifresini yazınız")
        self.login_password_field.set_on_enter_callback(self._login_attempt)
        pass_layout.addWidget(self.login_password_field)

        self.eye_btn = QPushButton("👁")
        self.eye_btn.setFixedSize(40, 48)
        self.eye_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.eye_btn.setStyleSheet("font-size: 20px; background-color: #444; color: white; border-radius: 5px;")
        self.eye_btn.pressed.connect(self._toggle_password_visibility)
        pass_layout.addWidget(self.eye_btn)

        lp_layout.addLayout(pass_layout)

        # Geri getirilen Gömülü Numpad - set_target ile doğrudan şifre alanına yazar
        self.numpad = EmbeddedNumpad(on_enter_callback=self._login_attempt)
        self.numpad.set_target(self.login_password_field)  # Focus bağımsız, direkt yaz
        self.numpad.setMinimumHeight(200)
        lp_layout.addWidget(self.numpad)

        self.login_error_label = QLabel("")
        self.login_error_label.setStyleSheet("color: #ff4444; font-size: 14px;")
        self.login_error_label.setAlignment(Qt.AlignCenter)
        lp_layout.addWidget(self.login_error_label)

        btn_layout = QHBoxLayout()
        cancel_btn = QPushButton("İptal")
        cancel_btn.setStyleSheet("background-color: #555; color: white;")
        cancel_btn.pressed.connect(self._login_cancel)
        btn_layout.addWidget(cancel_btn)

        login_btn = QPushButton("Tahtayı Aç")
        login_btn.setStyleSheet("background-color: #0066cc; color: white;")
        login_btn.pressed.connect(self._login_attempt)
        btn_layout.addWidget(login_btn)
        lp_layout.addLayout(btn_layout)

        self.login_panel.hide()  # Başlangıçta gizli

        # Login button - Tahtayı Açın butonu
        self.login_button = QPushButton("Tahtayı Açın", self)
        self.login_button.setStyleSheet("background-color: #0066cc; color: white; border: 3px solid white; border-radius: 10px;")
        self.login_button.setFont(QFont('DejaVu Sans', 18))
        self.login_button.pressed.connect(self.show_login_dialog)
        # Sabit boyut ayarla
        button_width = 280
        button_height = 60
        self.login_button.setFixedSize(button_width, button_height)
        
        # Butonu sağ üst köşeye taşı (üstten ve sağdan boşluk bırakarak)
        padding_top = 30
        padding_right = 30
        screen_width = QApplication.primaryScreen().geometry().width()
        self.login_button.move(screen_width - button_width - padding_right, padding_top)
        
        self.login_button.raise_()
        self.login_button.setVisible(True)
        self.login_button.show()

        # --- (i) Yardım Kılavuzu Butonu ---
        self.help_toggle_button = QPushButton("ℹ", self)
        self.help_toggle_button.setStyleSheet("""
            QPushButton {
                background-color: rgba(0, 0, 0, 150);
                color: #00ff88;
                border: 2px solid white;
                border-radius: 25px;
            }
            QPushButton:hover {
                background-color: rgba(0, 0, 0, 220);
            }
        """)
        self.help_toggle_button.setFont(QFont('DejaVu Sans', 24))
        self.help_toggle_button.pressed.connect(self.toggle_help_guide)
        toggle_size = 50
        self.help_toggle_button.setFixedSize(toggle_size, toggle_size)
        # Tahtayı Açın butonunun hemen soluna (15px boşluk)
        self.help_toggle_button.move(
            screen_width - button_width - padding_right - toggle_size - 15,
            padding_top + 5
        )
        self.help_toggle_button.raise_()
        self.help_toggle_button.show()

        # --- Yardım Kılavuzu Paneli (Child widget pattern) ---
        self.help_guide_label = QWidget(self)  # Child widget
        self.help_guide_label.setStyleSheet("""
            QWidget {
                background-color: rgba(0, 0, 0, 210);
                border: 2px solid #0066cc;
                border-radius: 15px;
            }
        """)
        hg_layout = QVBoxLayout(self.help_guide_label)
        hg_layout.setContentsMargins(20, 20, 20, 20)
        hg_text = QLabel(
            "👋 Merhaba! Tahtayı Açmak İçin:\n\n"
            "📱 Cep telefonunuza MebreCep uygulamasını indirin.\n\n"
            "🔓 Uygulamadan Akıllı Tahta menüsünden sınıfınızı seçip "
            "akıllı tahtayı açıp kilitleyebilirsiniz.\n\n"
            "🔑 Akıllı tahtada İnternet Yoksa: Uygulamadaki 'İnternetsiz "
            "Şifre Al' kodunu buradaki 'Tahtayı Açın' butonuna tıklayarak girin.\n\n"
            "✨ Ders bitiminde tahtanız otomatik olarak kilitlenecektir."
        )
        hg_text.setWordWrap(True)
        hg_text.setStyleSheet("color: white; font-size: 15px; background: transparent;")
        hg_layout.addWidget(hg_text)
        self.help_guide_label.hide()


        logging.info(f"Login button positioned at top-right: ({self.width() - button_width - padding_right}, {padding_top})")
        print(f"Login button moved to top-right: ({self.width() - button_width - padding_right}, {padding_top})")
        print(f"Login button visible: {self.login_button.isVisible()}")
        print(f"Login button enabled: {self.login_button.isEnabled()}")
        print(f"Button parent: {self.login_button.parent()}")
        print(f"Button window flags: {self.login_button.windowFlags()}")

        # Additional debugging - check window properties
        print(f"Window size: {self.size()}")
        print(f"Window is visible: {self.isVisible()}")
        print(f"Window is active: {self.isActiveWindow()}")

        # Admin command input (hidden)
        self.admin_input = QLineEdit(self)
        self.admin_input.setPlaceholderText("Admin komutları için Ctrl+K...")
        self.admin_input.setStyleSheet("background-color: rgba(0,0,0,0.3); color: white; border: 1px solid white;")
        self.admin_input.setGeometry(10, 10, 300, 30)
        self.admin_input.hide()
        self.admin_input.returnPressed.connect(self.process_admin_command)

        # Version update notification label (initially hidden)
        self.version_update_label = QLabel("", self)
        self.version_update_label.setStyleSheet("""
            QLabel {
                color: #00ff88;
                background-color: rgba(0, 0, 0, 200);
                padding: 8px 16px;
                border-radius: 8px;
                font-size: 14px;
            }
        """)
        self.version_update_label.setAlignment(Qt.AlignCenter)
        # Move below the login button to avoid overlap (button is at y=30-90)
        self.version_update_label.setGeometry(self.width() - 350, 110, 320, 40)
        self.version_update_label.setVisible(False)

        # Set up context menu
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)

        # Initialize system tray
        self.init_system_tray()

    def init_system_tray(self):
        """Initialize system tray icon and menu"""
        try:
            self.tray_icon = QSystemTrayIcon(self)
            # Use a default icon if resources don't exist
            icon_path = "resources/tray_icon.png"
            if os.path.exists(icon_path):
                self.tray_icon.setIcon(QIcon(icon_path))
            else:
                # Create a simple icon
                self.tray_icon.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon))

            self.tray_icon.setToolTip("Fatih Akıllı Tahta")

            # Create tray menu
            tray_menu = QMenu()
            show_action = QAction("Göster", self)
            show_action.triggered.connect(self.show)
            tray_menu.addAction(show_action)

            hide_action = QAction("Gizle", self)
            hide_action.triggered.connect(self.hide)
            tray_menu.addAction(hide_action)

            tray_menu.addSeparator()

            exit_action = QAction("Çıkış", self)
            exit_action.triggered.connect(QApplication.quit)
            tray_menu.addAction(exit_action)

            self.tray_icon.setContextMenu(tray_menu)
            self.tray_icon.show()

            # Balloon tip
            self.tray_icon.showMessage(
                "Fatih Client",
                "Program çalışıyor ve sistem korunuyor.",
                QSystemTrayIcon.MessageIcon.Information,
                3000
            )

        except Exception as e:
            logging.error(f"System tray initialization failed: {e}")

    def show_schedule_dialog(self):
        """C# FormGirisCikisSaatleri birebir karşılığı.
        
        7 gün butonu (radioButton1-7) + 18 ders satırı (txtg/txtc 1-18).
        Açılışta bugünün günü seçili gelir, gün butonlarına tıklanınca
        o günün giriş-çıkış saatleri listelenir.
        
        Veri: self.schedule['hours'] = list[8], hours[gun] = dict {"1": ["", "08:30", "09:10"], ...}
        """
        # Eğer zaten açıksa öne getir
        if hasattr(self, '_schedule_dialog_ref') and self._schedule_dialog_ref is not None:
            try:
                if self._schedule_dialog_ref.isVisible():
                    self._schedule_dialog_ref.raise_()
                    self._schedule_dialog_ref.activateWindow()
                    return
            except RuntimeError:
                self._schedule_dialog_ref = None

        logging.info(f"[SCHEDULE_DIALOG] Opening weekly view")

        dlg = QDialog()
        dlg.setWindowTitle("Giriş Çıkış Saatleri")
        dlg.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.X11BypassWindowManagerHint
        )
        dlg.setFixedSize(420, 560)
        dlg.setStyleSheet("background-color: #1a1a2e; color: white; border: 2px solid #16213e; border-radius: 10px;")
        
        main_layout = QVBoxLayout(dlg)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(8)
        
        # Başlık
        title = QLabel("🕒 Giriş Çıkış Saatleri")
        title.setFont(QFont('Sans', 16, QFont.Bold))
        title.setStyleSheet("color: #e94560; margin-bottom: 2px;")
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)
        
        # --- GÜN BUTONLARI (C# radioButton1-7) ---
        days_tr = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"]
        days_full = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
        
        day_btn_layout = QHBoxLayout()
        day_btn_layout.setSpacing(3)
        day_buttons = []
        
        today_iso = simdi().isoweekday()  # 1=Pzt, 7=Paz
        
        for i, day_name in enumerate(days_tr):
            day_idx = i + 1  # 1-7
            btn = QPushButton(day_name)
            btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            btn.setFixedHeight(36)
            btn.setCheckable(True)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #16213e; color: #aaa; font-size: 13px; 
                    font-weight: bold; border-radius: 5px; border: 1px solid #1a1a4e;
                    padding: 4px 2px;
                }
                QPushButton:checked {
                    background-color: #e94560; color: white; border: 1px solid #e94560;
                }
                QPushButton:hover {
                    background-color: #0f3460;
                }
            """)
            day_buttons.append(btn)
            day_btn_layout.addWidget(btn)
        
        main_layout.addLayout(day_btn_layout)
        
        # Seçili gün başlığı
        selected_day_label = QLabel("")
        selected_day_label.setStyleSheet("color: #4CAF50; font-weight: bold; font-size: 15px;")
        selected_day_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(selected_day_label)
        
        # --- DERS SAATLERİ LİSTESİ (ScrollArea) ---
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background-color: transparent; }")
        
        content = QWidget()
        content.setStyleSheet("background-color: transparent;")
        content_layout = QVBoxLayout(content)
        content_layout.setAlignment(Qt.AlignTop)
        content_layout.setSpacing(3)
        scroll.setWidget(content)
        main_layout.addWidget(scroll)
        
        # --- Gün değiştiğinde listeyi güncelleyen fonksiyon (C# SetAndChangeEvent) ---
        def load_day(day_idx):
            # Önce tüm butonları kaldır, seçili olanı işaretle
            for j, b in enumerate(day_buttons):
                b.setChecked((j + 1) == day_idx)
            
            selected_day_label.setText(f"📅 {days_full[day_idx - 1]}")
            
            # Mevcut satırları temizle
            while content_layout.count():
                item = content_layout.takeAt(0)
                w = item.widget()
                if w:
                    w.deleteLater()
            
            if not self.schedule or not isinstance(self.schedule, dict) or 'hours' not in self.schedule:
                lbl = QLabel("Saat bilgisi henüz sunucudan alınmadı.")
                lbl.setStyleSheet("font-size: 14px; color: #ff6b6b;")
                lbl.setAlignment(Qt.AlignCenter)
                content_layout.addWidget(lbl)
                return
            
            hours_data = self.schedule['hours']
            day_schedule = None
            
            if isinstance(hours_data, list) and day_idx < len(hours_data):
                day_schedule = hours_data[day_idx]
            elif isinstance(hours_data, dict):
                day_schedule = hours_data.get(str(day_idx))
            
            found = False
            
            if isinstance(day_schedule, dict):
                # hours[gun] = {"1": ["", "08:30", "09:10"], "2": [...], ...}
                for k in range(1, 19):
                    slot = day_schedule.get(str(k))
                    if slot and isinstance(slot, list) and len(slot) >= 3:
                        s = slot[1] if slot[1] else ""
                        e = slot[2] if slot[2] else ""
                        s = self._format_time(s)
                        e = self._format_time(e)
                        if s and e and s != "0" and e != "0":
                            row = QLabel(f"  <b>{k}. Ders:</b>  {s}  ➜  {e}")
                            row.setStyleSheet("font-size: 14px; padding: 5px 8px; background-color: #16213e; border-radius: 5px;")
                            content_layout.addWidget(row)
                            found = True
                            
            elif isinstance(day_schedule, list):
                for k in range(1, min(19, len(day_schedule))):
                    pd = day_schedule[k]
                    if isinstance(pd, list) and len(pd) >= 3:
                        s = pd[1] if pd[1] else ""
                        e = pd[2] if pd[2] else ""
                        s = self._format_time(s)
                        e = self._format_time(e)
                        if s and e and s != "0" and e != "0":
                            row = QLabel(f"  <b>{k}. Ders:</b>  {s}  ➜  {e}")
                            row.setStyleSheet("font-size: 14px; padding: 5px 8px; background-color: #16213e; border-radius: 5px;")
                            content_layout.addWidget(row)
                            found = True
            
            if not found:
                lbl = QLabel("Bu gün için ders saati tanımlanmamış.")
                lbl.setStyleSheet("font-size: 14px; color: #aaa;")
                lbl.setAlignment(Qt.AlignCenter)
                content_layout.addWidget(lbl)
        
        # Gün butonlarına tıklama sinyali bağla
        for i, btn in enumerate(day_buttons):
            day_idx = i + 1
            btn.clicked.connect(lambda checked, d=day_idx: load_day(d))
        
        # Kapat butonu
        btn_close = QPushButton("✕ Kapat")
        btn_close.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        btn_close.setStyleSheet("background-color: #e94560; color: white; font-weight: bold; padding: 10px; font-size: 15px; border-radius: 6px; border: none;")
        btn_close.clicked.connect(dlg.close)
        main_layout.addWidget(btn_close)
        
        # Referansı sakla
        self._schedule_dialog_ref = dlg
        
        # Ekranın ortasına konumlandır
        screenGeometry = QApplication.primaryScreen().geometry()
        x = (screenGeometry.width() - dlg.width()) // 2
        y = (screenGeometry.height() - dlg.height()) // 2
        dlg.setGeometry(x, y, dlg.width(), dlg.height())
        
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()
        
        # Bugünü otomatik yükle (C# FormGirisCikisSaatleri_Load)
        load_day(today_iso)
        
        # Cinnamon WM gecikmesi için tekrar öne getir
        QTimer.singleShot(200, self._raise_schedule_dialog)
    
    def _raise_schedule_dialog(self):
        """Schedule dialog'u kilit ekranının üstüne zorla"""
        try:
            if hasattr(self, '_schedule_dialog_ref') and self._schedule_dialog_ref is not None:
                self._schedule_dialog_ref.raise_()
                self._schedule_dialog_ref.activateWindow()
        except (RuntimeError, Exception):
            self._schedule_dialog_ref = None

    def toggle_help_guide(self):
        """(i) butonuna basıldığında yardım kılavuzunu göster/gizle (top-level window)."""
        if not hasattr(self, 'help_guide_label'):
            return
        if self.help_guide_label.isVisible():
            self.help_guide_label.hide()
            # Kılavuz kapandı -> bilgi panellerini geri getir
            self._restore_info_panels()
            logging.info("Help guide hidden")
        else:
            # Yardım kılavuzu doğum günü / aferin panellerinin üstüne binmesin -> önce onları gizle
            self._hide_info_panels()
            # Ekran koordinatlarına göre konumlandır (sağ üst köşe)
            guide_w, guide_h = 400, 320
            guide_x = self.width() - guide_w - 30
            guide_y = 110  # (i) butonunun altı
            self.help_guide_label.setGeometry(guide_x, guide_y, guide_w, guide_h)
            self.help_guide_label.show()
            self.help_guide_label.raise_()
            logging.info(f"Help guide shown at ({guide_x},{guide_y})")

    def init_network_timer(self):
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.poll_server)
        # Use configurable polling interval (default 5 seconds)
        polling_interval = int(SETTINGS.get('polling_interval', 5)) * 1000  # Convert to milliseconds
        self.timer.start(polling_interval)
        logging.info(f"Server polling timer started with {polling_interval/1000} second interval")

    def on_usb_unlock(self):
        """Handles the event of a USB unlock by logging and unlocking."""
        logging.info("USB unlock signal received.")
        self.save_log("USB anahtar ile giriş yapıldı", "login")
        self.unlock_system("USB ile açıldı")

    def init_usb_monitor(self):
        self.usb_monitor = UdevMonitor()
        self.usb_monitor.usbUnlockSignal.connect(self.on_usb_unlock)
        self.usb_monitor.usbRemoveSignal.connect(self.remove_system)
        self.usb_monitor.usbRemovedSignal.connect(lambda: self.lock_system("USB çıkarıldığı için kilitlendi"))  # NEW: Handle USB removal
        self.usb_monitor.start()
        
    def init_usb_check_timer(self):
        """
        NEW: Initialize timer for periodic USB checks (equivalent to C# CheckInternetWork)
        """
        self.usb_check_timer = QTimer(self)
        self.usb_check_timer.timeout.connect(self.check_usb_status)
        # This can be made configurable if needed
        usb_check_interval = int(SETTINGS.get('usb_check_interval', 3)) * 1000  # Convert to milliseconds
        self.usb_check_timer.start(usb_check_interval)
        logging.info(f"USB check timer started with {usb_check_interval/1000} second interval")

    def init_maintenance_timer(self):
        """
        NEW: Initialize timer for maintenance tasks (GetValues, version check, etc.)
        """
        self.maintenance_timer = QTimer(self)
        self.maintenance_timer.timeout.connect(self.perform_maintenance)
        # Run maintenance every 25 seconds (equivalent to C# dkk >= 25)
        maintenance_interval = int(SETTINGS.get('maintenance_interval', 25)) * 1000  # Convert to milliseconds
        self.maintenance_timer.start(maintenance_interval)
        logging.info(f"Maintenance timer started with {maintenance_interval/1000} second interval")

    def init_time_timer(self):
        """Initialize timer for updating time display"""
        self.time_timer = QTimer(self)
        self.time_timer.timeout.connect(self.update_time_display)
        self.time_timer.start(1000)  # Update every second
        self.update_time_display()  # Initial update

    def init_schedule_timer(self):
        """Initialize timer for checking the schedule every 20 seconds."""
        self.schedule_timer = QTimer(self)
        self.schedule_timer.timeout.connect(self.check_schedule)
        self.schedule_timer.start(20000)  # Check every 20 seconds
        logging.info("Schedule check timer started with 20 second interval")

    def init_display_timer(self):
        """Feature 5: kilit ekrani gosterim verisi (ilk-5 aferin) icin timer.
        Veri yavas degisir -> 5 dk. Ilk cekim biraz gecikmeli (ag/token otursun)."""
        self.display_timer = QTimer(self)
        self.display_timer.timeout.connect(self.refresh_display)
        # 2 dakika: /poll zaten 5 saniyede bir calisiyor (saatte ~720 istek), /display'in
        # saatte 30 istegi bunun yaninda ihmal edilebilir. Sunucuda 60sn cache tepe yuku emiyor.
        self.display_timer.start(120000)
        QTimer.singleShot(2500, self.refresh_display)
        logging.info("Display (aferin panel) timer started with 2 minute interval")

    def refresh_display(self):
        """Gosterim verisini (v5 /display) ARKA PLAN thread'inde ceker; sonucu _display_ready
        sinyaliyle UI thread'ine tasir. Boylece ag gecikmesi kilit ekranini dondurmaz."""
        def _worker():
            try:
                data = self.network_client.get_display()
            except Exception as e:
                logging.error(f"/display cekimi basarisiz: {e}")
                data = None
            self._display_ready.emit(data)

        threading.Thread(target=_worker, daemon=True).start()

    def _render_display(self, data):
        """/display sonucunu ilgili panellere dagitir (UI thread)."""
        # Son veriyi sakla: giris ekrani kapaninca ag'a tekrar gitmeden geri cizebilelim.
        self._last_display_data = data if isinstance(data, dict) else None

        # Sınav ekranı gösteriliyorsa (pencere aktif + kilitli) normal panelleri ÇİZME.
        if self._exam_showing():
            self._hide_info_panels()
            if getattr(self, 'exam_panel', None) is not None and self.exam_panel.isVisible():
                self.exam_panel.raise_()
            return

        # Sifre/giris paneli aciksa panelleri CIZME — numpad'i kapatmasinlar.
        if getattr(self, 'login_panel', None) is not None and self.login_panel.isVisible():
            self._hide_info_panels()
            return

        d = self._last_display_data or {}
        # Sira onemli: birthday, aferin+yoklama panellerinin ARASINA ortalanir; o yuzden
        # once yan paneller cizilir (genislik/gorunurluk hazir olsun), en son birthday.
        self._render_aferin_panel(d.get("aferinTop5"))
        self._render_yoklama_panel(d.get("yoklamaYok"))
        self._render_birthday_panel(d.get("dogumGunleri"))
        # Duyuru: aktif ders saati + doğum günü kapısına göre slider'ı yönet (birthday'den SONRA).
        self._update_duyuru_state()

    def _hide_info_panels(self):
        """Aferin + dogum gunu + yoklama panellerini gizler (sifre girisi, dialog vb. sirasinda)."""
        if getattr(self, 'aferin_panel', None) is not None:
            self.aferin_panel.hide()
        if getattr(self, 'birthday_panel', None) is not None:
            self.birthday_panel.hide()
        if getattr(self, 'yoklama_panel', None) is not None:
            self.yoklama_panel.hide()
        self._hide_duyuru_panel(keep_state=True)

    def _restore_info_panels(self):
        """Gizlenen panelleri son veriyle yeniden cizer (ag'a gitmeden)."""
        if getattr(self, 'login_panel', None) is not None and self.login_panel.isVisible():
            return  # hala giris ekrani acik
        # Sınav penceresi aktifse (kilit ekranı = sınav) normal panel yerine oturma düzenini çiz.
        if getattr(self, '_exam_on', False):
            self._hide_info_panels()
            self._render_exam_panel(self._exam_data or {})
            return
        d = getattr(self, '_last_display_data', None) or {}
        self._render_aferin_panel(d.get("aferinTop5"))
        self._render_yoklama_panel(d.get("yoklamaYok"))
        self._render_birthday_panel(d.get("dogumGunleri"))
        self._update_duyuru_state()

    def _clear_layout(self, layout):
        """Bir layout'un tum widget'larini temizler (paneller her yenilemede yeniden kurulur)."""
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

    def _render_birthday_panel(self, dogumGunleri):
        """Bugun dogum gunu olan ogrencileri ekran ortasinda kutlar. Bos/None -> gizle."""
        if not dogumGunleri:
            self.birthday_panel.hide()
            return

        self._clear_layout(self.bday_rows_layout)

        for r in dogumGunleri:
            adi = str(r.get('adi', '') or '')
            yas = r.get('yas')

            name_lbl = QLabel(adi, self.birthday_panel)
            name_lbl.setObjectName("bdayName")
            name_lbl.setAlignment(Qt.AlignCenter)
            # Uzun ad (ör. "ANIL TOPRAK KARABULUT") dar kartta yatayda kirpiliyordu;
            # word-wrap ile alt satira kayar, hicbir genislikte kesilmez.
            name_lbl.setWordWrap(True)
            self.bday_rows_layout.addWidget(name_lbl)
            name_lbl.show()   # bkz. _render_aferin_panel: gorunur parent'a eklenen cocuk otomatik gosterilmez

            if yas:
                age_lbl = QLabel(f"bugün {int(yas)} yaşında 🎂", self.birthday_panel)
                age_lbl.setObjectName("bdayAge")
                age_lbl.setAlignment(Qt.AlignCenter)
                self.bday_rows_layout.addWidget(age_lbl)
                age_lbl.show()

        # Tekil/cogul: iki ogrencinin ayni gun dogum gunu olabilir.
        cogul = len(dogumGunleri) > 1
        self.bday_title.setText("İYİ Kİ DOĞDUNUZ!" if cogul else "İYİ Kİ DOĞDUN!")

        sinif = SETTINGS.get('board_name', '') or ''
        if sinif:
            self.bday_sub.setText(
                f"{sinif} sınıfı {'sizinle' if cogul else 'seninle'} gurur duyuyor"
            )
        else:
            self.bday_sub.setText("Doğum gününüz kutlu olsun" if cogul else "Doğum günün kutlu olsun")

        # Yerlesim: aferin paneli gorunurse ONUN SAGINDAKI bos alana ortala (uzerine binmesin),
        # gorunmuyorsa ekranin tam ortasina. Dar ekranlarda panel genisligi kisilir.
        # Aferin paneli DOLU mu? isVisible() KULLANMA: Qt'de alt widget'in isVisible()'i
        # pencere henuz gosterilmemisse .show() cagrilmis olsa bile False doner -> panel
        # "yok" sanilip kutlama karti tam ortaya konuyor ve uzerine biniyordu (V6.00.08 bug'i).
        # Icerik sayisi pencere gorunurlugunden bagimsizdir, guvenilir olcut budur.
        # Kart, aferin (sol) ve yoklama (sag) panellerinin ARASINDAKI bosluga ortalanir;
        # boylece hicbir panele binmez. Panel gorunurlugu icerik sayisindan anlasilir
        # (isVisible() pencere gosterilene kadar guvenilmezdi -> V6.00.08 bug'i).
        # NOT: bu render, yan panellerden SONRA cagrilir (bkz. _apply_display_data sirasi),
        # boylece asagidaki genislik/gorunurluk olcumleri bu dongude tazedir.
        GAP = 24
        left_bound = 0
        if self.aferin_rows_layout.count() > 0:
            left_bound = self.aferin_panel.x() + self.aferin_panel.width() + GAP

        right_bound = self.width()
        if self.yoklama_rows_layout.count() > 0:
            right_bound = self.width() - self.yoklama_panel.width() - 16 - GAP

        avail = max(0, right_bound - left_bound)
        # Orta pano ONE CIKAR (ileride duyuru panosu): yan listeler 370px'e daraltildi,
        # burada tavan 920'ye cikarildi ki genis tahtada baskin dursun. Iki panelin
        # arasindaki bosluktan tasmaz; dar ekranda 380'e kadar kucululur.
        bw = max(380, min(920, avail - 32))
        self.birthday_panel.setFixedWidth(bw)

        # Yukseklik word-wrap'i sayarak bw genisliginde hesaplanir (bkz. _fit_panel_height).
        self._fit_panel_height(self.birthday_panel)
        bh = self.birthday_panel.height()
        bx = left_bound + max(0, (avail - bw) // 2)
        # Ekrandan tasmasin
        bx = min(bx, max(0, self.width() - bw))
        self.birthday_panel.move(bx, (self.height() - bh) // 2)
        self.birthday_panel.show()
        self.birthday_panel.raise_()

    # ----------------------------------------------------------------------------
    # DUYURU (sınıf+ders saati hedefli, orta pano slider)
    # ----------------------------------------------------------------------------
    def init_duyuru_timers(self):
        """İki timer: (1) durum değerlendirme — periyot değişimi + 10dk doğum günü kapısı
        için 10 sn'de bir; (2) slayt geçişi — sadece slider görünürken çalışır."""
        self.duyuru_state_timer = QTimer(self)
        self.duyuru_state_timer.timeout.connect(self._update_duyuru_state)
        self.duyuru_state_timer.start(10000)

        self.duyuru_slide_timer = QTimer(self)
        self.duyuru_slide_timer.timeout.connect(self._advance_duyuru_slide)

        # id -> QPixmap (basarili) | False (denendi, olmadi) | yok (henuz denenmedi)
        # Slayt 8 saniyede bir donuyor; onbellek olmadan ayni resim tekrar tekrar
        # indirilir ve okul agi bosuna mesgul edilirdi.
        self._duyuru_resim_onbellek = {}
        self._duyuru_resim_geldi.connect(self._on_duyuru_resim_geldi)
        # start/stop _update_duyuru_state içinde yönetilir (yalnız >1 duyuru varken çalışır).

    # ----------------------------------------------------------------------------
    # SINAV OTURMA DÜZENİ (tam ekran sınav modu)
    # ----------------------------------------------------------------------------
    def init_time_sync(self):
        """Ağ saati senkronu: açılışta hemen, sonra 6 saatte bir (arka planda, UI'yı bloklamaz).
        Tahtanın sistem saati kayarsa otomatik kilit/sınav penceresi/duyuru yanlış çalışırdı."""
        def _sync():
            threading.Thread(target=sync_network_time, daemon=True).start()
        self.time_sync_timer = QTimer(self)
        self.time_sync_timer.timeout.connect(_sync)
        self.time_sync_timer.start(6 * 60 * 60 * 1000)   # 6 saat
        QTimer.singleShot(1500, _sync)                   # açılışta (ağ otursun diye kısa gecikme)
        logging.info("Ağ saati senkron timer'ı başlatıldı (6 saat)")

    def init_exam_timer(self):
        """Sınav oturma düzeni yoklaması (v5 /sinav_oturma). Veri seyrek değişir -> 45 sn."""
        self.exam_timer = QTimer(self)
        self.exam_timer.timeout.connect(self.refresh_exam)
        self.exam_timer.start(45000)
        QTimer.singleShot(4000, self.refresh_exam)  # ilk çekim (ağ/token otursun)

        # Sınav saatinin gelmesini 45 sn beklemeyelim: elde tutulan sınav verisiyle her 10 sn'de
        # bir YEREL değerlendirme yapılır -> saat gelir gelmez (en geç 10 sn) kilit + ekran devreye
        # girer. Ağ gerektirmez; bu yüzden internet kesik olsa bile sınav ekranı zamanında açılır.
        self.exam_tick_timer = QTimer(self)
        self.exam_tick_timer.timeout.connect(self._exam_tick)
        self.exam_tick_timer.start(10000)
        logging.info("Sınav timer'ları başlatıldı (veri 45 sn, yerel değerlendirme 10 sn)")

    def _exam_tick(self):
        """Ağdan bağımsız yerel değerlendirme (10 sn): sınav penceresi açıldı/kapandı mı?"""
        veri = getattr(self, '_exam_data', None)
        if veri:
            self._apply_exam(veri)

    def refresh_exam(self):
        """/sinav_oturma'yı ARKA PLAN thread'inde çeker; sonucu _exam_ready ile UI thread'ine taşır."""
        def _worker():
            try:
                data = self.network_client.get_sinav_oturma()
            except Exception as e:
                logging.error(f"/sinav_oturma çekimi başarısız: {e}")
                data = None
            self._exam_ready.emit(data)
        threading.Thread(target=_worker, daemon=True).start()

    def _exam_time_reached(self, saat):
        """Sınav başlangıç saati (HH:mm) bugün geldi mi? Parse edilemezse güvenli taraf: True."""
        try:
            parts = str(saat).split(':')
            hh = int(parts[0])
            mm = int(parts[1]) if len(parts) > 1 else 0
            now = simdi()
            exam_dt = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
            return now >= exam_dt
        except Exception:
            return True

    def _exam_window_active(self, data):
        """Sınav penceresi ŞU AN açık mı? aktif=true VE saat<=now VE (bitis boş ya da now<bitis)."""
        if not bool(data.get('aktif')):
            return False
        if not self._exam_time_reached(data.get('saat')):
            return False                       # başlangıç saati gelmedi
        bitis = data.get('bitis')
        if bitis:
            if self._exam_time_reached(bitis):
                return False                   # bitiş geçti -> gösterimi durdur
            return True
        # Bitiş saati gönderilmemişse ekran gün boyu açık kalmasın: başlangıçtan
        # EXAM_VARSAYILAN_SURE_DK sonra kendiliğinden kapanır (güvenli varsayılan).
        try:
            p = str(data.get('saat') or '').split(':')
            bas = simdi().replace(hour=int(p[0]), minute=int(p[1]) if len(p) > 1 else 0,
                                  second=0, microsecond=0)
            return simdi() < bas + timedelta(minutes=EXAM_VARSAYILAN_SURE_DK)
        except Exception:
            return True

    def _exam_showing(self):
        """Sınav ekranı şu an gösteriliyor olmalı mı? = sınav penceresi aktif VE tahta kilitli."""
        return getattr(self, '_exam_on', False) and getattr(self, 'is_locked', False)

    def _apply_exam(self, data):
        """/sinav_oturma sonucunu uygular (UI thread). data None -> ağ hatası, mevcut durumu koru.

        MODEL: sınav ekranı = KİLİTLİYKEN gösterilen bir mod; kilidi ZORLA tutmaz. Sadece saat
        gelince tahta AÇIKSA bir kez otomatik kilitler (ekran gelsin). Sonrası: mebrecep/ynt5/
        masaüstü müdahaleleri her zaman öncelikli — açarsa açık kalır, tekrar kilitlerse (sınav
        penceresi hâlâ aktifse) ekran geri gelir. bitiş saati geçince gösterim durur."""
        if data is None:
            return  # ağ/parse hatası — mevcut durumu bozma

        self._exam_data = data if bool(data.get('aktif')) else None

        if not self._exam_window_active(data):
            # Sınav yok / saati gelmedi / bitti -> sınav modu kapalı.
            self._exam_on = False
            if not bool(data.get('aktif')):
                self._exam_locked_for = None   # sınav bitti -> ilk-kilit hafızasını sıfırla
            self._hide_exam_panel()
            return

        # Sınav penceresi aktif.
        self._exam_on = True
        sid = data.get('sinav_id')
        # İLK otomatik kilit: sınav saati geldiği AN, tahta AÇIKSA bir kez kilitle (ekran gelsin);
        # zaten kilitliyse sadece göster. İşaret (_exam_locked_for) pencere aktifleşir aktifleşmez
        # konur — tahta o an kilitli olsa bile. Aksi halde öğretmen sınav sırasında tahtayı açınca
        # sistem tekrar kilitliyordu (müdahale önceliği kuralına aykırı).
        if self._exam_locked_for != sid:
            self._exam_locked_for = sid
            if not self.is_locked:
                logging.info(f"Sınav saati geldi (sinav_id={sid}) — tahta açıktı, kilitleniyor.")
                self.lock_system("Sınav oturma düzeni")   # -> _restore_info_panels -> exam çizilir

        # Ekran durumu: kilitliyse oturma düzenini göster; açılmışsa (müdahale) dokunma.
        if self.is_locked:
            self._render_exam_panel(data)
        else:
            self._hide_exam_panel()

    def _hide_exam_panel(self):
        """Sınav panelini + kutularını gizler. Tahta KİLİDİNE DOKUNMAZ. Sınav modu kapalı AMA
        tahta hâlâ kilitliyse normal paneller (aferin/duyuru...) geri gelir."""
        # Panel gerçekten görünüyor muydu? Normal panelleri YALNIZ geçişte geri çiz — aksi halde
        # 10 sn'lik yerel değerlendirme her turda gereksiz yere hepsini yeniden çizerdi.
        goruniyordu = (getattr(self, 'exam_panel', None) is not None and self.exam_panel.isVisible())
        self._exam_rendered_id = None
        if getattr(self, 'exam_yok_panel', None) is not None:
            self.exam_yok_panel.hide()
        if getattr(self, 'exam_panel', None) is not None:
            self.exam_panel.hide()
        for b in getattr(self, '_exam_boxes', []):
            try:
                b.setParent(None)
                b.deleteLater()
            except Exception:
                pass
        self._exam_boxes = []
        if goruniyordu and getattr(self, 'is_locked', False) and not getattr(self, '_exam_on', False):
            self._restore_info_panels()

    @staticmethod
    def _fit_font_px(text, max_w, start_px, min_px, bold=False, tek_satir=False):
        """Metnin verilen genişliğe SIĞACAĞI en büyük font boyutunu (px) döner.
        tek_satir=False -> satır sarma var, yalnız EN UZUN KELİME sığmalı (ad soyad).
        tek_satir=True  -> metnin tamamı tek satıra sığmalı (No/Sıra bilgisi).
        Ölçüm QFontMetrics ile gerçek font üzerinden yapılır (tahminle değil)."""
        s = str(text or '')
        parcalar = [s] if tek_satir else ([w for w in s.split() if w] or [s])
        f = QFont('DejaVu Sans')
        f.setBold(bold)
        for px in range(int(start_px), int(min_px) - 1, -1):
            f.setPixelSize(px)
            fm = QFontMetrics(f)
            olc = getattr(fm, 'horizontalAdvance', None) or fm.width
            if max(olc(p) for p in parcalar) <= max_w:
                return px
        return int(min_px)

    def _raise_exam_controls(self):
        """'Tahtayı Açın' ve (i) butonlarını sınav panelinin üstüne çıkarır. Tam ekran sınav
        ekranı bunları örterse öğretmen tahtayı açamaz — her çizimde tekrar öne alınır."""
        for ad in ('login_button', 'help_toggle_button'):
            w = getattr(self, ad, None)
            if w is not None:
                try:
                    w.raise_()
                    w.show()
                except Exception:
                    pass

    def _update_exam_clock(self):
        """Sinav ekranindaki canli saati (ag saatiyle senkron) tazeler.
        Font, etiket genisligine gore OLCULEREK secilir -> saat ASLA kirpilmaz
        (once "17:17:35" yerine "17:17:3" gorunuyordu)."""
        lbl = getattr(self, 'exam_clock', None)
        if lbl is None:
            return
        metin = simdi().strftime("%d.%m.%Y   %H:%M:%S")
        gen = max(120, lbl.width() - 8)
        px = self._fit_font_px(metin, gen, 26, 13, bold=True, tek_satir=True)
        lbl.setStyleSheet(
            f"color:#E6EEF9; font-family:'DejaVu Sans'; font-size:{px}px;"
            f"font-weight:bold; background:transparent;")
        lbl.setText(metin)

    def _render_exam_panel(self, data):
        """Tam ekran oturma düzenini çizer: header (salon/ders/saat) + x/y grid öğrenci kutuları +
        gözetmenler. Koordinatlar salon-yerel/seyrek olabilir -> min çıkar, ekrana sığacak ölçekle.
        Küçük y = tahtaya/öne yakın (üstte)."""
        # Çizim anahtarı: sınav + YOKLAMA durumu. Yoklama sonradan alınır/değişir (gözetmen
        # MebreCep'ten işaretler) -> anahtar değişince yeniden çizilir. Sadece sinav_id'ye
        # bakılsaydı gelmeyenler listesi hiç güncellenmezdi.
        sid = (data.get('sinav_id'),
               bool(data.get('yoklamaAlindi')),
               tuple(sorted(str(g.get('no', '')) + '|' + str(g.get('ad', ''))
                            for g in (data.get('gelmeyenler') or []) if isinstance(g, dict))))
        # Aynı içerik zaten çiziliyse yeniden KURMA (45sn'de bir titreme olmasın) — sadece üstte tut.
        if (self._exam_rendered_id == sid and getattr(self, 'exam_panel', None) is not None
                and self.exam_panel.isVisible()):
            self.exam_panel.raise_()
            self._raise_exam_controls()
            self._update_exam_clock()
            return
        self._exam_rendered_id = sid
        W = self.width()
        H = self.height()
        self.exam_panel.setGeometry(0, 0, W, H)

        salon = str(data.get('salon') or '')
        ders = str(data.get('ders_adi') or data.get('sinav_adi') or '')
        saat = str(data.get('saat') or '')
        bitis = str(data.get('bitis') or '')
        # Sınav saati ARALIK olarak yazılır (başlangıç–bitiş) — "Saat 09:30" tek başına
        # ne zaman biteceğini söylemiyordu.
        aralik = f"{saat} – {bitis}" if (saat and bitis) else (saat or '')
        self.exam_subheader.setText(
            f"{ders}   ·   Salon {salon}" + (f"   ·   {aralik}" if aralik else ""))

        gorevliler = [g for g in (data.get('gorevliler') or []) if isinstance(g, dict)]
        self.exam_footer.setText("        ".join(
            f"{(g.get('gorev') or '')}: {(g.get('ad') or '')}".strip(" :") for g in gorevliler))

        # Sabit bölgeler (üst: başlık + canlı saat; alt: lejant ve gözetmenler)
        self.exam_header.setGeometry(0, 26, W, 50)
        self.exam_subheader.setGeometry(0, 80, W, 34)
        self.exam_front.setGeometry(0, 120, W, 20)
        # Saat SOL ustte: sag ust kose "Tahtayi Acin" + (i) butonlarina ait.
        # Genislik bol tutulur ve font olculerek sigdirilir — aksi halde saniye kirpiliyordu.
        self.exam_clock.setGeometry(30, 24, 430, 46)
        self.exam_clock.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self._update_exam_clock()
        self.exam_clock.show()

        # Lejant KALDIRILDI: "Amber / kesik cerceve" gibi teknik ifadelerin sinif ekraninda yeri
        # yok; kutudaki "GELMEDI" rozeti zaten kendini anlatiyor.
        self.exam_legend.hide()

        self.exam_footer.setGeometry(20, H - 58, W - 40, 44)

        # --- Sınava gelmeyenler (gözetmen MebreCep'ten yoklama alınca dolar) ---
        # Yoklama alındıysa sağda bir kolon ayrılır; grid o kadar daralır. Alınmadıysa panel gizli
        # ve grid tüm genişliği kullanır.
        gelmeyenler = [g for g in (data.get('gelmeyenler') or []) if isinstance(g, dict)]
        yoklama_alindi = bool(data.get('yoklamaAlindi'))
        yok_w = 0
        self._clear_layout(self.exam_yok_rows)
        if yoklama_alindi:
            yok_w = max(240, min(340, int(W * 0.22)))
            if gelmeyenler:
                self.exam_yok_title.setText(f"🚫  SINAVA GELMEYENLER  ({len(gelmeyenler)})")
                for g in gelmeyenler[:14]:
                    r = QLabel(f"{g.get('no', '')}  ·  {g.get('ad', '')}".strip(" ·"), self.exam_yok_panel)
                    r.setObjectName("examYokRow")
                    r.setWordWrap(True)
                    self.exam_yok_rows.addWidget(r)
                    r.show()
                if len(gelmeyenler) > 14:
                    more = QLabel(f"+{len(gelmeyenler) - 14} kişi daha", self.exam_yok_panel)
                    more.setObjectName("examYokEmpty")
                    self.exam_yok_rows.addWidget(more)
                    more.show()
            else:
                self.exam_yok_title.setText("✅  SINAV YOKLAMASI")
                r = QLabel("Tüm öğrenciler sınavda.", self.exam_yok_panel)
                r.setObjectName("examYokEmpty")
                r.setWordWrap(True)
                self.exam_yok_rows.addWidget(r)
                r.show()
            self.exam_yok_panel.setGeometry(W - yok_w - 24, 152, yok_w, H - 152 - 100)
            self.exam_yok_panel.show()
            self.exam_yok_panel.raise_()
        else:
            self.exam_yok_panel.hide()

        # Eski öğrenci kutularını temizle
        for b in getattr(self, '_exam_boxes', []):
            try:
                b.setParent(None)
                b.deleteLater()
            except Exception:
                pass
        self._exam_boxes = []

        ogr = [o for o in (data.get('ogrenciler') or []) if isinstance(o, dict)]
        if ogr:
            xs, ys = [], []
            for o in ogr:
                try:
                    xs.append(int(o.get('x', 0)))
                    ys.append(int(o.get('y', 0)))
                except Exception:
                    xs.append(0)
                    ys.append(0)
            minx, maxx = min(xs), max(xs)
            miny, maxy = min(ys), max(ys)
            ncols = max(1, maxx - minx + 1)
            nrows = max(1, maxy - miny + 1)

            # Grid alanı: header altında, footer üstünde; gelmeyenler paneli varsa sağdan daralır.
            top, bottom, left = 152, H - 100, 40
            right = W - 50 - (yok_w + 24 if yok_w else 0)
            gw = max(1, right - left)
            gh = max(1, bottom - top)
            cellW = gw / ncols
            cellH = gh / nrows
            gap = 10
            boxW = min(max(96, int(cellW - gap)), 340)
            boxH = min(max(78, int(cellH - gap)), 190)
            ic_genislik = max(30, boxW - 14)   # kutu ici kullanilabilir genislik (kenar bosluklari dusuk)

            for o in ogr:
                try:
                    col = int(o.get('x', 0)) - minx
                    row = int(o.get('y', 0)) - miny
                except Exception:
                    col, row = 0, 0
                cx = int(left + col * cellW + (cellW - boxW) / 2.0)
                cy = int(top + row * cellH + (cellH - boxH) / 2.0)
                # Sınava gelmeyen öğrencinin kutusu kırmızı + "GELMEDİ" etiketli.
                yok = bool(o.get('yok'))
                box = QFrame(self.exam_panel)
                box.setObjectName("examBoxYok" if yok else "examBox")
                box.setAttribute(Qt.WA_StyledBackground, True)
                box.setGeometry(cx, cy, boxW, boxH)
                bl = QVBoxLayout(box)
                bl.setContentsMargins(6, 5, 6, 5)
                bl.setSpacing(2)

                # Ad: kutuya SIĞACAK en büyük font seçilir (en uzun kelime taşmasın); satır sarar.
                ad_txt = str(o.get('ad', '') or '')
                ad_px = self._fit_font_px(ad_txt, ic_genislik, 17, 9, bold=True)
                nm = QLabel(ad_txt, box)
                nm.setObjectName("examNameYok" if yok else "examName")
                nm.setAlignment(Qt.AlignCenter)
                nm.setWordWrap(True)
                nm.setStyleSheet(
                    f"color:{'rgba(255,214,218,235)' if yok else '#FFFFFF'};"
                    f"font-family:'DejaVu Sans'; font-size:{ad_px}px; font-weight:bold; background:transparent;")

                # Bilgi satiri: ONCE tek satir denenir; okunabilir puntoda (>=11px) sigmiyorsa
                # ALT SATIRA inilir ("No 1320" / "Sira 1"). Numara ve sira ASLA kirpilmamali.
                no_txt = f"No {o.get('no', '')}"
                sira_txt = f"Sıra {o.get('sira', '')}"
                tek_txt = f"{no_txt} · {sira_txt}"
                info_px = self._fit_font_px(tek_txt, ic_genislik, 13, 8, bold=False, tek_satir=True)
                if info_px >= 11:
                    info_txt = tek_txt
                else:
                    info_txt = no_txt + "\n" + sira_txt
                    info_px = min(
                        self._fit_font_px(no_txt, ic_genislik, 13, 8, bold=False, tek_satir=True),
                        self._fit_font_px(sira_txt, ic_genislik, 13, 8, bold=False, tek_satir=True))
                info = QLabel(info_txt, box)
                info.setObjectName("examNo")
                info.setAlignment(Qt.AlignCenter)
                info.setWordWrap(True)
                info.setStyleSheet(
                    f"color:#B7DBFF; font-family:'DejaVu Sans'; font-size:{info_px}px; background:transparent;")
                bl.addWidget(nm)
                bl.addWidget(info)
                if yok:
                    tag = QLabel("GELMEDİ", box)
                    tag.setObjectName("examTagYok")
                    tag.setAlignment(Qt.AlignCenter)
                    tag_px = self._fit_font_px("GELMEDİ", ic_genislik, 13, 8, bold=True, tek_satir=True)
                    tag.setStyleSheet(
                        f"color:#FFC9CE; font-family:'DejaVu Sans'; font-size:{tag_px}px;"
                        f"font-weight:bold; background:transparent;")
                    bl.addWidget(tag)
                    tag.show()
                box.show()
                self._exam_boxes.append(box)

        self.exam_panel.setGeometry(0, 0, W, H)
        self.exam_panel.show()
        self.exam_panel.raise_()
        # Kilit ekranı kontrolleri sınav ekranının ÜSTÜNDE kalmalı: aksi halde öğretmen
        # sınav sırasında/ sonrasında tahtayı açamaz.
        self._raise_exam_controls()

    def _update_duyuru_state(self):
        """Orta panonun tek karar merciisi — KİLİT TABANLI model.

        Duyuru YALNIZ tahta KİLİTLİYKEN gösterilir (tenefüs/auto-lock/power açılışı/kilit-on-send).
        Ders saati penceresi mantığı YOK: kilitli olduğu SÜRECE bugünün tüm duyuruları döner
        (kısa 5 dk tenefüste de çalışır) — ta ki tahta açılana kadar.

        Akış: kilit değil -> gizle. Kilitliyken bugün doğum günü VAR ve kilitten bu yana <3 dk
        ise -> doğum günü öne çıkar, slider bekler. Sonra -> doğum günü gizle, slider döner.
        Öğretmen 'Durdur' -> bu kilit boyunca gizli (tahta açılıp tekrar kilitlenince sıfırlanır)."""
        if not hasattr(self, 'duyuru_slide_timer'):
            return  # timerlar henüz kurulmadı (erken çağrı koruması)

        # Sınav penceresi aktifse duyuru gösterme (tam ekran sınav üstte).
        if getattr(self, '_exam_on', False):
            self._hide_duyuru_panel()
            return

        # Şifre/giriş paneli açıkken hiçbir pano gösterme (numpad'i kapatmasın).
        if getattr(self, 'login_panel', None) is not None and self.login_panel.isVisible():
            self._hide_duyuru_panel()
            return

        # TETİK: yalnız kilitliyken. Değilse pencere zaten gizli ama garanti gizle.
        if not getattr(self, 'is_locked', False):
            self._hide_duyuru_panel()
            return

        d = getattr(self, '_last_display_data', None) or {}
        duyurular = [x for x in (d.get('duyurular') or []) if isinstance(x, dict)]

        # Duyuru yoksa -> gizle, doğum günü (varsa) yeniden görünür.
        if not duyurular:
            self._hide_duyuru_panel()
            self._restore_birthday_if_needed(d)
            return

        # Doğum günü kapısı: bugün doğum günü VAR ve KİLİTLENME anından bu yana <3 dk ise
        # kutlama öne çıksın; slider beklesin (state korunur).
        secs_since_lock = time.time() - getattr(self, 'last_lock_time', 0)
        if d.get('dogumGunleri') and secs_since_lock < DUYURU_BIRTHDAY_GATE_SEC:
            self._hide_duyuru_panel(keep_state=True)
            return

        # Slider devralıyor. Liste değiştiyse baştan kur.
        ids = [x.get('id') for x in duyurular]
        if ids != [x.get('id') for x in self._duyuru_active]:
            self._duyuru_active = duyurular
            self._duyuru_index = 0

        # Doğum günü panelini gizle (orta panoyu slider devralır).
        if getattr(self, 'birthday_panel', None) is not None:
            self.birthday_panel.hide()

        self._render_duyuru_slide()

        # Slayt geçişi yalnız birden fazla duyuru varken.
        if len(self._duyuru_active) > 1:
            if not self.duyuru_slide_timer.isActive():
                self.duyuru_slide_timer.start(DUYURU_SLIDE_MS)
        else:
            if self.duyuru_slide_timer.isActive():
                self.duyuru_slide_timer.stop()

    def _restore_birthday_if_needed(self, d):
        """Slider kapandığında, doğum günü verisi varsa ve panel gizliyse tekrar çizer.
        (Slider'ı biz gizlemiş olabiliriz.) isVisible() çalışma anında güvenilir."""
        bd = d.get('dogumGunleri')
        bp = getattr(self, 'birthday_panel', None)
        if bd and bp is not None and not bp.isVisible():
            self._render_birthday_panel(bd)

    def _hide_duyuru_panel(self, keep_state=False):
        # Panel gizleniyorsa tam ekran fotograf da kapanmali (ekranda asili kalmasin).
        self._foto_tam_ekran_kapat()
        """Slider'ı gizler + slayt timer'ını durdurur. keep_state=False durumunda slider
        bağlamını (periyot/liste/index) da sıfırlar."""
        if getattr(self, 'duyuru_panel', None) is not None:
            self.duyuru_panel.hide()
        if hasattr(self, 'duyuru_slide_timer') and self.duyuru_slide_timer.isActive():
            self.duyuru_slide_timer.stop()
        if not keep_state:
            self._duyuru_active = []
            self._duyuru_index = 0

    def _advance_duyuru_slide(self):
        # Slayt degisiyor -> acik tam ekran fotograf onceki duyuruya aitti, kapat.
        self._foto_tam_ekran_kapat()
        """Sonraki slayta geç (slayt timer'ından)."""
        if not self._duyuru_active:
            return
        self._duyuru_index = (self._duyuru_index + 1) % len(self._duyuru_active)
        self._render_duyuru_slide()

    def _duyuru_msg_px(self, text):
        """Mesaj uzunluğuna göre font boyutu (px). Uzun metinde küçülür; sabit yükseklikli
        alanda taşmayı azaltır. Tahta uzaktan okunduğu için tavan yüksek tutulur."""
        n = len(text or "")
        if n <= 120:
            return 22
        if n <= 220:
            return 19
        if n <= 360:
            return 16
        if n <= 520:
            return 14
        return 13

    # ==================== FOTOGRAF TAM EKRAN ====================
    # Tahtaya gonderilen fotograflar resmi yazi oluyor; kartta buyuk gosterilse bile
    # kucuk punto okunmayabiliyor. Tahta dokunmatik: fotografa dokununca tam ekran acilir.
    #
    # GUVENLIK (kilidi zayiflatmamak icin bilincli kisitlar):
    #  - Katman AYRI PENCERE DEGIL, kilit ekraninin COCUGU. Kilidin ustune cikamaz,
    #    kilit ekrani kapanirsa o da kapanir.
    #  - Uzerinde HICBIR etkilesim yok: buton yok, bag yok, metin girisi yok. Yalniz resim.
    #  - Her dokunusta kapanir; 20 sn'de kendiliginden de kapanir (acik unutulmasin).
    #  - Acilir acilmaz 'Tahtayi Acin' ve (i) butonlari USTE alinir -> ogretmen tahtayi
    #    her an acabilir, katman onu engellemez.
    #  - Slayt degisince, duyuru paneli gizlenince ve tahta acilinca kapatilir.
    #  - Klavye grab'ina dokunmaz; kilit mantigi bu katmandan tamamen bagimsizdir.

    def _foto_tam_ekran_hazirla(self):
        """Katmani (ilk kullanimda) olusturur."""
        if getattr(self, 'foto_tam_ekran', None) is not None:
            return
        self.foto_tam_ekran = QLabel(self)
        self.foto_tam_ekran.setObjectName("fotoTamEkran")
        self.foto_tam_ekran.setAlignment(Qt.AlignCenter)
        self.foto_tam_ekran.setStyleSheet("background-color: rgba(0,0,0,235);")
        self.foto_tam_ekran.hide()
        # Dokununca kapansin.
        self.foto_tam_ekran.mousePressEvent = lambda e: self._foto_tam_ekran_kapat()

        self.foto_tam_ekran_timer = QTimer(self)
        self.foto_tam_ekran_timer.setSingleShot(True)
        self.foto_tam_ekran_timer.timeout.connect(self._foto_tam_ekran_kapat)

    def _foto_tam_ekran_ac(self, pix):
        """Fotografi ekrani kaplayacak sekilde gosterir."""
        if pix is None or not isinstance(pix, QPixmap) or pix.isNull():
            return
        try:
            self._foto_tam_ekran_hazirla()
            # Ekranin tamamina sigdir; en-boy orani korunur (resmi yazi KIRPILMAZ).
            buyuk = pix.scaled(max(320, self.width() - 40), max(240, self.height() - 40),
                               Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.foto_tam_ekran.setPixmap(buyuk)
            self.foto_tam_ekran.setGeometry(0, 0, self.width(), self.height())
            self.foto_tam_ekran.show()
            self.foto_tam_ekran.raise_()
            # Tahtayi acma butonlari HER ZAMAN erisilebilir kalir.
            self._raise_exam_controls()
            self.foto_tam_ekran_timer.start(20000)
        except Exception as e:
            logging.warning(f"Fotograf tam ekran acilamadi: {e}")
            self._foto_tam_ekran_kapat()

    def _foto_tam_ekran_kapat(self):
        """Katmani kapatir. Cagrilmasi HER DURUMDA guvenlidir."""
        try:
            if getattr(self, 'foto_tam_ekran_timer', None) is not None:
                self.foto_tam_ekran_timer.stop()
            if getattr(self, 'foto_tam_ekran', None) is not None:
                self.foto_tam_ekran.clear()
                self.foto_tam_ekran.hide()
        except Exception:
            pass

    def _duyuru_resmi_iste(self, duyuru_id: int, url: str):
        """Fotografi ARKA PLANDA indirir. UI asla beklemez; gelince slayt yenilenir."""
        if not url or duyuru_id in self._duyuru_resim_onbellek:
            return
        # None = "indiriliyor" isareti; ayni resim icin ikinci istek acilmasin.
        self._duyuru_resim_onbellek[duyuru_id] = None

        def _indir():
            veri = self.network_client.duyuru_resmi_indir(url) if self.network_client else None
            self._duyuru_resim_geldi.emit(duyuru_id, veri)

        threading.Thread(target=_indir, daemon=True).start()

    def _on_duyuru_resim_geldi(self, duyuru_id: int, veri):
        """UI thread: ham bayttan QPixmap uretir, onbellege koyar, slaydi tazeler."""
        pix = False
        if veri:
            try:
                aday = QPixmap()
                if aday.loadFromData(veri) and not aday.isNull():
                    pix = aday
            except Exception as e:
                logging.warning(f"Duyuru resmi cozulemedi: {e}")
        self._duyuru_resim_onbellek[duyuru_id] = pix

        # Ekranda o duyuru duruyorsa hemen ciz.
        try:
            if self._duyuru_active and self._duyuru_index < len(self._duyuru_active):
                if int(self._duyuru_active[self._duyuru_index].get('id', 0) or 0) == duyuru_id:
                    self._render_duyuru_slide()
        except Exception:
            pass

    def _render_duyuru_slide(self):
        """Geçerli slaytı (başlık/mesaj/gönderen/noktalar) çizer ve paneli konumlandırır."""
        if not self._duyuru_active:
            self._hide_duyuru_panel()
            return
        n = len(self._duyuru_active)
        if self._duyuru_index >= n:
            self._duyuru_index = 0
        item = self._duyuru_active[self._duyuru_index]

        self.duyuru_baslik.setText(str(item.get('baslik', '') or ''))

        # (a) Uzun metin: mesaj alanı SABİT yükseklikte (slaytlar arası zıplama yok) +
        # uzunluğa göre font otomatik küçülür (tahta uzaktan okunur, taşma engellenir).
        mesaj = str(item.get('mesaj', '') or '')
        px = self._duyuru_msg_px(mesaj)
        self.duyuru_mesaj.setStyleSheet(
            f"color:#EAF4FF; font-family:'DejaVu Sans'; font-size:{px}px; background:transparent;")

        # --- Fotograf (varsa) ---
        _did = int(item.get('id', 0) or 0)
        _rurl = str(item.get('resimUrl', '') or '').strip()
        _pix = self._duyuru_resim_onbellek.get(_did) if _rurl else None
        _foto_var = bool(_rurl and isinstance(_pix, QPixmap) and not _pix.isNull())

        # Foto VARSA mesaj rezervini kucult (bos alan gitsin), o alani fotografa ver.
        # Net panel yuksekligi ~AYNI kalir (mesaj 0.36->0.18, foto 0.22->0.40 => toplam 0.58H sabit),
        # yani _position_center_panel'de tasma/kirpilma riski ARTMAZ ama foto ~2x buyur.
        # Tahtaya gonderilen fotograflar cogunlukla RESMI YAZI (A4, dikey, metin dolu).
        # Kirpmak metni goturur, tahtada parmakla buyutmek de yok -> belge TEK SEFERDE
        # ve OLABILDIGINCE BUYUK gorunmeli. Bu yuzden foto varken kart icindeki her sey
        # kisilir: ust satir ("SINIF DUYURUSU") gizlenir, mesaj icerigi kadar yer kaplar.
        self.duyuru_kicker.setVisible(not _foto_var)

        if _foto_var:
            # Foto varken mesaj kutusu ICERIGI KADAR yer kaplasin: "FOTO" gibi tek
            # kelimelik mesajda 0.18H rezerve etmek panelin ortasinda bos bir bosluk
            # birakiyor ve fotografa kalan alani gereksiz yere daraltiyordu.
            _tavan_m = max(90, min(260, int(self.height() * 0.18)))
            _dogal_m = 0
            try:
                _pw_m = self.duyuru_panel.maximumWidth()
                if _pw_m <= 0 or _pw_m >= 16777215:
                    _pw_m = self.duyuru_panel.width() or 760
                _dogal_m = self.duyuru_mesaj.heightForWidth(max(240, _pw_m - 72))
            except Exception:
                _dogal_m = 0
            if _dogal_m and _dogal_m > 0:
                _tavan_m = max(48, min(_tavan_m, _dogal_m + 10))
            self.duyuru_mesaj.setFixedHeight(_tavan_m)
        else:
            self.duyuru_mesaj.setFixedHeight(max(150, min(430, int(self.height() * 0.36))))
        self.duyuru_mesaj.setText(mesaj)

        if _rurl and _did not in self._duyuru_resim_onbellek:
            self._duyuru_resmi_iste(_did, _rurl)

        if _foto_var:
            # --- Fotografa GERCEK bos alan verilir (sabit oran DEGIL) ---
            # Sabit oranli (0.40H) siniri, DIKEY fotograflarda yetersiz kaliyordu:
            # en-boy orani korundugu icin yukseklik sinirlaninca genislik de kuculuyor
            # ve 760px'lik panelde daracik bir serit olusuyordu (iki yani bos).
            #
            # Iki gecisli olcum: once fotograf YOKKEN panel ne kadar yer kapliyor
            # olculur, ekranda kalan bosluk fotografa verilir. Boylece kisa mesajda
            # foto buyur, uzun mesajda kendiliginden kuculur ve panel HICBIR ZAMAN
            # ekrandan tasmaz (tasarsa _position_center_panel negatif y verip kirpardi).
            _pw = self.duyuru_panel.maximumWidth()
            if _pw <= 0 or _pw >= 16777215:
                _pw = self.duyuru_panel.width() or 760
            _gen = max(240, _pw - 48)

            # 1. gecis: resim gizliyken panelin dogal yuksekligi
            self.duyuru_resim.clear()
            self.duyuru_resim.hide()
            try:
                self._fit_panel_height(self.duyuru_panel)
                _h0 = self.duyuru_panel.height()
            except Exception:
                _h0 = int(self.height() * 0.45)

            # 2. gecis: kalan bosluk fotografin olsun (ust/alt icin pay birakilir)
            # Belge okunabilirligi icin ekranin neredeyse tamami kullanilir.
            # (Kart zaten dikeyde ortalaniyor; %97 pay ust/alt kenarda ince bosluk birakir.)
            _kalan = int(self.height() * 0.97) - _h0 - 12
            _maks_h = max(220, min(DUYURU_RESIM_MAX_YUKSEKLIK, _kalan))

            _olcekli = _pix.scaled(_gen, _maks_h,
                                   Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.duyuru_resim.setPixmap(_olcekli)
            self.duyuru_resim.show()
            # Dokununca tam ekran (resmi yazinin kucuk puntosu okunabilsin).
            self.duyuru_resim.setCursor(Qt.PointingHandCursor)
            self.duyuru_resim.mousePressEvent = (
                lambda e, _p=_pix: self._foto_tam_ekran_ac(_p))
        else:
            # Resmi yok, henuz inmedi ya da indirilemedi -> duyuru metin olarak devam eder.
            self.duyuru_resim.clear()
            self.duyuru_resim.hide()

        gonderen = str(item.get('gonderenAd', '') or '').strip()
        self.duyuru_gonderen.setText(f"— {gonderen}" if gonderen else "")
        self.duyuru_gonderen.setVisible(bool(gonderen))

        if n > 1:
            # Nokta sayisi SINIRLI: sunucu gunde 50 duyuruya kadar gonderebiliyor ve
            # 50 nokta tek satira sigmiyordu (panel en fazla 920px). Cok duyuruda
            # noktalar yerine sayac gosterilir.
            if n <= DUYURU_MAX_NOKTA:
                self.duyuru_dots.setText("   ".join("●" if i == self._duyuru_index else "○"
                                                     for i in range(n)))
            else:
                self.duyuru_dots.setText(f"{self._duyuru_index + 1} / {n}")
            self.duyuru_dots.show()
        else:
            self.duyuru_dots.setText("")
            self.duyuru_dots.hide()

        # Aferin (sol) ile yoklama (sağ) panelleri arasına ortala (birthday ile aynı mantık).
        self._position_center_panel(self.duyuru_panel, max_w=920)
        self.duyuru_panel.show()
        self.duyuru_panel.raise_()

    def _position_center_panel(self, panel, max_w=920):
        """Orta panoyu (aferin sol + yoklama sağ arasındaki boşluğa) ortalar; genişliği o
        boşluğa sığdırır, yüksekliği word-wrap'i sayarak hesaplar. Birthday konumlama
        mantığının slider için ortak sürümü."""
        GAP = 24
        left_bound = 0
        if self.aferin_rows_layout.count() > 0:
            left_bound = self.aferin_panel.x() + self.aferin_panel.width() + GAP
        right_bound = self.width()
        if self.yoklama_rows_layout.count() > 0:
            right_bound = self.width() - self.yoklama_panel.width() - 16 - GAP
        avail = max(0, right_bound - left_bound)
        bw = max(380, min(max_w, avail - 32))
        panel.setFixedWidth(bw)
        self._fit_panel_height(panel)
        bh = panel.height()
        bx = left_bound + max(0, (avail - bw) // 2)
        bx = min(bx, max(0, self.width() - bw))
        panel.move(bx, (self.height() - bh) // 2)

    def _render_yoklama_panel(self, yoklamaYok):
        """Bugünkü EN SON yoklamada gelmeyenleri sağ-alt panelde gösterir (UI thread).
        yoklamaYok None -> bugün yoklama alınmamış -> gizle.
        gelmeyenler boş -> yoklama alındı, gelmeyen yok -> 'Tam katılım'."""
        if not yoklamaYok or not isinstance(yoklamaYok, dict):
            # Satirlari da temizle: birthday paneli sag boslugu 'yoklama_rows_layout.count()'
            # ile olcuyor; gizlenirken bosaltilmazsa gizli panel icin yer ayrilip kart sola kayar.
            self._clear_layout(self.yoklama_rows_layout)
            self.yoklama_panel.hide()
            return

        self._clear_layout(self.yoklama_rows_layout)

        sinif = str(yoklamaYok.get('sinif') or SETTINGS.get('board_name', '') or '')
        ders = str(yoklamaYok.get('ders') or '')
        alt = " • ".join([x for x in (sinif, ders) if x]) or "bugünkü yoklama"
        self.yoklama_sub.setText(alt)

        gelmeyenler = yoklamaYok.get('gelmeyenler') or []
        if not gelmeyenler:
            # Yoklama alınmış ama gelmeyen yok -> tam katılım (yeşil satır).
            lbl = QLabel("✅  Tam katılım — gelmeyen yok", self.yoklama_panel)
            lbl.setObjectName("yoklamaTamKatilim")
            self.yoklama_rows_layout.addWidget(lbl)
            lbl.show()
        else:
            # Ekran taşmasın: en fazla 12 satır, gerisi "+N daha".
            MAX_SATIR = 12
            gosterilecek = gelmeyenler[:MAX_SATIR]
            for r in gosterilecek:
                numara = str(r.get('numara', '') or '')
                adi = str(r.get('adi', '') or '')
                durum = str(r.get('durum', 'yok') or 'yok')

                row = QFrame(self.yoklama_panel)
                row.setObjectName("yoklamaRow")
                row.setAttribute(Qt.WA_StyledBackground, True)
                row_lay = QHBoxLayout(row)
                row_lay.setContentsMargins(11, 8, 13, 8)
                row_lay.setSpacing(12)

                no = QLabel(numara or "—", row)
                no.setObjectName("yoklamaNo")
                no.setAlignment(Qt.AlignCenter)
                no.setFixedSize(42, 24)
                row_lay.addWidget(no)

                name_lbl = QLabel(adi, row)
                name_lbl.setObjectName("yoklamaName")
                name_lbl.setWordWrap(True)  # dar panelde uzun ad kesilmesin, alt satira kaysin
                # stretch=1: no ile tag arasindaki bosluk ada kalir, word-wrap orada sarilir.
                row_lay.addWidget(name_lbl, 1)

                # Durum etiketi: geç / nöbetçi. Gerçekten gelmeyende (yok) etiket yok.
                if durum == 'gec':
                    tag = QLabel("GEÇ", row)
                    tag.setObjectName("yoklamaTagGec")
                    tag.setAlignment(Qt.AlignCenter)
                    tag.setFixedSize(38, 20)
                    row_lay.addWidget(tag)
                elif durum == 'nbt':
                    tag = QLabel("NÖBETÇİ", row)
                    tag.setObjectName("yoklamaTagNbt")
                    tag.setAlignment(Qt.AlignCenter)
                    tag.setFixedSize(60, 20)
                    row_lay.addWidget(tag)

                self.yoklama_rows_layout.addWidget(row)
                row.show()

            kalan = len(gelmeyenler) - len(gosterilecek)
            if kalan > 0:
                more = QLabel(f"+{kalan} öğrenci daha", self.yoklama_panel)
                more.setObjectName("yoklamaSubtitle")
                more.setAlignment(Qt.AlignCenter)
                self.yoklama_rows_layout.addWidget(more)
                more.show()

        # Alt başlık: sınıf • ders • sayım. "gelmeyen" = gerçekten YOK (geç/nöbetçi hariç);
        # geç/nöbetçi varsa ayrıca eklenir ki sayı doğru okunsun.
        if gelmeyenler:
            yok_s = sum(1 for r in gelmeyenler if str(r.get('durum', 'yok')) == 'yok')
            gec_s = sum(1 for r in gelmeyenler if str(r.get('durum')) == 'gec')
            nbt_s = sum(1 for r in gelmeyenler if str(r.get('durum')) == 'nbt')
            parts = []
            if yok_s: parts.append(f"{yok_s} gelmeyen")
            if gec_s: parts.append(f"{gec_s} geç")
            if nbt_s: parts.append(f"{nbt_s} nöbetçi")
            self.yoklama_sub.setText(f"{alt}  •  " + ", ".join(parts) if parts else alt)

        # Sağ kolon: dikeyde ortalanır (aferin sol kolonu ile simetrik -> temiz üçlü pano).
        self._fit_panel_height(self.yoklama_panel)
        yh = self.yoklama_panel.height()
        yw = self.yoklama_panel.width()
        self.yoklama_panel.move(self.width() - yw - 16, (self.height() - yh) // 2)
        self.yoklama_panel.show()
        self.yoklama_panel.raise_()

    @staticmethod
    def _fit_panel_height(panel):
        """Paneli icerigine gore boyutlandirir (genislik SABIT varsayilir -> setFixedWidth).

        Qt tuzagi 1: bir layout'a widget eklendikten hemen sonra sizeHint() ONBELLEKTEKI
        (eski) degeri dondurebilir. invalidate()+activate() ile layout'u zorla yeniden
        hesaplatiriz.
        Qt tuzagi 2: word-wrap'li etiketlerde adjustSize() sarilan satirlari saymayip
        paneli KISA cizip dikey kirpiyor. Bu yuzden yuksekligi panelin SABIT genisliginde
        layout.heightForWidth() ile hesaplayip setFixedHeight veriyoruz (hfw cocuk varsa;
        yoksa -1 doner -> eski adjustSize yoluna duseriz).
        """
        lay = panel.layout()
        if lay is not None:
            lay.invalidate()
            lay.activate()
        panel.updateGeometry()
        # Sabit genisligi guvenilir oku: setFixedWidth maximumWidth'i ANINDA ayarlar,
        # width() ise panel henuz gosterilmemisse gecikebilir (yanlis heightForWidth verir).
        w = panel.maximumWidth()
        if w <= 0 or w >= 16777215:  # QWIDGETSIZE_MAX -> sabit genislik yok
            w = panel.width()
        h = lay.heightForWidth(w) if lay is not None else -1
        if h and h > 0:
            panel.setFixedWidth(w)
            panel.setFixedHeight(h)
        else:
            panel.adjustSize()

    def _clear_aferin_rows(self):
        """Panel satirlarini temizler (her yenilemede yeniden kurulur)."""
        while self.aferin_rows_layout.count():
            item = self.aferin_rows_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

    def _render_aferin_panel(self, top5):
        """Bu haftanin ilk-5 aferin listesini sol-alt panelde cizer (UI thread). Bos/None -> gizle.
        Sira SUNUCUDAN gelir (aferin cok->az, esitlikte alfabetik); burada sadece cizim yapilir."""
        if not top5:
            self.aferin_panel.hide()
            return

        self._clear_aferin_rows()

        sinif = SETTINGS.get('board_name', '') or ''
        self.aferin_subtitle.setText(f"{sinif} sınıfı  •  bu hafta" if sinif else "bu hafta")

        for i, r in enumerate(top5[:5]):
            numara = str(r.get('numara', '') or '')
            adi = str(r.get('adi', '') or '')
            aferin = int(r.get('aferin', 0) or 0)
            is_top = (i == 0)

            row = QFrame(self.aferin_panel)
            row.setObjectName("aferinRowTop" if is_top else "aferinRow")
            row.setAttribute(Qt.WA_StyledBackground, True)
            row_lay = QHBoxLayout(row)
            row_lay.setContentsMargins(11, 9, 13, 9)
            row_lay.setSpacing(13)

            # Sira rozeti — ilk uc madalya renginde, 4-5 sade (dar panel icin kucultuldu)
            badge = QLabel(str(i + 1), row)
            badge.setAlignment(Qt.AlignCenter)
            badge.setFixedSize(32, 32)
            if i < len(AFERIN_RANK_COLORS):
                c_top, c_bottom, c_text = AFERIN_RANK_COLORS[i]
                badge.setStyleSheet(
                    f"color:{c_text}; font-family:'DejaVu Sans'; font-size:14px; font-weight:bold;"
                    f"border-radius:16px; background-color: qlineargradient("
                    f"x1:0, y1:0, x2:0, y2:1, stop:0 {c_top}, stop:1 {c_bottom});"
                )
            else:
                badge.setStyleSheet(
                    "color:#C7D4E8; font-family:'DejaVu Sans'; font-size:13px; font-weight:bold;"
                    "border-radius:16px; background-color: rgba(255,255,255,26);"
                )
            row_lay.addWidget(badge)

            # Ad + numara (alt alta)
            name_box = QVBoxLayout()
            name_box.setSpacing(1)
            name_lbl = QLabel(adi, row)
            name_lbl.setObjectName("aferinNameTop" if is_top else "aferinName")
            name_lbl.setWordWrap(True)  # dar panelde uzun ad kesilmesin, alt satira kaysin
            name_box.addWidget(name_lbl)
            if numara:
                no_lbl = QLabel(f"No {numara}", row)
                no_lbl.setObjectName("aferinNo")
                name_box.addWidget(no_lbl)
            # name_box'a stretch=1: badge ile cnt arasindaki TUM bosluk ona kalir; word-wrap'li
            # ad bu genislikte sarilir (ayri addStretch olsaydi Qt ada tam genislik verip keserdi).
            row_lay.addLayout(name_box, 1)

            # Aferin sayisi rozeti (dar panel: biraz kucultuldu)
            cnt = QLabel(f"{aferin} ★", row)
            cnt.setObjectName("aferinCount" if is_top else "aferinCountPlain")
            cnt.setAlignment(Qt.AlignCenter)
            cnt.setFixedSize(50, 24)
            row_lay.addWidget(cnt)

            self.aferin_rows_layout.addWidget(row)
            # KRITIK: parent (panel) ZATEN GORUNURSE Qt yeni cocugu otomatik GOSTERMEZ.
            # show() cagrilmazsa satir gizli kalir, layout'ta yer kaplamaz ve panel
            # "baslik var govde yok" halinde kucuk cizilir (V6.00.08-10'daki bos liste bug'i).
            row.show()

        # Icerige gore yukseklik, sol-altta surum etiketinin uzerine yerlestir.
        # Layout ZORLA guncellenir: satirlar yeni eklendigi icin sizeHint() aksi halde
        # eski (satirsiz) yuksekligi dondurup paneli kirpabiliyor.
        # Sol kolon: dikeyde ortalanir (yoklama sag kolonu ve ortadaki birthday ile ayni
        # dikey eksende hizalansin -> temiz uclu pano). Onceden sol-alta yapisikti.
        self._fit_panel_height(self.aferin_panel)
        ph = self.aferin_panel.height()
        self.aferin_panel.move(16, (self.height() - ph) // 2)
        self.aferin_panel.show()
        self.aferin_panel.raise_()

    def perform_maintenance(self):
        """
        Perform periodic maintenance tasks, including fetching the schedule.
        """
        def _maintenance_task():
            try:
                logging.info("Performing periodic maintenance tasks")
                
                # Get board values/schedule
                all_boards_data = self.network_client.get_values()
                if all_boards_data:
                    logging.info(f"Retrieved {len(all_boards_data)} board configurations")
                    # Find this board's schedule
                    my_board_id_str = SETTINGS.get('board_id', '0')
                    for board_data in all_boards_data:
                        if str(board_data.get('id')) == my_board_id_str:
                            self.schedule = board_data
                            logging.info(f"Successfully loaded schedule for board {my_board_id_str}")
                            break
                    else:
                        logging.warning(f"Could not find schedule for board ID {my_board_id_str} in server response.")

                # Check for version updates
                new_version = self.network_client.check_version()
                if new_version and new_version != SETTINGS.get('version'):
                    logging.info(f"Version update available: {SETTINGS.get('version')} -> {new_version}")
                    if hasattr(self, 'version_update_label'):
                        QTimer.singleShot(0, lambda: self.version_update_label.setText(f"⬆ Güncelleme mevcut: v{new_version}"))
                        QTimer.singleShot(0, lambda: self.version_update_label.setVisible(True))

                # --- Bileşen 13: Autostart dosyası kontrolü ---
                self._repair_autostart()
                    
            except Exception as e:
                logging.error(f"Error in maintenance tasks: {e}")

        threading.Thread(target=_maintenance_task, daemon=True).start()

    def _repair_autostart(self):
        """Autostart dosyasını kontrol et, silinmişse/bozulmuşsa geri oluştur (Bileşen 13)."""
        try:
            if not os.path.exists(AUTOSTART_FILE):
                logging.warning(f"Autostart file missing: {AUTOSTART_FILE}")
                os.makedirs(AUTOSTART_DIR, exist_ok=True)
                with open(AUTOSTART_FILE, 'w') as f:
                    f.write(AUTOSTART_CONTENT)
                logging.info(f"Autostart file restored: {AUTOSTART_FILE}")
            else:
                # İçerik doğru mu kontrol et
                with open(AUTOSTART_FILE, 'r') as f:
                    content = f.read()
                if '/opt/fatih-client/main.py' not in content:
                    logging.warning("Autostart file content is incorrect, restoring...")
                    with open(AUTOSTART_FILE, 'w') as f:
                        f.write(AUTOSTART_CONTENT)
                    logging.info("Autostart file content restored")
        except PermissionError:
            logging.error("Permission denied when repairing autostart file")
        except Exception as e:
            logging.error(f"Error repairing autostart: {e}")

    def _format_time(self, time_str):
        """Saat formatını HH:MM formatına çevir (C# Tools.ClockFrmt karşılığı)"""
        if not time_str or time_str == "0":
            return ""
        time_str = time_str.strip()
        parts = time_str.split(':')
        if len(parts) == 2:
            try:
                h = int(parts[0])
                m = int(parts[1])
                return f"{h:02d}:{m:02d}"
            except ValueError:
                return ""
        return time_str if len(time_str) == 5 else ""

    def check_schedule(self):
        """Ders çıkış saatinde otomatik kilitleme.
        
        NOT: Ders saati başladığında otomatik açılma YAPILMAZ.
        Tahta sadece MebreCep, admin şifresi veya yönetim panelinden açılır.
        Bu fonksiyon sadece ders bittiğinde (çıkış saati) otomatik kilitler.
        """
        if not self.schedule or 'hours' not in self.schedule:
            logging.debug("Schedule not available, skipping check.")
            return

        # KRIZ PENCERESI: kriz kodu girilmisse tahta 24 saat kilitlenmez. Aksi halde kriz
        # aninda her ders bitiminde tekrar kilitlenip kodu yeniden isterdi.
        _kriz_kalan = kriz_penceresi_kalan()
        if _kriz_kalan > 0:
            logging.debug(f"Kriz penceresi acik ({_kriz_kalan // 60} dk kaldi) — otomatik kilit atlandi.")
            return

        now = simdi()   # AG SAATI (sistem saati kaymis olabilir)
        # isoweekday(): Monday is 1 and Sunday is 7. This matches the C# loop (s=1 to 7)
        day_of_week = now.isoweekday()
        current_time_str = now.strftime("%H:%M")

        # Gün değiştiğinde exit_time_locked dizisini sıfırla (C# kSaat[] gibi)
        if day_of_week != self.last_schedule_day:
            self.exit_time_locked = [0] * 20
            self.last_schedule_day = day_of_week
            logging.info(f"New day detected ({day_of_week}), reset exit_time_locked counters")

        exit_time_triggered = False
        exit_time_log = ""
        try:
            hours_data = self.schedule['hours']

            # Handle both list and dict structures
            if isinstance(hours_data, list):
                # Server returns hours as a 3D list: [day][period][property]
                # day: 0-7 (we use day_of_week which is 1-7 for Mon-Sun)
                # period: 0-18 (we check 1-18)
                # property: 0-2 where 1=start_time, 2=end_time

                if day_of_week < len(hours_data):
                    day_schedule = hours_data[day_of_week]

                    # Check each period (1-18)
                    for period_idx in range(1, min(19, len(day_schedule))):
                        period_data = day_schedule[period_idx]

                        if isinstance(period_data, list) and len(period_data) >= 3:
                            start_time = period_data[1] if period_data[1] else ""
                            end_time = period_data[2] if len(period_data) > 2 and period_data[2] else ""

                            if start_time and end_time and start_time != "0" and end_time != "0":

                                # --- C# timer1Thread mantığı: Çıkış saati kontrolü ---
                                # Çıkış saati geldiğinde kilitle (tenefüs/ders bitimi)
                                formatted_exit = self._format_time(end_time)
                                if formatted_exit and len(formatted_exit) == 5 and not self.is_locked:
                                    if self.exit_time_locked[period_idx] == 0:
                                        if current_time_str == formatted_exit:
                                            # Tam çıkış saatinde kilitle
                                            self.exit_time_locked[period_idx] = 1
                                            exit_time_triggered = True
                                            exit_time_log = f"Tenefüs olduğu için kilitlendi (Ders {period_idx}, çıkış: {formatted_exit})"
                                            logging.info(exit_time_log)
                                        else:
                                            # 2-5 dakika tolerans (C# kodundaki gibi)
                                            try:
                                                from datetime import timedelta
                                                current_dt = datetime.strptime(current_time_str, "%H:%M")
                                                exit_dt = datetime.strptime(formatted_exit, "%H:%M")
                                                diff_minutes = (current_dt - exit_dt).total_seconds() / 60
                                                if 2 < diff_minutes < 5:
                                                    self.exit_time_locked[period_idx] = 1
                                                    exit_time_triggered = True
                                                    exit_time_log = f"Tenefüs olduğu için kilitlendi (Ders {period_idx}, çıkış: {formatted_exit}, +{diff_minutes:.0f}dk)"
                                                    logging.info(exit_time_log)
                                            except Exception as te:
                                                logging.debug(f"Time comparison error: {te}")

            elif isinstance(hours_data, dict):
                # Handle dictionary format (if server changes to this format)
                day_schedule = hours_data.get(str(day_of_week), {})

                # The hour slots are also 1-indexed strings "1" through "18"
                for k in range(1, 19):
                    slot = day_schedule.get(str(k))
                    # Slot is expected to be a list like ["", "08:30", "09:10"] or dict
                    if slot:
                        start_time = ""
                        end_time = ""
                        if isinstance(slot, list) and len(slot) >= 3:
                            start_time = slot[1] if slot[1] else ""
                            end_time = slot[2] if slot[2] else ""
                        elif isinstance(slot, dict):
                            start_time = slot.get('1', '')
                            end_time = slot.get('2', '')

                        if start_time and end_time and start_time != "0" and end_time != "0":

                            # Çıkış saati kontrolü
                            formatted_exit = self._format_time(end_time)
                            if formatted_exit and len(formatted_exit) == 5 and not self.is_locked:
                                if self.exit_time_locked[k] == 0:
                                    if current_time_str == formatted_exit:
                                        self.exit_time_locked[k] = 1
                                        exit_time_triggered = True
                                        exit_time_log = f"Tenefüs olduğu için kilitlendi (Ders {k}, çıkış: {formatted_exit})"
                                        logging.info(exit_time_log)
                                    else:
                                        try:
                                            from datetime import timedelta
                                            current_dt = datetime.strptime(current_time_str, "%H:%M")
                                            exit_dt = datetime.strptime(formatted_exit, "%H:%M")
                                            diff_minutes = (current_dt - exit_dt).total_seconds() / 60
                                            if 2 < diff_minutes < 5:
                                                self.exit_time_locked[k] = 1
                                                exit_time_triggered = True
                                                exit_time_log = f"Tenefüs olduğu için kilitlendi (Ders {k}, çıkış: {formatted_exit}, +{diff_minutes:.0f}dk)"
                                                logging.info(exit_time_log)
                                        except Exception as te:
                                            logging.debug(f"Time comparison error: {te}")
            else:
                logging.warning(f"Unexpected hours data type: {type(hours_data)}")

        except (IndexError, KeyError, TypeError) as e:
            logging.warning(f"Could not parse schedule for today (day {day_of_week}): {e}")
            # Schedule parse hatası olduğunda kilitleme YAPMA
            # (internetsiz durumda schedule yoksa açık kalmalı)
            return

        # --- Çıkış saati bazlı kilitleme (öncelikli) ---
        # C# timer1Thread: çıkış saati geldiğinde USB yoksa kilitle
        if exit_time_triggered and not self.is_locked:
            # Overlay açıkken (kullanıcı Yapılandırma/Şifre Değiştir ekranında)
            # lock_system() çağırmak X11'de focus çakışması ve donma yaratır.
            # Kilitlemeyi bir sonraki timer tick'e (20sn) ertele.
            for child in self.children():
                if type(child).__name__ == 'LockScreenOverlay' and child.isVisible():
                    logging.info("Çıkış saati kilitleme ertelendi: overlay aktif")
                    return
            if check_usb_password():
                logging.info("Exit time says lock, but USB is present. Skipping lock.")
            else:
                self.manual_override = False
                self.lock_system(exit_time_log)
                self.save_log(exit_time_log, "schedule")
                return  # Çıkış saati kilitledi, aşağıdaki mantığa geçme

        # NOT: Ders saati başladığında otomatik açılma YAPILMAZ.
        # Tahta sadece MebreCep, admin şifresi veya yönetim panelinden açılır.
        
    def check_usb_status(self):
        """
        NEW: Periodic USB status check (equivalent to C# CheckInternetWork function)
        Only locks system if it was originally unlocked by USB
        """
        try:
            # Kilit aktifken USB otomatik mount edilmeyebilir, biz yapalım
            ensure_usb_mounted()
            
            # Check if USB with password is present
            usb_present = check_usb_password()
            
            if usb_present:
                # USB is present - unlock if locked, but only call unlock ONCE
                if self.is_locked:
                    logging.info("USB password detected - unlocking system")
                    self.unlock_system("USB ile açıldı")
                # Keep manual_override active while USB is present to prevent schedule from re-locking
                elif self.usb_monitor.unlocked_by_usb:
                    # USB still present, make sure manual_override stays active
                    self.manual_override = True
            else:
                # USB with password not present
                if not self.is_locked and self.usb_monitor.unlocked_by_usb:
                    # Only lock if system was unlocked by USB
                    logging.info("USB password not found and system was unlocked by USB - locking system")
                    self.lock_system("USB çıkarıldığı için kilitlendi")
                    # Reset the USB unlock flag since we're locking
                    self.usb_monitor.unlocked_by_usb = False
                    
            # Check for remove command
            if check_usb_remove():
                self.remove_system()
                
        except Exception as e:
            logging.error(f"Error in USB status check: {e}")
        
    # NOT: Eski v4-tarzi _get_headers (User-Key/UserCore/cFnc) KALDIRILDI — kullanilmiyordu.
    # v6 runtime'inin tum sunucu iletisimi NetworkClient uzerinden v5'e (Bearer + X-Timestamp) gider.

    def poll_server(self):
        def _poll_task():
            commands = self.network_client.ctrl_post()
            if commands is not None:
                logging.info("Successfully polled server.")
                self.network_status_signal.emit(True)
                
                # --- C# startWork mekanizmasi ---
                if not self.start_work:
                    self.early_wait_ticks += 1
                    if self.early_wait_ticks >= 4:
                        self.early_wait_ticks = 0
                        self.start_work = True
                        logging.info("start_work=True: Sunucu komutlari artik islenecek (C# ewt mekanizmasi)")
                    else:
                        logging.info(f"start_work=False: Sunucu komutu yoksayildi (ewt={self.early_wait_ticks}/4)")
                        return
                
                # ctrl_post artik liste donuyor (v5 JSON'dan); split gerekmiyor.
                # Safely emit to main thread instead of lambda QTimer which gets garbage collected
                self.command_signal.emit(commands)
            else:
                # İNTERNET VEYA SUNUCU KOPTU
                self.server_has_spoken = False
                
                # Gerçekten internet mi yok, yoksa sadece API mi yanıt vermiyor ayırımı
                has_connection = self.network_client.check_network()
                self.network_status_signal.emit(has_connection)
                
                if not has_connection:
                    # İnternet koptuğunda kilitli değilsek kilitliyoruz (USB ile açılmadıysa).
                    # KRIZ PENCERESI ISTISNA: kriz kodu tam da "sunucu/internet yok" diye
                    # giriliyor. Burada kriz kontrolu olmayinca ilk basarisiz poll tahtayi
                    # tekrar kilitliyor ve 24 saatlik pencere hicbir ise yaramiyordu.
                    _kriz = kriz_penceresi_kalan()
                    if _kriz > 0:
                        logging.warning(
                            f"Internet yok ama kriz penceresi acik ({_kriz // 60} dk) — kilitlenmiyor.")
                    elif not self.is_locked and not check_usb_password():
                        logging.warning("İnternet bağlantısı kesildi, sistem kilitleniyor.")
                        QTimer.singleShot(0, lambda: self.lock_system("İnternet bağlantısı kesildiği için kilitlendi"))
                        
                    logging.error("Failed to poll server - No Internet connection detected.")
                else:
                    logging.error("Failed to poll server - Internet exists, but API server failed to respond.")

        threading.Thread(target=_poll_task, daemon=True).start()

    def process_commands(self, commands):
        if len(commands) < 4:
            logging.warning(f"Sunucudan eksik/hatalı komut formatı geldi (len < 4): {commands}")
            return
        try:
            self.tahta_lock = int(commands[0])
            message = commands[1] if commands[1] != '0' else ""
            self.shutDown = int(commands[2])
            self.system_remove = int(commands[3])
            
            if len(commands) > 4:
                self.log_send = int(commands[4])
            else:
                self.log_send = 0
            
            # --- DEBUG: Tum durum degiskenlerini logla ---
            lock_age = time.time() - self.last_lock_time if hasattr(self, 'last_lock_time') and self.last_lock_time > 0 else -1
            logging.info(f"[CMD] tahta_lock={self.tahta_lock}, is_locked={self.is_locked}, lock_age={lock_age:.1f}s")
            
            # --- Mesaj gelirse ve sistem açıksa otomatik kilitle (C# davranışı) ---
            # Sadece mesaj değiştiğinde kilitle ki sonsuz döngüye girmesin!
            if not hasattr(self, 'last_server_message'):
                self.last_server_message = ""
                
            if message != "" and not self.is_locked:
                if message != self.last_server_message:
                    logging.info(f"YENİ Mesaj geldi, sistem kilitleniyor: {message}")
                    self.manual_override = False
                    self.lock_system(f"Mesaj alındı: {message}")
                
            self.last_server_message = message

            if hasattr(self, 'message_label'):
                if message != "":
                    self.message_label.setText(message)
                else:
                    self.message_label.setText("")

            # --- Sadece sunucudaki sinyal DEĞİŞTİĞİNDE aksiyon al ---
            if not hasattr(self, 'last_server_tahta_lock'):
                self.last_server_tahta_lock = -6
                
            overlay_active = False
            for child in self.children():
                if type(child).__name__ == 'LockScreenOverlay' and child.isVisible():
                    overlay_active = True
                    break

            is_new_command = False
            if self.tahta_lock != self.last_server_tahta_lock and self.tahta_lock in (0, 1):
                if overlay_active:
                    logging.info("Sunucudan komut geldi ancak overlay (Şifre/Ayar ekranı) açık, erteleniyor.")
                else:
                    is_new_command = True
                    self.last_server_tahta_lock = self.tahta_lock

            # C# BİREBİR DAVRANIŞI: Server yeni komut gönderirse onu uygula
            if is_new_command:
                if self.tahta_lock == 1 and not self.is_locked and message == "":
                    # USB takılıysa sunucu komutunu (lock=1) yoksay (C# IsFlash mantığı)
                    if check_usb_password():
                        logging.info("Server says lock, but USB is present. Skipping lock.")
                    else:
                        # Sunucudan ACIK kilit komutu geldiyse bu bilincli bir mudahaledir:
                        # kriz penceresini de kapatir (kullanicinin "mudahaleler onceliklidir" kurali).
                        kriz_penceresi_kapat("sunucudan kilit komutu")
                        self.manual_override = False
                        self.lock_system("Sunucudan gelen komut ile kilitlendi")

                elif self.tahta_lock == 0 and self.is_locked and message == "":
                    logging.info("Sunucudan 'AÇ (0)' komutu geldi. Sistem açılıyor.")
                    if hasattr(self, 'login_panel') and self.login_panel.isVisible():
                        self.login_panel.hide()
                    self.unlock_system("Sunucudan (Mobilden) İstek Geldi")
            
            self.server_has_spoken = True

            # Update Message Label
            if hasattr(self, 'message_label'):
                if message != "":
                    self.message_label.setText(message)
                else:
                    self.message_label.setText("")
            if self.shutDown == 1:
                logging.info("Shutdown command received from server (mobile app)")
                # KRİTİK: ACK'i SENKRON yap — daemon thread kapatılmadan önce
                # sunucunun shutdown=0 öğrenmesini garanti et.
                # Aksi halde sunucu hâlâ shutdown=1 tutar → sonsuz reboot döngüsü!
                try:
                    ack_ok = self.network_client.set_value("shutdown", "0")
                    if ack_ok:
                        logging.info("Shutdown ACK başarıyla gönderildi (senkron)")
                    else:
                        logging.warning("Shutdown ACK başarısız — yine de kapatılıyor")
                except Exception as ack_err:
                    logging.error(f"Shutdown ACK hatası: {ack_err}")
                self.save_log("Sunucudan kapatma komutu alındı", "system")
                # Birden fazla kapatma yöntemi dene
                import subprocess
                shutdown_commands = [
                    ['dbus-send', '--system', '--print-reply', '--dest=org.freedesktop.login1', '/org/freedesktop/login1', 'org.freedesktop.login1.Manager.PowerOff', 'boolean:true'],
                    ['systemctl', 'poweroff'],
                    ['poweroff'],
                    ['sudo', 'poweroff'],
                    ['sudo', 'systemctl', 'poweroff'],
                    ['sudo', '/sbin/poweroff'],
                    ['sudo', 'shutdown', '-h', 'now'],
                ]
                for cmd in shutdown_commands:
                    try:
                        logging.info(f"Trying server shutdown command: {' '.join(cmd)}")
                        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                        if result.returncode == 0:
                            logging.info(f"Shutdown initiated with: {' '.join(cmd)}")
                            QApplication.quit()
                            return
                    except subprocess.TimeoutExpired:
                        # Sistem kapanıyor olabilir
                        QApplication.quit()
                        return
                    except Exception as e:
                        logging.warning(f"Server shutdown command {cmd} failed: {e}")
                        continue
                # Son çare
                os.system("sudo poweroff || poweroff")
                QApplication.quit()
            
            if self.system_remove == 1:
                self.remove_system()

            # --- Log isteme (C# LogSend karşılığı) ---
            if self.log_send == 1:
                logging.info("Server requesting logs...")
                try:
                    log_path = os.path.expanduser("~/fatih_client.log")
                    if os.path.exists(log_path):
                        with open(log_path, 'r', errors='ignore') as f:
                            lines = f.readlines()
                        last_lines = ''.join(lines[-50:])  # Son 50 satır
                        self.network_client.save_log(last_lines, "logfile")
                        self.acknowledge_command("logSend", "0")
                except Exception as le:
                    logging.error(f"Error sending logs: {le}")

            pass

        except (ValueError, IndexError) as e:
            logging.error(f"Error processing server commands '{commands}': {e}")

    def lock_system(self, reason=""):
        if NO_LOCK_MODE:
            logging.info(f"[NO-LOCK] lock_system() skipped: {reason}")
            return
        if not self.is_locked: # Prevent redundant locks
            logging.info(f"Locking system: {reason}")
            self.is_locked = True
            self.last_lock_time = time.time()  # Soğuma + duyuru 3 dk doğum günü kapısı bu andan başlar
            # Record the lock event
            self.save_log(reason, "lock")
            self.acknowledge_command("tahtaLock", "1", reason)
            self.tahta_lock = -6  # C# NullVal(-6) davranışı - sunucudan yeni geçerli değer gelene kadar bekle

            # --- Güvenlik katmanları (C# LockSystm karşılığı) ---
            PanelManager.hide()          # Taskbar gizle (C# TastbarWindows)
            VolumeControl.mute()         # Ses kapat (C# VD)
            ShortcutManager.disable()    # Kısayolları devre dışı bırak
            kill_all_browsers()          # Tarayıcıları kapat (C# KillAllItem)

            # Ensure UI elements are visible
            self.login_button.setVisible(True)
            self.message_label.setVisible(True)

            # Show, raise, and activate the window.
            self.show()
            self.raise_()
            self.activateWindow()
            self.login_button.setFocus()

            QApplication.processEvents()

            # Bilgi panellerini once SON VERIYLE ciz -> ekran aninda dolu gelsin.
            # (Bu cagri show()+processEvents() SONRASINDA olmali; pencere gorunmeden
            #  cizilirse layout dogru oturmaz.)
            self._restore_info_panels()

            # Ardindan TAZE veri iste: ders icinde verilen aferin / girilen dogum gunu
            # tahta kilitlenir kilitlenmez gorunsun. Arka planda calisir, ~1 sn sonra
            # panelleri tazeler; ekran bu sirada bos kalmaz (yukarida zaten cizildi).
            self.refresh_display()

            # Cinnamon panel'i altımıza göm: xdotool ile kilit ekranını en üste al
            QTimer.singleShot(500, self._force_on_top)
            QTimer.singleShot(1500, self._force_on_top)  # 1.5 saniye sonra tekrar

            try:
                if not getattr(self, 'keyboard_locker', None) or not self.keyboard_locker.is_alive():
                    self.keyboard_locker = KeyboardLocker()
                    self.keyboard_locker.start()
                    logging.info("KeyboardLocker thread started successfully")
            except Exception as e:
                logging.error(f"Failed to start KeyboardLocker: {e}")
                self.keyboard_locker = None


    def _force_on_top(self):
        """Cinnamon'da kilit ekranını taskbar'ın üstüne zorla al"""
        # Overlay (Yapılandırma/Şifre Değiştir ekranı) açıkken
        # raise_/activateWindow/xdotool çağırmak X11 focus kaybına ve
        # QListWidget scroll donmasına yol açar — bu durumda atla!
        for child in self.children():
            if type(child).__name__ == 'LockScreenOverlay' and child.isVisible():
                logging.debug("_force_on_top atlandı: overlay aktif")
                return
        try:
            self.raise_()
            self.activateWindow()
            # xdotool ile kendi penceremizin ID'sini bul ve en üste al
            try:
                result = _subprocess.run(
                    ['xdotool', 'getactivewindow'],
                    capture_output=True, text=True, timeout=2
                )
                wid = result.stdout.strip()
                if wid:
                    _subprocess.run(['xdotool', 'windowraise', wid],
                                   capture_output=True, timeout=2)
            except Exception:
                pass
            # wmctrl ile 'above' bayrağını zorla ekle
            try:
                _subprocess.run(
                    ['wmctrl', '-r', ':ACTIVE:', '-b', 'add,above,fullscreen'],
                    capture_output=True, timeout=2
                )
            except Exception:
                pass
        except Exception as e:
            logging.debug(f"_force_on_top error: {e}")

    def unlock_system(self, reason=""):
        # Safety: always hide child login_panel before hiding the parent window
        # to prevent X11/Cinnamon WM from crashing on orphaned child widget repaints.
        if hasattr(self, 'login_panel') and self.login_panel.isVisible():
            self.login_panel.hide()
        logging.info(f"Unlocking system: {reason}")
        # NOT: Sınav modu kilidi ZORLA tutmaz (müdahale önceliği) — açılınca sınav ekranı da
        # pencereyle gizlenir; tahta tekrar kilitlenirse (sınav hâlâ aktifse) ekran geri gelir.

        # Set manual override if this is not a scheduled or server-commanded unlock
        # Veya sunucudan gelmiş olsa bile, kullanıcının MebreCep/Yönetim ekranından 
        # açması durumu da manual override sayılmalıdır
        if "Zamanlanmış" not in reason:
            self.manual_override = True
            logging.info("Manual override activated (or server unlock received). Timer started.")

        # Tam ekran fotograf acik kaldiysa kapat: kilit ekrani gidiyor.
        self._foto_tam_ekran_kapat()

        self.is_locked = False
        self.hide()
        if self.keyboard_locker:
            self.keyboard_locker.stop()
            self.keyboard_locker = None
            
        # --- Güvenlik katmanlarını geri aç (C# LockFree karşılığı) ---
        PanelManager.show()          # Taskbar göster
        VolumeControl.unmute()       # Ses aç (C# VU)
        ShortcutManager.restore()    # Kısayolları geri yükle

        # Reset USB unlock flag if unlocked by other means (not USB)
        if not reason.startswith("USB ile"):
            if hasattr(self, 'usb_monitor') and self.usb_monitor:
                self.usb_monitor.reset_usb_unlock_flag()
            
        # Acilis sebebi sunucuya bildirilir (illegal acilis uyarisinin kaynagi budur).
        self.acknowledge_command("tahtaLock", "0", reason)
        self.tahta_lock = -6  # C# NullVal(-6) davranışı - sunucudan yeni geçerli değer gelene kadar bekle
        
        # Fatih kilidi açıldıktan sonra Pardus/GNOME ekran kilidini aktif et
        # İPTAL: MebreCep veya USB ile açıldığında işletim sistemi şifresi sormasın
        # self.activate_system_lock_screen()

    def activate_system_lock_screen(self):
        """
        Fatih kilit ekranı açıldıktan sonra Pardus/GNOME sistem kilidini aktif eder.
        Kullanıcı kendi şifresiyle giriş yaparak sisteme erişir.
        """
        import subprocess
        
        logging.info("Activating Pardus/GNOME lock screen...")
        
        # Birkaç farklı yöntem deneyeceğiz (Pardus/Debian için)
        lock_commands = [
            # GNOME Screensaver (en yaygın)
            ['gnome-screensaver-command', '--lock'],
            # loginctl (systemd-based)
            ['loginctl', 'lock-session'],
            # xdg-screensaver (generic)
            ['xdg-screensaver', 'lock'],
            # dbus-send (GNOME Shell)
            ['dbus-send', '--type=method_call', '--dest=org.gnome.ScreenSaver',
             '/org/gnome/ScreenSaver', 'org.gnome.ScreenSaver.Lock'],
        ]
        
        for cmd in lock_commands:
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    logging.info(f"System lock screen activated using: {cmd[0]}")
                    return True
                else:
                    logging.debug(f"Command {cmd[0]} failed: {result.stderr}")
            except FileNotFoundError:
                logging.debug(f"Command not found: {cmd[0]}")
            except subprocess.TimeoutExpired:
                logging.warning(f"Command timed out: {cmd[0]}")
            except Exception as e:
                logging.debug(f"Error running {cmd[0]}: {e}")
        
        logging.warning("Could not activate system lock screen - no supported method found")
        return False

    def acknowledge_command(self, cmd_key, cmd_val, sebep=None):
        # Notify the server that we have processed a command.
        def send_ack():
            self.network_client.set_value(cmd_key, cmd_val)
            if cmd_key == "tahtaLock":
                # Cihazın kilitli olup olmadığını MebreCep'e bildiren asıl kolon 'open_close'dir.
                # C# kodunda (systmlock = true ise "1", false ise "0") gönderiliyordu.
                # python tarafında cmd_val "1" (kilitli) ve "0" (açık) olarak geliyor.
                # MebreCep'teki yeşil/kırmızı ışığın doğru tespiti için bu satır gereklidir:
                # Acilis/kilit SEBEBI de gonderilir -> sunucu denetim kaydina yazar.
                self.network_client.set_value("open_close", cmd_val, sebep)

        threading.Thread(target=send_ack, daemon=True).start()

    def _kaldirma_kaniti(self) -> str:
        """Uzaktan kaldirma yetki kaniti: sha256(device_token + REMOVE_SALT).

        uninstall.sh ile BIREBIR ayni formul; ikisi birlikte degismeli.
        Tuz betikte duruyor ve betik root:700 oldugu icin etapadmin okuyamaz.
        Token cihaza ozeldir -> bir tahtadan sizan kanit baska tahtayi kaldiramaz.
        """
        try:
            token = get_setting('device_token', '') or ''
            if not token:
                return ''
            return hashlib.sha256((token + "mebre-remove-v1").encode('utf-8')).hexdigest()
        except Exception as e:
            logging.error(f"Kaldirma kaniti uretilemedi: {e}")
            return ''

    def remove_system(self):
        """Uzaktan kaldirma (ynt5 -> system_Remove=1).

        Temizligi KENDIMIZ yapmiyoruz: kurulumla gelen resmi kaldirma betigini
        (/usr/local/bin/fatih-uninstall) --force ile calistiriyoruz. Boylece uzaktan
        kaldirma ile teknisyenin elle kaldirmasi BIREBIR ayni islemi yapar; iki ayri
        temizlik listesi tutulmaz. (Eskiden burada sadece 3 dosya siliniyordu; autostart
        kopyalari, rfkill, ses, gsettings ve sudoers artiklari geride kaliyordu ->
        tahta "program kalkti ama internetim/sesim yok, hala kilitleniyor" durumunda kaliyordu.)
        """
        logging.info("SYSTEM REMOVE command received. Uninstalling...")

        # KRİTİK: ACK'i SENKRON yap — dosyalar silinmeden önce sunucu bilgilendirilmeli
        try:
            self.network_client.set_value("system_Remove", "0")
        except Exception as ack_err:
            logging.error(f"Remove ACK hatası: {ack_err}")

        # Istemci etapadmin olarak calisir, kaldirma ise ROOT isi -> sudo sart.
        # setup.sh yalnizca bu betik icin NOPASSWD kurali tanimlar (/etc/sudoers.d/fatih-client).
        # `-n`: sifre sorma, soracaksa hemen basarisiz ol (kilit ekraninda prompt bekleyemeyiz).
        uninstaller = "/usr/local/bin/fatih-uninstall"
        try:
            # Betik client.py'yi de oldurecegi icin AYRI OTURUMDA baslatiyoruz;
            # biz olsek de temizlik sonuna kadar devam etsin.
            # YETKI ARTIK ARGUMANLA DEGIL, STDIN'DEN GIDIYOR (3 Agustos 2026).
            # Eskiden `--force` yolluyorduk ve sudoers argumani kisitlamadigi icin
            # tahtada terminale erisen HERKES ayni komutu yazip kilit sistemini
            # kaldirabiliyordu. Artik sudoers yalnizca argumansiz cagriya izin veriyor;
            # kaldirma betigi yetkiyi stdin'deki kanittan dogruluyor.
            _kanit = self._kaldirma_kaniti()
            _p = _subprocess.Popen(
                ["sudo", "-n", uninstaller],
                stdin=_subprocess.PIPE,
                start_new_session=True,
                stdout=_subprocess.DEVNULL,
                stderr=_subprocess.DEVNULL,
            )
            try:
                _p.stdin.write((_kanit + "\n").encode("utf-8"))
                _p.stdin.flush()
                _p.stdin.close()
            except Exception:
                pass
            _kanit = None
            logging.info("sudo fatih-uninstall (kanit stdin) started (detached). Exiting.")
            QApplication.quit()
            return
        except Exception as e:
            logging.error(f"Uninstaller calistirilamadi: {e} — satir ici temizlige dusuluyor")

        # --- Yedek plan: betik cagrilamadiysa ayni adimlari burada dene ---
        # Bunlar da root isi -> hepsi `sudo -n` ile. (Betikle ayni liste; birlikte guncellenmeli.)
        for cmd in (
            "rm -f /etc/xdg/autostart/fatih-client-autostart.desktop",
            "rm -f /home/etapadmin/.config/autostart/fatih-client.desktop",
            "rm -f /home/fatih-kiosk/.config/autostart/fatih-kiosk.desktop",
            "rfkill unblock all",
            "rm -f /etc/sudoers.d/fatih-kiosk",
            "rm -rf /opt/fatih-client",
            "rm -f /etc/fatih-client/config.ini",
        ):
            try:
                os.system(f"sudo -n {cmd} 2>/dev/null")
            except Exception:
                pass
        # Bunlar kullanici oturumuna ait, sudo'suz calisir.
        for cmd in (
            "pactl set-sink-mute @DEFAULT_SINK@ 0",
            "gsettings set org.gnome.desktop.lockdown disable-command-line false",
        ):
            try:
                os.system(cmd + " 2>/dev/null")
            except Exception:
                pass

        # DURUST RAPOR: eskiden temizlik basarisiz olsa bile "complete" yaziliyordu
        # (Errno 13'te tam bu oldu) -> gercekten gitti mi kontrol et.
        if os.path.exists("/opt/fatih-client"):
            logging.error("KALDIRMA BASARISIZ: /opt/fatih-client hala duruyor (yetki sorunu?). "
                          "Tahta elle kaldirilmali: sudo /usr/local/bin/fatih-uninstall")
        else:
            logging.info("Uninstallation complete (fallback). Exiting.")
        QApplication.quit()

    # --- NEW: Log saving method that uses the network client ---
    def save_log(self, log_name, vog_name):
        # Run in a separate thread to avoid blocking the UI
        threading.Thread(
            target=self.network_client.save_log,
            args=(log_name, vog_name),
            daemon=True
        ).start()

    def update_time_display(self):
        """Update the time display in bottom-right corner (AG SAATI ile senkron)"""
        current_time = simdi()
        time_str = current_time.strftime("%d/%m/%Y %H:%M:%S")
        self.time_label.setText(time_str)
        # Sınav ekranı açıksa oradaki büyük saat de aynı kaynaktan tazelenir.
        if getattr(self, '_exam_on', False):
            self._update_exam_clock()

    def update_board_id_display(self):
        """Update the board name display in top-center - Sadece TAHTA ADI görünür"""
        board_name = SETTINGS.get('board_name', 'Akıllı Tahta')
        self.board_id_label.setText(board_name)

    def update_network_status_ui(self, has_internet):
        """C# Uyumluluğu: İnternet koptuğunda versiyon/isim etiketini İNTERNET YOK!!! yapar"""
        current_text = self.version_label.text()
        
        if not has_internet:
            self.version_label.setText("İNTERNET YOK!!!")
            self.version_label.setStyleSheet("color: #ff3333; font-size: 18px; font-weight: bold; background-color: rgba(0,0,0,0.8); padding: 5px; border-radius: 5px;")
        else:
            if current_text == "İNTERNET YOK!!!":
                # Restore original formatting
                version_text = "V1.00.00"
                try:
                    version_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "version.txt")
                    if os.path.exists(version_path):
                        with open(version_path, 'r', encoding='utf-8') as f:
                            version_text = f.read().strip()
                    elif os.path.exists("/opt/fatih-client/version.txt"):
                        with open("/opt/fatih-client/version.txt", 'r', encoding='utf-8') as f:
                            version_text = f.read().strip()
                except:
                    pass
                self.version_label.setText(f"Sürüm: {version_text}")
                self.version_label.setStyleSheet("color: white; font-size: 18px; background-color: rgba(0,0,0,0.7); padding: 5px; border-radius: 5px;")

    def show_login_dialog(self):
        """Giriş panelini göster (top-level frameless window - Cinnamon WM fix)"""
        logging.info(f"Login button clicked! is_locked={self.is_locked}")
        if not self.is_locked:
            logging.warning("show_login_dialog called but is_locked=False - skipping")
            return
        # C# stms=false: login panel açıkken sunucu komutlarını işleme
        self.start_work = False
        logging.info("start_work=False: Login panel açık - sunucu komutları askıya alındı")
        
        self.login_password_field.clear()
        self.login_error_label.setText("")
        
        # Paneli ekranın ortasına konumlandır
        panel_w, panel_h = 450, 480
        panel_x = (self.width() - panel_w) // 2
        panel_y = (self.height() - panel_h) // 2
        self.login_panel.setGeometry(panel_x, panel_y, panel_w, panel_h)
        
        # Bilgi panelleri (aferin/dogum gunu) giris ekranini ve numpad'i kapatmasin.
        self._hide_info_panels()

        # Tam ekran fotograf acikken sifre paneli ALTINDA kalabilirdi -> once kapat.
        self._foto_tam_ekran_kapat()

        self.login_panel.show()
        self.login_panel.raise_()
        # Force window to stay on top and regain focus if Cinnamon dropped it
        self.raise_()
        try:
            self.activateWindow()
        except Exception:
            pass
        
        # Remove setFocus() which causes ibus/fcitx crashes on Pardus ETAP
        # self.login_password_field.setFocus()
        logging.info(f"Login panel shown at ({panel_x},{panel_y}) size {panel_w}x{panel_h}, visible={self.login_panel.isVisible()}")
        for handler in logging.getLogger().handlers:
            handler.flush()

    def _login_attempt(self):
        """Gömülü giriş formundan şifre denemesi.
        
        Şifre doğrulaması (validate_admin_password) arka planda bir thread'de
        çalıştırılır; çünkü içindeki get_network_time() bloklu bir NTP soketi
        açar. Bu soketi Qt'nin ana UI thread'inde çağırmak event loop'u dondurarak
        PyQt5'in çökmesine neden olur.
        """
        password = self.login_password_field.text()
        if not password:
            return

        logging.info(f"Login attempt with password: {'*' * len(password)}")

        # UI'yı 'bekleniyor' durumuna al — kullanıcıya geri bildirim ver
        self.login_error_label.setText("🔄 Doğrulanıyor...")
        self.login_error_label.setStyleSheet("color: #ffaa00; font-size: 14px;")

        # Çift tıklamayı önlemek için butonu geçici olarak devre dışı bırak
        for btn in self.login_panel.findChildren(QPushButton):
            btn.setEnabled(False)

        # Signal'ı tek seferliğine bağla (önceki bağlantıları temizle)
        try:
            self._validation_result.disconnect()
        except TypeError:
            pass
        self._validation_result.connect(self._on_validation_result)

        # Bloklu NTP çağrısını arka thread'e taşı
        def _validate_in_thread(pwd):
            result = self.validate_admin_password(pwd)
            self._validation_result.emit(result)

        threading.Thread(target=_validate_in_thread, args=(password,), daemon=True).start()

    def _on_validation_result(self, is_valid: bool):
        """Background thread'den gelen doğrulama sonucunu UI thread'inde işle."""
        # Buton(lar)ı yeniden etkinleştir
        for btn in self.login_panel.findChildren(QPushButton):
            btn.setEnabled(True)

        if is_valid:
            logging.info("Password validated successfully")
            self.login_panel.hide()
            # C# stms=true'ya dönüş (başarılı giriş)
            self.start_work = True
            # Sebepsiz ack YOK — bkz. attempt_login'deki aciklama; sebep unlock_system'de gider.
            _y = getattr(self, 'son_acilis_yontemi', 'Admin sifresi')
            self.save_log("Admin şifre ile giriş yapıldı", "login")
            self.unlock_system(f"{_y} ile acildi")
        else:
            logging.warning("Invalid password entered")
            self.login_error_label.setStyleSheet("color: #ff4444; font-size: 14px;")
            self.login_error_label.setText("❌ Geçersiz şifre!")
            self.login_password_field.clear()
            self.login_password_field.setFocus()
            # start_work=False olarak kalıyor (panel hâlâ açık)

    def _toggle_password_visibility(self):
        """Şifre kutusunda göz ikonuna tıklandığında şifreyi göster/gizle (Task 3)"""
        if self.login_password_field.echoMode() == QLineEdit.EchoMode.Password:
            self.login_password_field.setEchoMode(QLineEdit.EchoMode.Normal)
            self.eye_btn.setText("🔒") # Kapalı kilit/göz ikonu
        else:
            self.login_password_field.setEchoMode(QLineEdit.EchoMode.Password)
            self.eye_btn.setText("👁")

    def _login_cancel(self):
        """Gömülü giriş panelini kapat"""
        self.login_panel.hide()
        # Giris kapandi -> bilgi panellerini son veriyle geri getir (ag'a gitmeden)
        self._restore_info_panels()
        # C# stms=true'ya dönüş (iptal edildi)
        self.start_work = True
        logging.info("Login panel cancelled - start_work=True restored")

    def validate_admin_password(self, password):
        """
        Şifre doğrulama - Önce config'deki admin şifresi, sonra Mebrecep çevrimdışı şifre

        1. Config'deki admin_password ile kontrol
        2. Çevrimdışı şifre (v6 TOTP, yoksa eski formül)

        Kaba kuvvet kilidi: 5 üst üste yanlıştan sonra 5 dk. Her iki şifreyi de korur.
        """
        # Kilitliyse hiçbir denemeyi kontrol etme (6 hane taranamasın)
        rem = offline_lock_remaining()
        if rem > 0:
            logging.warning(f"Şifre denemesi kilitli, {rem} sn kaldı.")
            return False

        # Önce config'deki admin şifresi ile kontrol et (PBKDF2 veya eski düz metin)
        if admin_sifre_dogru(password):
            logging.info("Password validated via config admin_password")
            self.son_acilis_yontemi = "Admin sifresi"
            offline_register_success()
            return True

        # Çevrimdışı şifre kontrolü (v6 tahta → TOTP; değilse eski formül)
        if validate_offline_password(password):
            logging.info("Password validated via offline algorithm (Mebrecep)")
            self.son_acilis_yontemi = "Cevrimdisi sifre"
            offline_register_success()
            return True

        # KRİZ KODU — sunucu tamamen çökmüşken son çare. Tamamen çevrimdışı doğrulanır.
        if validate_kriz_password(password):
            self.son_acilis_yontemi = "KRIZ KODU"
            offline_register_success()
            return True

        logging.warning("Invalid password - does not match config or offline algorithm")
        offline_register_failure()
        return False

    def show_context_menu(self, position):
        """Show right-click context menu"""
        context_menu = QMenu(self)

        # NEW: Manual Lock Action
        if not self.is_locked:
            lock_action = QAction("Tahtayı Kilitle", self)
            lock_action.triggered.connect(lambda: self.lock_system("Kullanıcı tarafından manuel kilitlendi"))
            context_menu.addAction(lock_action)
            context_menu.addSeparator()



        # Ayarlar kaldırıldı - müşteri isteği
        # settings_action = QAction("Ayarlar", self)
        # settings_action.triggered.connect(self.show_settings)
        # context_menu.addAction(settings_action)

        context_menu.addSeparator()

        # Change password
        change_pass_action = QAction("Şifre Değiştir", self)
        change_pass_action.triggered.connect(self.show_change_password)
        context_menu.addAction(change_pass_action)

        # Board configuration
        board_config_action = QAction("Tahta Yapılandırması", self)
        board_config_action.triggered.connect(self.show_board_config)
        context_menu.addAction(board_config_action)

        # Ders Saatleri
        schedule_action = QAction("🕒 Giriş Çıkış Saatleri", self)
        schedule_action.triggered.connect(lambda: self.show_schedule_dialog())
        context_menu.addAction(schedule_action)

        context_menu.addSeparator()



        # Kayıtları Görüntüle kaldırıldı - müşteri isteği
        # logs_action = QAction("Kayıtları Görüntüle", self)
        # logs_action.triggered.connect(self.show_logs)
        # context_menu.addAction(logs_action)

        context_menu.addSeparator()

        # System control
        restart_action = QAction("Yeniden Başlat", self)
        restart_action.triggered.connect(self.restart_system)
        context_menu.addAction(restart_action)

        shutdown_action = QAction("Kapat", self)
        shutdown_action.triggered.connect(self.shutdown_system)
        context_menu.addAction(shutdown_action)

        context_menu.addSeparator()



        context_menu.exec(QCursor.pos())

    def _show_info_dialog(self, dialog_class, **kwargs):
        """
        Bilgi amaçlı içerikleri kilit ekranı üzerine CHILD WIDGET olarak yerleştirir.
        Ayrı pencere OLMADIĞI için lockscreen hiç titresmiyor, hiç kapanmıyor.
        """
        title = kwargs.get('title', '')
        text = kwargs.get('text', '')
        schedule_data = kwargs.get('schedule_data', None)

        if schedule_data is not None:
            # Giriş/Çıkış Saatleri için özel miçro widget
            content = ScheduleWidget(schedule_data)
            LockScreenOverlay(self, title="Giriş/Çıkış Saatleri", content_widget=content)
        elif getattr(dialog_class, '__name__', str(dialog_class)) == 'OnScreenKeyboardDialog':
            numpad = EmbeddedNumpad()
            LockScreenOverlay(self, title="Ekran Klavyesi", content_widget=numpad)
        else:
            LockScreenOverlay(self, title=title, text=text)

    def show_system_status(self, checked=False):
        """Show system status dialog - Kurum kodu kaldırıldı"""
        board_name = SETTINGS.get('board_name', 'Akıllı Tahta')
        status_text = f"""
Sistem Durumu:

Tahta Adı: {board_name}
Versiyon: {SETTINGS.get('version')}.{SETTINGS.get('sub_version')}
Sistem Kilidi: {'Aktif' if getattr(self, 'is_locked', False) else 'Pasif'}
USB Bağlı: {'Evet' if check_usb_password() else 'Hayır'}
Ağ Bağlantısı: {'Var' if self.network_client.check_network() else 'Yok'}
_________________________________________________________________________________________
"""
        self._show_info_dialog('SystemMessageBox', title="Sistem Durumu", text=status_text.strip())

    def show_settings(self, checked=False):
        """Show settings dialog"""
        settings_text = f"""
Mevcut Ayarlar:

API URL: {get_setting('api_url')}
Polling Aralığı: {SETTINGS.get('polling_interval', 5)} saniye
USB Kontrol Aralığı: {SETTINGS.get('usb_check_interval', 3)} saniye
Bakım Aralığı: {SETTINGS.get('maintenance_interval', 25)} saniye

Bu ayarlar config.ini dosyasından değiştirilebilir.
_________________________________________________________________________________________
"""
        QMessageBox.information(self, "Ayarlar", settings_text.strip())

    def show_on_screen_keyboard(self, checked=False):
        """Show on-screen keyboard"""
        self._show_info_dialog('OnScreenKeyboardDialog')

    def show_logs(self, checked=False):
        """Show recent logs"""
        log_file = os.path.expanduser("~/fatih_client.log")
        if os.path.exists(log_file):
            try:
                with open(log_file, 'r') as f:
                    logs = f.read()
                log_dialog = QDialog(self)
                log_dialog.setWindowTitle("Sistem Kayıtları")
                log_dialog.setModal(True)
                layout = QVBoxLayout()
                log_text = QTextEdit()
                log_text.setPlainText(logs)
                log_text.setReadOnly(True)
                layout.addWidget(log_text)
                close_btn = QPushButton("Kapat")
                close_btn.clicked.connect(log_dialog.accept)
                layout.addWidget(close_btn)
                log_dialog.setLayout(layout)
                log_dialog.resize(600, 400)
                log_dialog.exec()
            except Exception as e:
                QMessageBox.warning(self, "Hata", f"Kayıtlar okunamadı: {e}")
        else:
            QMessageBox.information(self, "Bilgi", "Henüz kayıt dosyası oluşturulmamış.")

    def restart_system(self, checked=False):
        """Restart the system - C# bilgisayarıYenidenBaşlatToolStripMenuItem1_Click karşılığı
        C# kodu: cls = true; Process.Start("cmd", "/C shutdown -f -r -t 0")
        Onay diyalogu YOK - doğrudan çalıştırılır."""
        logging.info("Bilgisayar yeniden başlatılıyor (context menu)")
        self.save_log("Bilgisayar Yeniden Başlatıldı", "system")
        import subprocess
        # C# karşılığı: cmd /C shutdown -f -r -t 0
        reboot_commands = [
            ['sudo', 'reboot'],
            ['sudo', 'systemctl', 'reboot'],
            ['sudo', '/sbin/reboot'],
            ['systemctl', 'reboot'],
            ['reboot'],
        ]
        for cmd in reboot_commands:
            try:
                logging.info(f"Trying reboot command: {' '.join(cmd)}")
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    logging.info(f"Reboot initiated with: {' '.join(cmd)}")
                    return
            except FileNotFoundError:
                continue
            except subprocess.TimeoutExpired:
                # Komut çalıştı, sistem kapanıyor olabilir
                return
            except Exception as e:
                logging.warning(f"Reboot command {cmd} failed: {e}")
                continue
        # Son çare: os.system ile dene
        logging.warning("All reboot methods failed, trying os.system")
        os.system("sudo reboot || reboot")

    def shutdown_system(self, checked=False):
        """Shutdown the system - C# bilgisayarıYenidenBaşlatToolStripMenuItem_Click karşılığı
        C# kodu: cls = true; Process.Start("shutdown", "/s /f /t 0")
        Onay diyalogu YOK - doğrudan çalıştırılır."""
        logging.info("Bilgisayar kapatılıyor (context menu)")
        self.save_log("Bilgisayar Kapatıldı", "system")
        import subprocess
        # C# karşılığı: shutdown /s /f /t 0
        shutdown_commands = [
            ['sudo', 'poweroff'],
            ['sudo', 'systemctl', 'poweroff'],
            ['sudo', '/sbin/poweroff'],
            ['sudo', 'shutdown', '-h', 'now'],
            ['systemctl', 'poweroff'],
            ['poweroff'],
        ]
        for cmd in shutdown_commands:
            try:
                logging.info(f"Trying shutdown command: {' '.join(cmd)}")
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    logging.info(f"Shutdown initiated with: {' '.join(cmd)}")
                    return
            except FileNotFoundError:
                continue
            except subprocess.TimeoutExpired:
                # Komut çalıştı, sistem kapanıyor olabilir
                return
            except Exception as e:
                logging.warning(f"Shutdown command {cmd} failed: {e}")
                continue
        # Son çare: os.system ile dene
        logging.warning("All shutdown methods failed, trying os.system")
        os.system("sudo poweroff || poweroff")

    def show_about(self, checked=False):
        """Show about dialog"""
        about_text = f"""
Fatih Akıllı Tahta İstemcisi

Versiyon: {SETTINGS.get('version')}.{SETTINGS.get('sub_version')}

Bu yazılım Fatih Projesi kapsamında geliştirilmiştir.
Akıllı tahta güvenliği ve yönetimi için tasarlanmıştır.
"""
        LockScreenOverlay(self, title="Hakkında", text=about_text.strip())

    def _safe_open_dialog(self, dialog_class, **kwargs):
        """
        Dialog açmadan önce keyboard locker'ı güvenli şekilde durdurur,
        dialog kapandıktan sonra tekrar başlatır.
        time.sleep() KULLANMAZ — QTimer ile asenkron çalışır, Segfault önler.
        """
        locker_was_active = False
        if hasattr(self, 'keyboard_locker') and self.keyboard_locker:
            self.keyboard_locker.stop()
            self.keyboard_locker.join(timeout=3)
            self.keyboard_locker = None
            locker_was_active = True
            logging.info("Keyboard locker stopped for dialog")

        def _open():
            # Dialog açılmadan önce ana pencereden X11Bypass'ı kaldır
            # yoksa dialog ana pencerenin altında kalır veya tıklanamaz
            old_flags = self.windowFlags()
            self.setWindowFlags(
                Qt.Window | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
            )
            self.show()  # Flag değişikliği pencereyi gizler, tekrar göster
            
            dialog = dialog_class(self, **kwargs)
            dialog.exec()
            
            # Dialog kapandı, X11Bypass'ı geri yükle
            self.setWindowFlags(
                Qt.Window | Qt.FramelessWindowHint
                | Qt.WindowStaysOnTopHint | Qt.X11BypassWindowManagerHint
            )
            self.show()
            self.raise_()
            self.activateWindow()
            
            if locker_was_active:
                self.keyboard_locker = KeyboardLocker()
                self.keyboard_locker.start()
                logging.info("Keyboard locker restarted after dialog")

        if locker_was_active:
            QTimer.singleShot(500, _open)
        else:
            _open()

    def show_board_config(self, checked=False):
        """Show board configuration dialog"""
        # Şifre Zorunluluğu Kuralı:
        _pw = SETTINGS.get('admin_password', '803580')
        if _pw == '803580' or _pw == 'mebre':
            msg = QMessageBox(self)
            msg.setIcon(QMessageBox.Warning)
            msg.setWindowTitle("Uyarı")
            msg.setText("Tahta yapılandırmasını değiştirmeden önce güvenlik gereği cihazın varsayılan yönetim şifresini 'Şifre Değiştir' menüsünden değiştirmelisiniz.")
            msg.setStandardButtons(QMessageBox.Ok)
            msg.setWindowFlags(Qt.Tool | Qt.WindowStaysOnTopHint)
            msg.exec()
            
            QTimer.singleShot(50, lambda: (self.setWindowState((self.windowState() & ~Qt.WindowMinimized) | Qt.WindowActive), self.show(), self.raise_(), self.activateWindow()))
            return

        widget = BoardConfigWidget(self, network_client=self.network_client)
        overlay = LockScreenOverlay(self, title="Tahta Yapılandırması", content_widget=widget)
        widget.close_callback = overlay.close_overlay

    def show_change_password(self, checked=False):
        """Show change password dialog"""
        widget = ChangePasswordWidget(self)
        overlay = LockScreenOverlay(self, title="Şifre Değiştir", content_widget=widget)
        widget.close_callback = overlay.close_overlay

    def show_schedule(self, checked=False):
        """Show schedule hours dialog (C# FormGirisCikisSaatleri karşılığı)"""
        if self.schedule:
            self._show_info_dialog('ScheduleDialog', schedule_data=self.schedule)
        # The original instruction had an 'else:f process_admin_command(self):' here,
        # which is syntactically incorrect and seems like a copy-paste error.
        # Assuming the intent was to add a conditional check for self.schedule
        # and use exec_() instead of exec().
        # The rest of the instruction regarding ensure_usb_mounted, ScheduleDialog __init__
        # and window flags are not applicable to this specific code block.

    def process_admin_command(self):
        """Process admin commands (equivalent to C#textBox1_KeyDown)"""
        command = self.admin_input.text().strip()
        logging.info(f"Admin command received: {command}")

        if command == "_*:swf":
            self.unlock_system("Admin komutu ile açıldı")
            self.save_log("Admin komutu ile sistem açıldı", "admin")
        elif command == "_*:sl":
            self.lock_system("Admin komutu ile kilitlendi")
            self.save_log("Admin komutu ile sistem kilitlendi", "admin")
        elif command == "_*:cs":
            status = f"Sdwn:{self.shutDown} Tlck:{self.tahta_lock} Rmv:{self.system_remove} logS:{self.log_send}"
            self.message_label.setText(status)
        elif command == "_*:is":
            info = f"{SETTINGS.get('board_name', 'Board')},{SETTINGS.get('corporate_code')},{SETTINGS.get('board_id')}"
            self.message_label.setText(info)
        elif command == "_*:cls":
            self.admin_input.hide()
            self.message_label.setText(f"[{SETTINGS.get('version')}] {SETTINGS.get('board_name', 'Board')}")
        elif command.startswith("_*:pass"):
            # Password change command
            parts = command.split()
            if len(parts) == 2:
                new_password = parts[1]
                # In a real implementation, you'd save this to config
                logging.info(f"Admin password changed to: {new_password}")
                self.message_label.setText("Şifre değiştirildi")
        elif command == "_*:save":
            # Save configuration
            logging.info("Configuration saved by admin command")
            self.message_label.setText("Ayarlar kaydedildi")
        elif command == "_*:aop":
            self.show_settings()
        elif command == "_*:opgy":
            # Disable task manager equivalent
            logging.info("Task manager disabled by admin command")
            self.message_label.setText("Görev yöneticisi devre dışı")
        elif command == "_*:srmv":
            self.remove_system()

        # Clear the input after processing
        self.admin_input.clear()
        self.admin_input.hide()

    def keyPressEvent(self, event):
        """Handle key press events for admin interface"""
        if event.key() == Qt.Key.Key_K and event.modifiers() == Qt.KeyboardModifier.ControlModifier:
            # Toggle admin input visibility
            if self.admin_input.isVisible():
                self.admin_input.hide()
            else:
                self.admin_input.show()
                self.admin_input.setFocus()
        else:
            super().keyPressEvent(event)

    def resizeEvent(self, event):
        """Handle window resize to reposition UI elements"""
        super().resizeEvent(event)

        # Update background to fill window
        if hasattr(self, 'background'):
            self.background.setGeometry(self.rect())

        # Reposition login button to TOP-RIGHT
        if hasattr(self, 'login_button'):
            button_width = 280
            padding_top = 30
            padding_right = 30
            self.login_button.move(self.width() - button_width - padding_right, padding_top)

        # Reposition other UI elements
        if hasattr(self, 'message_label'):
            self.message_label.setGeometry(50, self.height() // 2 - 100, self.width() - 100, 200)

        if hasattr(self, 'time_label'):
            self.time_label.setGeometry(self.width() - 250, self.height() - 50, 240, 40)

        if hasattr(self, 'board_id_label'):
            label_width = 450
            label_height = 100
            label_x = (self.width() - label_width) // 2
            self.board_id_label.setGeometry(label_x, 20, label_width, label_height)

        if hasattr(self, 'help_toggle_button'):
            toggle_size = 50
            padding_top = 35
            padding_right = 30
            button_width = 280
            # Tahtayı Açın butonunun soluna yerleştir
            self.help_toggle_button.setGeometry(self.width() - button_width - padding_right - toggle_size - 15, padding_top, toggle_size, toggle_size)

        if hasattr(self, 'help_guide_label'):
            guide_width = 400
            padding_right = 30
            # Buton 30'da başlıyor, 60 boyunda = 90'da bitiyor. 
            # Kılavuzu 110'a koyalım.
            self.help_guide_label.setGeometry(self.width() - guide_width - padding_right, 110, guide_width, 320)

        if hasattr(self, 'version_update_label'):
            # Kılavuzun altına taşı ki çakışmasın
            self.version_update_label.setGeometry(self.width() - 350, 450, 320, 40)

def main():
    try:
        logging.info("Starting Fatih Client application...")
        print("Starting Fatih Client application...")

        app = QApplication(sys.argv)
        # Note: High DPI scaling attributes not available in this PyQt6 version

        window = FatihClientApp()
        logging.info("FatihClientApp created successfully")

        window.lock_system("Sistem başlatıldı")
        logging.info("System locked on startup")

        print("Application started successfully - login button should be visible")
        sys.exit(app.exec())
    except Exception as e:
        logging.critical(f"Unhandled exception in main: {e}", exc_info=True)
        print(f"Critical error: {e}")

def main_kiosk():
    """
    Kiosk mode for pre-login lock screen.
    Shows only the lock screen, exits after unlock to allow real user login.
    """
    try:
        logging.info("=== Starting Fatih Client in KIOSK MODE ===")
        app = QApplication(sys.argv)

        # Create a simplified kiosk window
        kiosk = FatihKioskMode()
        kiosk.show()

        logging.info("Kiosk mode started - waiting for unlock")
        sys.exit(app.exec())
    except Exception as e:
        logging.critical(f"Unhandled exception in kiosk mode: {e}", exc_info=True)
        print(f"Critical error in kiosk mode: {e}")
        sys.exit(1)

class FatihKioskMode(QMainWindow):
    """
    Kiosk mode that shows lock screen before user login.
    Supports: USB unlock, password unlock, mobile app unlock (server polling),
    and remote shutdown command.
    Normal modla aynı görünümde çalışır (duvar kağıdı, saat, tahta adı).
    """
    # Arka plan thread'i /display verisini getirdiginde UI thread'ine tasir (aferinTop5 listesi ya da None).
    _display_ready = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Fatih Sistem Kilidi")
        self.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setGeometry(QApplication.primaryScreen().geometry())

        # Mouse tracking ve right-click desteği
        self.setMouseTracking(True)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_kiosk_context_menu)

        # Network client for server polling (mobile app unlock + shutdown)
        self.network_client = NetworkClient(SETTINGS)

        # Background image (normal modla aynı)
        self.background = QLabel(self)
        bg_image_path = os.path.join(RESOURCES_DIR, "Artboard 3.png")
        if os.path.exists(bg_image_path):
            self.background.setPixmap(QPixmap(bg_image_path))
        else:
            logging.warning(f"Kiosk: Background image not found: {bg_image_path}")
            self.background.setStyleSheet("background-color: #1a1a2e;")
        self.background.setScaledContents(True)
        self.background.setGeometry(self.rect())

        # Time display (bottom-right corner - normal modla aynı)
        self.time_label = QLabel("", self)
        self.time_label.setStyleSheet("color: white; font-size: 18px; background-color: rgba(0,0,0,0.7); padding: 5px;")
        self.time_label.setAlignment(Qt.AlignRight)
        self.time_label.setGeometry(self.width() - 250, self.height() - 50, 240, 40)

        # Board Name display (top-center - normal modla aynı)
        self.board_id_label = QLabel("", self)
        self.board_id_label.setStyleSheet("""
            QLabel {
                color: white; 
                background-color: rgba(0, 0, 0, 220); 
                padding: 25px 40px;
                border-radius: 10px;
            }
        """)
        self.board_id_label.setFont(QFont('Sans', 20, QFont.Bold))
        self.board_id_label.setAlignment(Qt.AlignCenter)
        label_width = 450
        label_height = 100
        label_x = (self.width() - label_width) // 2
        self.board_id_label.setGeometry(label_x, 20, label_width, label_height)
        self.board_id_label.setMinimumHeight(label_height)
        board_name = SETTINGS.get('board_name', 'Akıllı Tahta')
        self.board_id_label.setText(board_name)

        # Status message label (empty by default, no Sistem Kilitli text)
        self.message_label = QLabel("", self)
        self.message_label.setStyleSheet("color: white; font-size: 32px; background-color: transparent;")
        self.message_label.setAlignment(Qt.AlignCenter)
        self.message_label.setWordWrap(True)
        self.message_label.setGeometry(50, self.height() // 2 - 100, self.width() - 100, 200)

        # Login button - normal modla aynı stil
        self.login_button = QPushButton("TAHTAYI AÇ", self)
        self.login_button.setStyleSheet("background-color: #0066cc; color: white; border: 3px solid white; border-radius: 10px;")
        self.login_button.setFont(QFont('DejaVu Sans', 18))
        self.login_button.pressed.connect(self.show_login)
        # Butonu sağ üst köşeye taşı
        button_width = 280
        button_height = 60
        self.login_button.setFixedSize(button_width, button_height)
        padding_top = 30
        padding_right = 30
        self.login_button.move(self.width() - button_width - padding_right, padding_top)
        self.login_button.raise_()
        self.login_button.setVisible(True)
        self.login_button.show()

        # --- YENİ: Yardım Kılavuzu Aç/Kapat Butonu (Kiosk Modu) ---
        self.help_toggle_button = QPushButton("ℹ", self)
        self.help_toggle_button.setStyleSheet("""
            QPushButton {
                background-color: rgba(0, 0, 0, 150); 
                color: #00ff88; 
                border: 2px solid white; 
                border-radius: 25px;
            }
            QPushButton:hover {
                background-color: rgba(0, 0, 0, 220);
            }
        """)
        self.help_toggle_button.setFont(QFont('DejaVu Sans', 24))
        self.help_toggle_button.pressed.connect(self.toggle_help_guide)
        toggle_size = 50
        self.help_toggle_button.setFixedSize(toggle_size, toggle_size)
        self.help_toggle_button.setGeometry(self.width() - button_width - 100, padding_top + 5, toggle_size, toggle_size)
        self.help_toggle_button.show()

        # --- YENİ: Tahtayı Açma Kılavuzu (Kiosk Modu) ---
        self.help_guide_label = QLabel(self)
        self.help_guide_label.setText(
            "👋 Merhaba! Tahtayı Açmak İçin:\n\n"
            "📱 Cep telefonunuza MebreCep uygulamasını indirin.\n\n"
            "🔓 Uygulamadan Akıllı Tahta menüsünden sınıfınızı seçip akıllı tahtayı açıp kilitleyebilirsiniz.\n\n"
            "🔑 Akıllı tahtada İnternet Yoksa: Uygulamadaki 'İnternetsiz Şifre Al' kodunu buradaki 'Tahtayı Aç' butonuna tıklayarak girin.\n\n"
            "✨ Ders bitiminde tahtanız otomatik olarak kilitlenecektir."
        )
        self.help_guide_label.setWordWrap(True)
        self.help_guide_label.setStyleSheet("""
            QLabel {
                color: white; 
                background-color: rgba(0, 0, 0, 180); 
                padding: 20px;
                border-radius: 15px;
                border: 2px solid #0066cc;
                font-size: 15px;
                line-height: 1.4;
            }
        """)
        self.help_guide_label.setGeometry(self.width() - 430, 110, 400, 320)
        self.help_guide_label.hide() # Varsayılan olarak gizli

        # --- Feature 5: "Bu Haftanın İlk 5 Aferini" paneli (sol-alt köşe) ---
        # Sunucudan (v5 /display) gelir; sınıf bazlı, bu haftanın en çok aferin alan 5 öğrencisi.
        # Veri yoksa (isim eşleşmedi / bu hafta aferin yok / ağ yok) panel gizli kalır.
        self.aferin_panel = QLabel(self)
        self.aferin_panel.setTextFormat(Qt.RichText)
        self.aferin_panel.setWordWrap(True)
        self.aferin_panel.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.aferin_panel.setStyleSheet("""
            QLabel {
                color: white;
                background-color: rgba(0, 0, 0, 190);
                padding: 18px 22px;
                border-radius: 15px;
                border: 2px solid #ffb300;
                font-size: 16px;
            }
        """)
        panel_w = 380
        panel_h = 340
        self.aferin_panel.setGeometry(30, self.height() - panel_h - 70, panel_w, panel_h)
        self.aferin_panel.hide()

        # /display verisi geldiğinde paneli UI thread'inde güncelle.
        self._display_ready.connect(self._render_aferin_panel)

        # Gösterim verisi timer'ı (5 dk) — yavaş değişir, poll'dan seyrek. İlk çekim biraz gecikmeli
        # (ağ/token otursun diye), sonra periyodik.
        self.display_timer = QTimer(self)
        self.display_timer.timeout.connect(self.refresh_display)
        self.display_timer.start(300000)  # 5 dakika
        QTimer.singleShot(2500, self.refresh_display)

        # Keyboard locker
        self.keyboard_locker = KeyboardLocker()
        self.keyboard_locker.start()

        # USB check timer (3 seconds)
        self.usb_timer = QTimer(self)
        self.usb_timer.timeout.connect(self.check_usb_for_unlock)
        self.usb_timer.start(3000)

        # Server polling timer (5 seconds) - mobil uygulama ile kilit açma/kapatma
        self.server_timer = QTimer(self)
        self.server_timer.timeout.connect(self.poll_server)
        self.server_timer.start(5000)

        # Time update timer (1 second)
        self.time_timer = QTimer(self)
        self.time_timer.timeout.connect(self.update_time_display)
        self.time_timer.start(1000)
        self.update_time_display()

        logging.info("Kiosk mode UI initialized with background, clock, USB monitoring, and server polling")

    def update_time_display(self):
        """Update the time display in bottom-right corner (AG SAATI ile senkron)"""
        current_time = simdi()
        time_str = current_time.strftime("%d/%m/%Y %H:%M:%S")
        self.time_label.setText(time_str)

    def refresh_display(self):
        """Kilit ekrani gosterim verisini (v5 /display) ARKA PLAN thread'inde ceker; sonucu
        _display_ready sinyaliyle UI thread'ine tasir. Boylece ag gecikmesi kilit ekranini dondurmaz."""
        def _worker():
            try:
                data = self.network_client.get_display()
                top5 = data.get("aferinTop5") if isinstance(data, dict) else None
            except Exception as e:
                logging.error(f"Kiosk: /display cekimi basarisiz: {e}")
                top5 = None
            self._display_ready.emit(top5)

        threading.Thread(target=_worker, daemon=True).start()

    def _render_aferin_panel(self, top5):
        """Bu haftanin ilk-5 aferin listesini sol-alt panelde gosterir (UI thread). Bos/None -> gizle."""
        if not top5:
            self.aferin_panel.hide()
            return

        def _esc(s):
            return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

        medals = ['🥇', '🥈', '🥉', '4.', '5.']
        rows_html = []
        for i, r in enumerate(top5[:5]):
            medal = medals[i] if i < len(medals) else f"{i + 1}."
            numara = _esc(r.get('numara', ''))
            adi = _esc(r.get('adi', ''))
            aferin = int(r.get('aferin', 0) or 0)
            no_part = f"<b>No {numara}</b> " if numara else ""
            rows_html.append(
                f"<div style='margin:6px 0;'>{medal} {no_part}{adi} "
                f"<span style='color:#ffd700;'>— {aferin} ⭐</span></div>"
            )

        html = (
            "<div style='font-size:20px;font-weight:bold;color:#ffd700;margin-bottom:8px;'>"
            "🏆 Bu Haftanın Aferinleri</div>"
            + "".join(rows_html)
        )
        self.aferin_panel.setText(html)
        self.aferin_panel.show()
        self.aferin_panel.raise_()

    def check_usb_for_unlock(self):
        """Check USB for unlock password"""
        usb_password = check_usb_password()
        if usb_password:
            logging.info(f"Kiosk mode unlocked by USB: {usb_password}")
            self.unlock_and_exit()

    def poll_server(self):
        """
        Poll server for commands (mobile app unlock + shutdown).
        tahta_lock=0 → unlock, shutDown=1 → shutdown
        """
        try:
            commands = self.network_client.ctrl_post()
            if commands:
                if len(commands) >= 5:
                    tahta_lock = int(commands[0])
                    shut_down = int(commands[2])
                    system_remove = int(commands[3])
                    
                    # Update message from server
                    message = commands[1] if commands[1] != '0' else "Sistem Kilitli"
                    self.message_label.setText(message)
                    
                    # Mobile app unlock: tahta_lock=0 means unlock
                    if tahta_lock == 0:
                        logging.info("Kiosk: Server says unlock (mobile app)")
                        self.unlock_and_exit()
                        return
                    
                    # Shutdown command from mobile app
                    if shut_down == 1:
                        logging.info("Kiosk: Shutdown command from server (mobile app)")
                        # Acknowledge the command
                        self.network_client.set_value("shutdown", "0")
                        import subprocess
                        shutdown_commands = [
                            ['sudo', 'poweroff'],
                            ['sudo', 'systemctl', 'poweroff'],
                            ['sudo', '/sbin/poweroff'],
                            ['sudo', 'shutdown', '-h', 'now'],
                            ['poweroff'],
                        ]
                        for cmd in shutdown_commands:
                            try:
                                logging.info(f"Kiosk: Trying shutdown command: {' '.join(cmd)}")
                                result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                                if result.returncode == 0:
                                    logging.info(f"Kiosk: Shutdown initiated with: {' '.join(cmd)}")
                                    QApplication.quit()
                                    return
                            except subprocess.TimeoutExpired:
                                QApplication.quit()
                                return
                            except Exception as e:
                                logging.warning(f"Kiosk: Shutdown command {cmd} failed: {e}")
                                continue
                        os.system("sudo poweroff || poweroff")
                        QApplication.quit()
                        return
                    
                    # System remove command
                    if system_remove == 1:
                        logging.info("Kiosk: System remove command from server")
                        self.unlock_and_exit()
                        return
            else:
                logging.debug("Kiosk: Server unreachable or no response")
        except Exception as e:
            logging.debug(f"Kiosk: Server poll error: {e}")

    def show_kiosk_context_menu(self, position):
        """Kiosk modunda sağ tık menüsü - Normal moddaki tüm seçenekler"""
        context_menu = QMenu(self)
        context_menu.setStyleSheet("""
            QMenu {
                background-color: #2b2b2b;
                color: white;
                border: 1px solid #555;
                padding: 5px;
                font-size: 14px;
            }
            QMenu::item {
                padding: 8px 25px;
                min-width: 200px;
            }
            QMenu::item:selected {
                background-color: #0066cc;
            }
            QMenu::separator {
                height: 1px;
                background: #555;
                margin: 4px 10px;
            }
        """)

        # Giriş (login) seçeneği
        login_action = QAction("Tahtayı Aç (Giriş)", self)
        login_action.triggered.connect(self.show_login)
        context_menu.addAction(login_action)

        context_menu.addSeparator()



        context_menu.addSeparator()

        # Tahta Yapılandırması
        board_config_action = QAction("Tahta Yapılandırması", self)
        board_config_action.triggered.connect(self.kiosk_show_board_config)
        context_menu.addAction(board_config_action)

        # Şifre Değiştir
        change_pass_action = QAction("Şifre Değiştir", self)
        change_pass_action.triggered.connect(self.kiosk_show_change_password)
        context_menu.addAction(change_pass_action)

        context_menu.addSeparator()



        context_menu.addSeparator()



        context_menu.addSeparator()

        # Yeniden başlat
        restart_action = QAction("Yeniden Başlat", self)
        restart_action.triggered.connect(self.kiosk_system_restart)
        context_menu.addAction(restart_action)

        # Kapat
        shutdown_action = QAction("Kapat", self)
        shutdown_action.triggered.connect(self.kiosk_system_shutdown)
        context_menu.addAction(shutdown_action)

        context_menu.addSeparator()



        context_menu.exec_(QCursor.pos())

    def kiosk_system_shutdown(self):
        """Kiosk modunda sistemi kapat"""
        import subprocess
        logging.info("Kiosk: Shutdown requested from context menu")
        shutdown_commands = [
            ['sudo', 'poweroff'],
            ['sudo', 'systemctl', 'poweroff'],
            ['sudo', '/sbin/poweroff'],
            ['sudo', 'shutdown', '-h', 'now'],
            ['poweroff'],
        ]
        for cmd in shutdown_commands:
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    QApplication.quit()
                    return
            except:
                continue
        os.system("sudo poweroff || poweroff")
        QApplication.quit()

    def kiosk_system_restart(self):
        """Kiosk modunda sistemi yeniden başlat"""
        import subprocess
        logging.info("Kiosk: Reboot requested from context menu")
        reboot_commands = [
            ['sudo', 'reboot'],
            ['sudo', 'systemctl', 'reboot'],
            ['sudo', '/sbin/reboot'],
            ['reboot'],
        ]
        for cmd in reboot_commands:
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    QApplication.quit()
                    return
            except:
                continue
        os.system("sudo reboot || reboot")
        QApplication.quit()

    def show_login(self):
        """Show admin login dialog - önce keyboard locker'ı durdur ki yazabilsin"""
        # CRITICAL: Keyboard locker'ı durdur ve bitmesini bekle!
        if self.keyboard_locker:
            self.keyboard_locker.stop()
            self.keyboard_locker.join(timeout=3)  # Thread'in bitmesini bekle
            self.keyboard_locker = None
            logging.info("Kiosk: Keyboard locker stopped and joined for login dialog")
            # evdev grab release'inin tamamlanması için 500ms bekle — BLOKSUZ
            QTimer.singleShot(500, self._do_show_login)
            return
        self._do_show_login()

    def _do_show_login(self):

        dialog = QDialog(self)
        dialog.setWindowTitle("Yönetici Girişi")
        dialog.setModal(True)
        dialog.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.Tool)

        # Dialog stil ve boyut ayarları - kiosk fullscreen'de düzgün görünsün
        dialog.setStyleSheet("""
            QDialog {
                background-color: #2b2b2b;
                color: white;
                border: 2px solid #0066cc;
                border-radius: 10px;
            }
            QLabel {
                color: white;
            }
            QLineEdit {
                background-color: #3c3c3c;
                color: white;
                border: 2px solid #555;
                border-radius: 5px;
                padding: 10px;
                font-size: 16px;
            }
            QLineEdit:focus {
                border-color: #0066cc;
            }
            QPushButton {
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
                min-width: 120px;
            }
        """)

        layout = QVBoxLayout()
        layout.setSpacing(15)
        layout.setContentsMargins(30, 25, 30, 25)

        title = QLabel("Sistem Kilidi Açma")
        title.setFont(QFont("Arial", 20, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: white; margin-bottom: 5px;")
        layout.addWidget(title)

        # Info label: show password hint
        info = QLabel("Mebrecep uygulamasından şifreyi alın\nveya metin kutusuna tıklayarak ekran klavyesini açın")
        info.setAlignment(Qt.AlignCenter)
        info.setStyleSheet("color: #aaa; font-size: 13px; margin-bottom: 10px;")
        info.setWordWrap(True)
        layout.addWidget(info)

        password_field = KeyboardLineEdit()
        password_field.setEchoMode(QLineEdit.Password)
        password_field.setPlaceholderText("Mebrecep'ten şifre yazınız")
        password_field.setFont(QFont("Arial", 16))
        password_field.setMinimumHeight(50)
        # Klavyeden Enter'a basıldığında doğrudan giriş yapsın
        password_field.set_on_enter_callback(lambda: self.attempt_unlock(password_field.text(), dialog))
        layout.addWidget(password_field)

        numpad = EmbeddedNumpad(on_enter_callback=lambda: self.attempt_unlock(password_field.text(), dialog))
        layout.addWidget(numpad)

        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)

        cancel_btn = QPushButton("İptal")
        cancel_btn.setMinimumHeight(50)
        cancel_btn.setStyleSheet("background-color: #555; color: white; font-weight: bold;")
        cancel_btn.pressed.connect(dialog.reject)
        button_layout.addWidget(cancel_btn)

        login_btn = QPushButton("Tahtayı Aç")
        login_btn.setMinimumHeight(50)
        login_btn.setStyleSheet("background-color: #0066cc; color: white; font-weight: bold;")
        login_btn.pressed.connect(lambda: self.attempt_unlock(password_field.text(), dialog))
        login_btn.setDefault(True)
        button_layout.addWidget(login_btn)

        layout.addLayout(button_layout)
        dialog.setLayout(layout)

        # Boyut ve konum ayarları
        dialog.setFixedSize(450, 650)
        # Ekranın ortasına yerleştir
        screen = QApplication.primaryScreen().geometry()
        dialog.move(
            (screen.width() - 450) // 2,
            (screen.height() - 650) // 2
        )

        logging.info("Kiosk: Login dialog shown")
        result = dialog.exec()
        logging.info(f"Kiosk: Login dialog closed with result={result}")

        # Dialog kapandıysa ve kilit açılmadıysa keyboard locker'ı tekrar başlat
        if result != QDialog.Accepted:
            self.keyboard_locker = KeyboardLocker()
            self.keyboard_locker.start()
            logging.info("Kiosk: Keyboard locker restarted after cancelled login")

    def attempt_unlock(self, password, dialog):
        """
        Kiosk modunda şifre ile kilit açma
        Mebrecep'ten alınan çevrimdışı şifre ile çalışır (v6 → TOTP, değilse eski formül)
        """
        logging.info(f"Kiosk: Unlock attempt with password length={len(password)}")

        if not password or len(password) == 0:
            QMessageBox.warning(dialog, "Hata", "Lütfen şifre giriniz!")
            return

        # Kaba kuvvet kilidi: kilitliyse denemeyi hiç kontrol etme
        rem = offline_lock_remaining()
        if rem > 0:
            dk = (rem + 59) // 60
            QMessageBox.warning(dialog, "Kilitli",
                                f"Çok fazla yanlış deneme. {dk} dakika sonra tekrar deneyin.")
            return

        # Çevrimdışı şifre kontrolü (v6 → TOTP; değilse eski formül). Orijinal davranış korunur:
        # kiosk yalnızca çevrimdışı şifreyi kabul eder (admin şifresi burada KABUL EDİLMEZ —
        # varsayılan 803580 herkesçe bilindiği için kilit ekranını açmamalı).
        if validate_offline_password(password):
            logging.info("Kiosk mode unlocked with offline password (Mebrecep)")
            offline_register_success()
            dialog.accept()
            self.unlock_and_exit()
        else:
            # GÜVENLİK: beklenen şifre ASLA log'a yazılmaz (log'u okuyan açabilir).
            offline_register_failure()
            logging.warning(f"Failed kiosk unlock attempt - entered len={len(password)}")
            QMessageBox.warning(dialog, "Hata", "Yanlış şifre!\nMebrecep uygulamasından güncel şifreyi alın.")

    def unlock_and_exit(self):
        """Unlock and exit to allow real user login"""
        logging.info("Kiosk mode unlock successful - exiting to show user login")

        # Stop USB timer
        if self.usb_timer:
            self.usb_timer.stop()

        # Stop server polling timer
        if self.server_timer:
            self.server_timer.stop()

        # Stop time timer
        if self.time_timer:
            self.time_timer.stop()

        # Stop keyboard locker
        if self.keyboard_locker:
            self.keyboard_locker.stop()
            self.keyboard_locker = None

        # Hide window
        self.hide()

        # Exit application - kiosk launcher will restart display manager
        QApplication.quit()

    def _show_info_dialog(self, dialog_class, **kwargs):
        """
        Bilgi amaçlı içerikleri kilit ekranı üzerine CHILD WIDGET olarak yerleştirir.
        Ayrı pencere OLMADIĞi için lockscreen hiç titresmiyor, hiç kapanmıyor.
        """
        title = kwargs.get('title', '')
        text = kwargs.get('text', '')
        schedule_data = kwargs.get('schedule_data', None)

        if schedule_data is not None:
            content = ScheduleWidget(schedule_data)
            LockScreenOverlay(self, title="Giriş/Çıkış Saatleri", content_widget=content)
        elif getattr(dialog_class, '__name__', str(dialog_class)) == 'OnScreenKeyboardDialog':
            numpad = EmbeddedNumpad()
            LockScreenOverlay(self, title="Ekran Klavyesi", content_widget=numpad)
        else:
            LockScreenOverlay(self, title=title, text=text)

    def kiosk_show_system_status(self):
        """Kiosk modunda sistem durumu göster"""
        board_name = SETTINGS.get('board_name', 'Akıllı Tahta')
        status_text = f"""
Sistem Durumu:

Tahta Adı: {board_name}
Versiyon: {SETTINGS.get('version')}.{SETTINGS.get('sub_version')}
Sistem Kilidi: Aktif (Kiosk Modu)
USB Bağlı: {'Evet' if check_usb_password() else 'Hayır'}
Ağ Bağlantısı: {'Var' if self.network_client.check_network() else 'Yok'}
_________________________________________________________________________________________
"""
        LockScreenOverlay(self, title="Sistem Durumu", text=status_text.strip())

    def _safe_open_dialog(self, dialog_class, **kwargs):
        """
        Kiosk modunda dialog açmadan önce keyboard locker'ı güvenli şekilde durdurur,
        dialog kapandıktan sonra tekrar başlatır.
        time.sleep() KULLANMAZ — QTimer ile asenkron çalışır, Segfault önler.
        """
        locker_was_active = False
        if getattr(self, 'keyboard_locker', None):
            self.keyboard_locker.stop()
            self.keyboard_locker.join(timeout=3)
            self.keyboard_locker = None
            locker_was_active = True
            logging.info("Kiosk: Keyboard locker stopped for dialog")

        def _open():
            dialog = dialog_class(self, **kwargs)
            dialog.exec()
            # Kiosk modunda keyboard locker her zaman tekrar başlar
            self.keyboard_locker = KeyboardLocker()
            self.keyboard_locker.start()
            logging.info("Kiosk: Keyboard locker restarted after dialog")
            # Modal kapanınca FatihClient arkaplana düşmesin (Cinnamon X11 Focus Pump)
            QTimer.singleShot(100, lambda: (
                self.setWindowState((self.windowState() & ~Qt.WindowMinimized) | Qt.WindowActive),
                self.show(), self.raise_(), self.activateWindow()
            ))

        if locker_was_active:
            # evdev grab release'inin tam tamamlanması için 500ms bekle — BLOKSUZ
            QTimer.singleShot(500, _open)
        else:
            _open()

    def kiosk_show_board_config(self):
        """Kiosk modunda tahta yapılandırması göster"""
        # Şifre Zorunluluğu Kuralı:
        _pw = SETTINGS.get('admin_password', '803580')
        if _pw == '803580' or _pw == 'mebre':
            msg = QMessageBox(self)
            msg.setIcon(QMessageBox.Warning)
            msg.setWindowTitle("Uyarı")
            msg.setText("Tahta yapılandırmasını değiştirmeden önce güvenlik gereği cihazın varsayılan yönetim şifresini 'Şifre Değiştir' menüsünden değiştirmelisiniz.")
            msg.setStandardButtons(QMessageBox.Ok)
            msg.setWindowFlags(Qt.Tool | Qt.WindowStaysOnTopHint)
            msg.exec()
            
            QTimer.singleShot(50, lambda: (self.setWindowState((self.windowState() & ~Qt.WindowMinimized) | Qt.WindowActive), self.show(), self.raise_(), self.activateWindow()))
            return

        widget = BoardConfigWidget(self, network_client=self.network_client)
        overlay = LockScreenOverlay(self, title="Tahta Yapılandırması", content_widget=widget)
        widget.close_callback = overlay.close_overlay

    def kiosk_show_change_password(self):
        """Kiosk modunda şifre değiştir dialog göster"""
        widget = ChangePasswordWidget(self)
        overlay = LockScreenOverlay(self, title="Şifre Değiştir", content_widget=widget)
        widget.close_callback = overlay.close_overlay

    def kiosk_show_schedule(self):
        """Kiosk modunda giriş/çıkış saatleri dialog göster"""
        schedule_file = os.path.expanduser("~/fatih_schedule.json")
        schedule_data = {}
        if os.path.exists(schedule_file):
            try:
                import json
                with open(schedule_file, 'r', encoding='utf-8') as f:
                    schedule_data = json.load(f)
            except Exception as e:
                logging.error(f"Kiosk schedule load error: {e}")
        self._show_info_dialog('ScheduleDialog', schedule_data=schedule_data)

    def kiosk_show_on_screen_keyboard(self):
        """Kiosk modunda ekran klavyesi göster"""
        self._show_info_dialog('OnScreenKeyboardDialog')

    def kiosk_show_about(self):
        """Kiosk modunda hakkında dialog göster"""
        about_text = f"""
Fatih Akıllı Tahta İstemcisi

Versiyon: {SETTINGS.get('version')}.{SETTINGS.get('sub_version')}

Bu yazılım Fatih Projesi kapsamında geliştirilmiştir.
Akıllı tahta güvenliği ve yönetimi için tasarlanmıştır.
"""
        LockScreenOverlay(self, title="Hakkında", text=about_text.strip())

    def resizeEvent(self, event):
        """Handle window resize to reposition UI elements"""
        super().resizeEvent(event)

        if hasattr(self, 'background'):
            self.background.setGeometry(self.rect())

        if hasattr(self, 'login_button'):
            button_width = 280
            padding_top = 30
            padding_right = 30
            self.login_button.move(self.width() - button_width - padding_right, padding_top)

        if hasattr(self, 'message_label'):
            self.message_label.setGeometry(50, self.height() // 2 - 100, self.width() - 100, 200)

        if hasattr(self, 'time_label'):
            self.time_label.setGeometry(self.width() - 250, self.height() - 50, 240, 40)

        if hasattr(self, 'board_id_label'):
            label_width = 450
            label_x = (self.width() - label_width) // 2
            self.board_id_label.setGeometry(label_x, 20, label_width, 100)
            
        if hasattr(self, 'help_toggle_button'):
            toggle_size = 50
            padding_top = 35
            padding_right = 30
            button_width = 280
            self.help_toggle_button.setGeometry(self.width() - button_width - padding_right - toggle_size - 15, padding_top, toggle_size, toggle_size)

        if hasattr(self, 'help_guide_label'):
            guide_width = 400
            padding_right = 30
            self.help_guide_label.setGeometry(self.width() - guide_width - padding_right, 110, guide_width, 320)
            
        if hasattr(self, 'warning_label'):
            self.warning_label.setGeometry(self.width() // 2 - 200, self.height() // 2 - 25, 400, 50)

if __name__ == '__main__':
    # Check command line arguments
    if len(sys.argv) > 1:
        if sys.argv[1] == '--test':
            print("Running in test mode...")
            try:
                validate_config()
                print("✅ Configuration loaded successfully")
                print(f"Admin password: {SETTINGS.get('admin_password', '803580')}")
            except Exception as e:
                print(f"❌ Configuration error: {e}")
            sys.exit(0)
        elif sys.argv[1] == '--kiosk':
            print("Running in KIOSK mode (pre-login lock screen)")
            main_kiosk()
            sys.exit(0)

    # Normal mode
    main()

