========================================================
  MEBRE AKILLI TAHTA - KURULUM KILAVUZU
  Pardus ETAP / Fatih Client
========================================================

KURULUM ADIMLARI
----------------
1. Bu klasoru oldugu gibi tahtaya cikartin.
   Dosyalari tek tek kopyalamayin.

2. Klasorde sag tiklayip "Terminalde ac" deyin.

3. Kurulumu baslatin:

      sudo ./setup.sh

4. Ekranda istendiginde okulun KURUM KODUNU girin (sadece rakam).

5. Kurulum bitince tahtayi yeniden baslatin:

      sudo reboot

6. Tahta acildiginda kilit ekrani gelir.
   Once sag tiklayip SIFREYI DEGISTIRIN (fabrika sifresi: 803580).
   Sonra kurum kodu + yeni sifre ile "Tahtalari Getir" deyip
   bu tahtayi listeden secin.


SIK KARSILASILAN DURUMLAR
-------------------------
- "Kurulum dosyalari eksik" : Paket duzgun cikarilmamis.
  Klasoru oldugu gibi kullanin.

- "Once sag tiklayip sifrenizi degistiriniz!" : Fabrika sifresi
  hala duruyor. Sifreyi degistirmeden tahta listesi gelmez.

- "Internet yok" : Tahtanin ag baglantisini kontrol edin.
  Kurulum internet olmadan tamamlanamaz.

- "Kurulum kodu gecersiz" : Elinizdeki paket eski.
  Destek hattini arayin.

- Kurulum yarida kalirsa setup.sh yeniden calistirilabilir,
  onceki ayarlar korunur.


PAKET BILGISI
-------------
Surum           : V6.00.41
Yapi            : 2026-08-03
Paket Dogrulama : 22fe9d855748c6dd432b20aae07f01b223847c0a5386a603aa33622718769035
Mimari          : x86_64
Bagimliliklar   : python3-pyqt5, python3-evdev, Cython 3.0.11


DESTEK
------
Mebre Yazilim
Telefon : 0850 XXX XX XX
E-posta : destek@mebre.com.tr

Bu kilavuz kurulum klasorunde kalmalidir, silmeyiniz.
========================================================
